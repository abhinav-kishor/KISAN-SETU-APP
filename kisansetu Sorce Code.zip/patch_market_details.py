import re

with open("app/src/main/java/com/example/ui/screens/MarketDetailsScreen.kt", "r") as f:
    content = f.read()

# Add a check to load routes if missing
if "LaunchedEffect(userLocation) {" not in content:
    content = content.replace(
        "val existingRequest = sellRequests.find { ",
        """
    LaunchedEffect(userLocation) {
        if (routePolylines.isEmpty() && (userLocation != null || androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED)) {
            mapViewModel.loadLocationAndRoutes(context, MarketRepository.availableMarkets.value)
        }
    }
    val existingRequest = sellRequests.find { """
    )

with open("app/src/main/java/com/example/ui/screens/MarketDetailsScreen.kt", "w") as f:
    f.write(content)
