import re

with open('app/src/main/java/com/example/ui/screens/MandiOverviewScreen.kt', 'r') as f:
    content = f.read()

# Update signature
old_sig = """fun MandiOverviewScreen(navController: NavController, marketId: String?, quantity: Int) {"""
new_sig = """import com.example.ui.screens.MandiViewModel\nimport androidx.compose.ui.layout.ContentScale\nimport coil.compose.AsyncImage\nimport androidx.compose.foundation.shape.RoundedCornerShape\nimport androidx.compose.ui.draw.clip\n\n@OptIn(ExperimentalMaterial3Api::class)\n@Composable\nfun MandiOverviewScreen(navController: NavController, marketId: String?, quantity: Int, mandiViewModel: MandiViewModel) {"""
content = content.replace("@OptIn(ExperimentalMaterial3Api::class)\n@Composable\nfun MandiOverviewScreen(navController: NavController, marketId: String?, quantity: Int) {", new_sig)

# Add tabs
old_body = """        Column(modifier = Modifier.padding(innerPadding).fillMaxSize().padding(16.dp)) {
            Text(market.name, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Text("${market.name}, Uttar Pradesh", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("${market.distanceKm} km away", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            
            Spacer(modifier = Modifier.height(24.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(16.dp))
            Text("Crops Demanding at this mandi", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(16.dp))
            if (market.crops.isEmpty()) {"""

new_body = """        Column(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 16.dp)) {
                Text(market.name, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text("${market.name}, Uttar Pradesh", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("${market.distanceKm} km away", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            
            var selectedTabIndex by remember { mutableStateOf(0) }
            val tabs = listOf("Crops", "Photos")
            
            TabRow(selectedTabIndex = selectedTabIndex) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = { Text(title, fontWeight = FontWeight.Bold) }
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            if (selectedTabIndex == 0) {
                Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                    Text("Crops Demanding at this mandi", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(16.dp))
                    if (market.crops.isEmpty()) {"""
content = content.replace(old_body, new_body)

# Close the new if statement and add the Photos tab logic
old_tail = """                    }
                }
            }
        }
    }
}"""

new_tail = """                    }
                }
                }
            } else {
                Column(modifier = Modifier.padding(horizontal = 16.dp).fillMaxSize()) {
                    val profile by mandiViewModel.mandiProfile.collectAsState()
                    if (profile?.mandiId == market.id && profile?.shopPhotoUri != null) {
                        Text("Shop Photo", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(8.dp))
                        Box(modifier = Modifier.fillMaxWidth().height(250.dp).clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.surfaceVariant)) {
                            AsyncImage(
                                model = profile?.shopPhotoUri,
                                contentDescription = "Shop Photo",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    } else {
                        Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                            Text("No photos available for this mandi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}"""
content = content.replace(old_tail, new_tail)

with open('app/src/main/java/com/example/ui/screens/MandiOverviewScreen.kt', 'w') as f:
    f.write(content)
