package com.example.util

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow

enum class AppTheme(val displayName: String) {
    DEFAULT("Official Green"),
    OCEAN("Ocean Blue"),
    FOREST("Deep Forest"),
    SUNSET("Sunset Orange"),
    LAVENDER("Lavender")
}

object ThemeManager {
    private const val PREFS_NAME = "theme_prefs"
    private const val THEME_KEY = "selected_theme"

    val themeState = MutableStateFlow(AppTheme.DEFAULT)

    fun init(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val savedThemeName = prefs.getString(THEME_KEY, AppTheme.DEFAULT.name) ?: AppTheme.DEFAULT.name
        val savedTheme = try {
            AppTheme.valueOf(savedThemeName)
        } catch (e: Exception) {
            AppTheme.DEFAULT
        }
        themeState.value = savedTheme
    }

    fun setTheme(context: Context, theme: AppTheme) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(THEME_KEY, theme.name).apply()
        themeState.value = theme
    }
}
