package com.example.ui.screens

import android.app.Activity
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.activity.compose.LocalActivity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.R
import com.example.ui.AuthViewModel
import com.example.ui.UserState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun PhoneVerificationScreen(
    navController: NavController,
    authViewModel: AuthViewModel,
    phone: String,
    name: String,
    email: String,
    pass: String
) {
    val userState by authViewModel.userState.collectAsState()
    val verificationId by authViewModel.verificationId.collectAsState()
    
    var otp by remember { mutableStateOf("") }
    var timer by remember { mutableStateOf(60) }
    
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val activity = LocalActivity.current ?: return

    LaunchedEffect(Unit) {
        if (verificationId.isNullOrEmpty()) {
            authViewModel.startPhoneVerification(phone, activity)
        }
        while (timer > 0) {
            delay(1000)
            timer--
        }
    }

    LaunchedEffect(userState) {
        if (userState is UserState.SignedIn) {
            if (email != "NONE") {
                navController.navigate("email_verification") {
                    popUpTo("signup") { inclusive = true }
                    popUpTo("phone_verification") { inclusive = true }
                    popUpTo("login") { inclusive = true }
                }
            } else {
                navController.navigate("role_selection") {
                    popUpTo("signup") { inclusive = true }
                    popUpTo("phone_verification") { inclusive = true }
                    popUpTo("login") { inclusive = true }
                }
            }
        } else if (userState is UserState.Error) {
            val message = (userState as UserState.Error).message
            scope.launch {
                snackbarHostState.showSnackbar(message)
                authViewModel.clearError()
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = stringResource(R.string.phone_verified),
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(16.dp))
            
            Text(
                text = stringResource(R.string.enter_code_sent) + "\n" + phone.take(4) + "****" + phone.takeLast(4),
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center
            )
            
            Spacer(modifier = Modifier.height(32.dp))
            
            OutlinedTextField(
                value = otp,
                onValueChange = { if (it.length <= 6) otp = it },
                label = { Text(stringResource(R.string.enter_verification_code)) },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true
            )
            
            Spacer(modifier = Modifier.height(32.dp))
            
            Button(
                onClick = {
                    if (otp.length == 6 && !verificationId.isNullOrEmpty()) {
                        authViewModel.verifyOTPAndSignUp(verificationId!!, otp, name, phone, email, pass)
                    } else {
                        scope.launch { snackbarHostState.showSnackbar("Enter valid 6-digit OTP") }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                enabled = userState !is UserState.Loading && otp.length == 6
            ) {
                if (userState is UserState.Loading) {
                    CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.onPrimary)
                } else {
                    Text(stringResource(R.string.verify_otp), style = MaterialTheme.typography.titleMedium)
                }
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            if (timer > 0) {
                Text(stringResource(R.string.resend_in_seconds, timer), color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                TextButton(onClick = {
                    timer = 60
                    authViewModel.startPhoneVerification(phone, activity)
                }) {
                    Text(stringResource(R.string.resend_otp))
                }
            }
        }
    }
}
