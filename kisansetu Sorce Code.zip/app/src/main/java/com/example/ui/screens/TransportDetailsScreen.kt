package com.example.ui.screens

import com.example.R

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.ui.res.stringResource
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.ui.MarketRepository
import com.example.ui.availableVehicles
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransportDetailsScreen(
    navController: NavController,
    mandiId: String,
    vehicleId: String,
    quantity: Int,
    distanceKm: Double,
    fare: Int
) {
    val market = MarketRepository.availableMarkets.value.find { it.id == mandiId }
    val vehicle = availableVehicles.find { it.id == vehicleId }

    if (market == null || vehicle == null) return

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.transport_summary)) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.back))
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Summary", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Text("Destination: ${market.name}", fontWeight = FontWeight.Medium)
                    Text(stringResource(R.string.quantity_val_quintals, quantity.toString()))
                    Text("Road Distance: ${"%.1f".format(distanceKm)} km")
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Text("Vehicle Type: ${vehicle.name}", fontWeight = FontWeight.Medium)
                    Text(stringResource(R.string.vehicle_capacity_quintals, vehicle.capacityQuintals))
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Text("Estimated Fare", style = MaterialTheme.typography.labelLarge)
                    Text("₹$fare", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                }
            }
            
            Spacer(modifier = Modifier.weight(1f))
            
            Button(
                onClick = {
                    val requestId = "KS-TR-${UUID.randomUUID().toString().substring(0, 6).uppercase()}"
                    navController.navigate("transport_status/$requestId") {
                        popUpTo("farmer_home")
                    }
                },
                modifier = Modifier.fillMaxWidth().height(56.dp)
            ) {
                Text(stringResource(R.string.request_transport), style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}
