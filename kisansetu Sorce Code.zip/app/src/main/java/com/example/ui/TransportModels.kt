package com.example.ui

data class VehicleType(
    val id: String,
    val name: String,
    val capacityQuintals: Int,
    val baseFare: Int,
    val ratePerKm: Int,
    val loadingCharge: Int,
    val isAvailable: Boolean = true
)

val availableVehicles = listOf(
    VehicleType("v1", "Pickup (Demo)", 15, 300, 30, 0),
    VehicleType("v2", "Mini Truck (Demo)", 30, 500, 40, 100),
    VehicleType("v3", "Light Commercial Vehicle (Demo)", 50, 800, 50, 200),
    VehicleType("v4", "Truck (Demo)", 150, 1500, 70, 500)
)

data class TransportRequest(
    val requestId: String,
    val crop: String,
    val quantityQuintals: Int,
    val destinationMandiId: String,
    val vehicleTypeId: String,
    val roadDistanceKm: Double,
    val travelTimeMinutes: String,
    val estimatedFare: Int,
    val status: TransportStatus,
    val createdAt: Long = System.currentTimeMillis()
)

enum class TransportStatus(val displayName: String) {
    SEARCHING("Searching for Transport"),
    TRANSPORTER_ASSIGNED("Transporter Assigned"),
    VEHICLE_ON_THE_WAY("Vehicle On The Way"),
    CROP_PICKED_UP("Crop Picked Up"),
    REACHED_MANDI("Reached Mandi"),
    COMPLETED("Completed"),
    CANCELLED("Cancelled")
}

fun calculateEstimatedFare(vehicle: VehicleType, distanceKm: Double): Int {
    return vehicle.baseFare + (distanceKm * vehicle.ratePerKm).toInt() + vehicle.loadingCharge
}

fun getBestSuitableVehicle(quantityQuintals: Int, distanceKm: Double): Pair<VehicleType, Int>? {
    val suitableVehicles = availableVehicles
        .filter { it.isAvailable && it.capacityQuintals >= quantityQuintals }
    
    if (suitableVehicles.isEmpty()) return null
    
    return suitableVehicles
        .map { it to calculateEstimatedFare(it, distanceKm) }
        .minByOrNull { it.second }
}
