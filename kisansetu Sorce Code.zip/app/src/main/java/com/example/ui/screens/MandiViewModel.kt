package com.example.ui.screens

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class MandiProfile(
    val mandiName: String,
    val mandiId: String,
    val ownerName: String,
    val address: String,
    val city: String,
    val contactNumber: String,
    val shopPhotoUri: String? = null,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val placeId: String? = null
)

data class SellRequest(
    val id: String,
    val cropName: String,
    val quantity: Int,
    val farmerName: String,
    val farmerLocation: String,
    val status: String // Pending, Accepted, Declined
)

class MandiViewModel : ViewModel() {
    private val _mandiProfile = MutableStateFlow<MandiProfile?>(null)
    val mandiProfile = _mandiProfile.asStateFlow()

    private val _sellRequests = MutableStateFlow<List<SellRequest>>(emptyList())
    val sellRequests = _sellRequests.asStateFlow()

    fun registerMandi(profile: MandiProfile) {
        _mandiProfile.value = profile
    }
    
    fun logout() {
        _mandiProfile.value = null
    }

    fun addSellRequest(request: SellRequest) {
        _sellRequests.update { listOf(request) + it }
    }

    fun updateSellRequestStatus(requestId: String, status: String) {
        _sellRequests.update { requests ->
            requests.map { if (it.id == requestId) it.copy(status = status) else it }
        }
    }
}
