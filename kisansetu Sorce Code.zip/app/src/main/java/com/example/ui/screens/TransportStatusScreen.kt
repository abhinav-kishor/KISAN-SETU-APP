package com.example.ui.screens

import androidx.compose.ui.res.stringResource

import com.example.R

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransportStatusScreen(navController: NavController, requestId: String) {
    // Mock status progression for demo
    var currentStep by remember { mutableStateOf(0) }
    
    val steps = listOf(
        "Searching for Transport",
        "Transporter Assigned",
        "Vehicle On The Way",
        "Crop Picked Up",
        "Reached Mandi",
        "Completed"
    )

    LaunchedEffect(Unit) {
        while(currentStep < steps.size - 1) {
            delay(3000)
            currentStep++
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.request_id, requestId)) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.back))
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            Text("Transport Status", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(32.dp))
            
            steps.forEachIndexed { index, stepName ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(bottom = 24.dp)
                ) {
                    if (index <= currentStep) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
                    } else {
                        Box(modifier = Modifier.size(32.dp).padding(4.dp)) {
                            CircularProgressIndicator(modifier = Modifier.fillMaxSize(), strokeWidth = 2.dp, color = Color.Gray)
                        }
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Text(
                        text = stepName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = if (index == currentStep) FontWeight.Bold else FontWeight.Normal,
                        color = if (index <= currentStep) MaterialTheme.colorScheme.onSurface else Color.Gray
                    )
                }
            }
            
            Spacer(modifier = Modifier.weight(1f))
            Button(
                onClick = { navController.navigate("farmer_home") { popUpTo("farmer_home") } },
                modifier = Modifier.fillMaxWidth().height(56.dp)
            ) {
                Text(stringResource(R.string.back_to_home))
            }
        }
    }
}
