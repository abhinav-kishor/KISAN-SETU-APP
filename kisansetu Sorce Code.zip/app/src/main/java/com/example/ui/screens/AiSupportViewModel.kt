package com.example.ui.screens

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.ui.AuthViewModel
import com.example.ui.UserState
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers

enum class CallState {
    IDLE, CALLING, CONNECTING, CONNECTED, LISTENING, AI_SPEAKING, ENDING, COMPLETED
}

class AiSupportViewModel(application: Application) : AndroidViewModel(application) {
    private val _callState = MutableStateFlow(CallState.IDLE)
    val callState = _callState.asStateFlow()

    private val voiceManager = VoiceManager(application)
    private val conversationHistory = mutableListOf<GeminiContent>()
    private var rawConversationLog = StringBuilder()

    private var authViewModel: AuthViewModel? = null
    private var farmerName = "Farmer"
    private var farmerPhone = ""
    
    private val systemPrompt = """
        You are 'KisanSetu AI Support', a natural-sounding voice assistant for Indian farmers.
        You must speak in simple Hindi/Hinglish (written in Latin script).
        Keep your responses SHORT, POLITE, and HELPFUL (1-2 sentences maximum).
        Do NOT sound like an IVR. Do NOT repeatedly ask the same question.
        Use "ji" naturally.
        If a farmer reports a problem (app, crop, mandi, price), listen and acknowledge it. 
        Offer a brief solution if possible, and tell them you are noting it down.
        Do not use markdown, emojis, or special characters because your text will be spoken via Text-To-Speech.
        Start the conversation by greeting them to KisanSetu Customer Support.
    """.trimIndent()

    init {
        voiceManager.onSpeechResult = { text ->
            handleUserSpeech(text)
        }
        voiceManager.onSpeechError = { error ->
            if (_callState.value == CallState.LISTENING) {
                _callState.value = CallState.CONNECTED
            }
        }
        
        conversationHistory.add(GeminiContent(role = "user", parts = listOf(Part(text = "Hello, please start the conversation."))))
    }

    fun setAuthViewModel(vm: AuthViewModel) {
        authViewModel = vm
        val state = vm.userState.value
        if (state is UserState.SignedIn) {
            farmerName = state.displayName.ifBlank { "Farmer" }
            farmerPhone = state.phoneNumber.ifBlank { "Unknown" }
        }
    }

    fun startCall() {
        if (_callState.value != CallState.IDLE) return
        _callState.value = CallState.CALLING
        
        viewModelScope.launch {
            delay(1500)
            _callState.value = CallState.CONNECTING
            delay(1000)
            _callState.value = CallState.CONNECTED
            
            getAiResponse("Hello, please start the conversation. My name is $farmerName.")
        }
    }
    
    fun toggleMicrophone() {
        if (_callState.value == CallState.CONNECTED || _callState.value == CallState.AI_SPEAKING) {
            voiceManager.tts?.stop()
            _callState.value = CallState.LISTENING
            voiceManager.startListening()
        } else if (_callState.value == CallState.LISTENING) {
            voiceManager.stopListening()
            _callState.value = CallState.CONNECTED
        }
    }

    private fun handleUserSpeech(text: String) {
        if (text.isBlank()) return
        _callState.value = CallState.CONNECTED
        
        rawConversationLog.append("Farmer: $text\n")
        conversationHistory.add(GeminiContent(role = "user", parts = listOf(Part(text = text))))
        
        getAiResponse(text)
    }

    private fun getAiResponse(userText: String) {
        _callState.value = CallState.AI_SPEAKING
        viewModelScope.launch {
            try {
                val apiKey = BuildConfig.GEMINI_API_KEY
                if (apiKey.isBlank() || apiKey == "YOUR_GEMINI_API_KEY") {
                    speakText("API key error.")
                    return@launch
                }
                
                val request = GenerateContentRequest(
                    contents = conversationHistory,
                    systemInstruction = GeminiContent(parts = listOf(Part(text = systemPrompt))),
                    generationConfig = GenerationConfig(temperature = 0.7f)
                )
                
                val response = GeminiApiClient.service.generateContent(apiKey, request)
                val replyText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: "Ji, kripya dobara bataiye."
                
                conversationHistory.add(GeminiContent(role = "model", parts = listOf(Part(text = replyText))))
                rawConversationLog.append("AI: $replyText\n")
                
                speakText(replyText)
            } catch (e: Exception) {
                Log.e("AiSupport", "Gemini error", e)
                speakText("Network mein thodi problem hai. Kripya dobara try karein.")
            }
        }
    }

    private fun speakText(text: String) {
        if (_callState.value == CallState.ENDING || _callState.value == CallState.COMPLETED) return
        
        voiceManager.speak("support_msg", text)
        _callState.value = CallState.AI_SPEAKING
        
        viewModelScope.launch {
            delay(1000)
            while(voiceManager.playingMessageId.value != null && _callState.value == CallState.AI_SPEAKING) {
                delay(500)
            }
            if (_callState.value == CallState.AI_SPEAKING) {
                _callState.value = CallState.CONNECTED
            }
        }
    }

    fun endCall() {
        voiceManager.stopListening()
        voiceManager.tts?.stop()
        _callState.value = CallState.ENDING
        
        viewModelScope.launch {
            if (rawConversationLog.length > 50) {
                extractAndLogComplaint()
            } else {
                _callState.value = CallState.COMPLETED
            }
        }
    }

    private suspend fun extractAndLogComplaint() {
        try {
            val apiKey = BuildConfig.GEMINI_API_KEY
            if (apiKey.isBlank() || apiKey == "YOUR_GEMINI_API_KEY") {
                _callState.value = CallState.COMPLETED
                return
            }

            val extractionPrompt = """
                Analyze the following customer support conversation between a Farmer and AI.
                Determine if there is a meaningful complaint, problem, feedback, or support request.
                If YES, return a JSON object with these exact keys:
                {
                  "isComplaint": true,
                  "category": "Crop Issue / Mandi Issue / App Issue / etc.",
                  "crop": "crop name if mentioned, else N/A",
                  "complaint": "brief description of the problem",
                  "summary": "1 sentence summary",
                  "aiResponse": "what the AI suggested"
                }
                If NO (just small talk, thank you, or no issue), return:
                {
                  "isComplaint": false
                }
                
                Conversation:
                $rawConversationLog
            """.trimIndent()

            val request = GenerateContentRequest(
                contents = listOf(GeminiContent(role = "user", parts = listOf(Part(text = extractionPrompt)))),
                generationConfig = GenerationConfig(temperature = 0.1f, responseMimeType = "application/json")
            )
            
            val response = GeminiApiClient.service.generateContent(apiKey, request)
            val jsonString = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: ""
            
            if (jsonString.isNotBlank()) {
                val json = JSONObject(jsonString)
                if (json.optBoolean("isComplaint", false)) {
                    sendToGoogleSheets(json)
                    return 
                }
            }
            _callState.value = CallState.COMPLETED
        } catch (e: Exception) {
            Log.e("AiSupport", "Extraction error", e)
            _callState.value = CallState.COMPLETED
        }
    }

    private fun sendToGoogleSheets(complaintJson: JSONObject) {
        val payload = JSONObject().apply {
            put("farmerName", farmerName)
            put("phone", farmerPhone)
            put("crop", complaintJson.optString("crop", "N/A"))
            put("category", complaintJson.optString("category", "General Support"))
            put("complaint", complaintJson.optString("complaint", "Unknown"))
            put("summary", complaintJson.optString("summary", "No summary"))
            put("aiResponse", complaintJson.optString("aiResponse", "N/A"))
            put("location", "N/A")
            put("status", "New")
            put("sessionId", "KS-${System.currentTimeMillis()}")
        }
        
        val scriptUrl = "https://script.google.com/macros/s/AKfycbz_placeholder/exec"
        
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val url = URL(scriptUrl)
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.setRequestProperty("Content-Type", "application/json; utf-8")
                conn.setRequestProperty("Accept", "application/json")
                conn.doOutput = true
                
                conn.outputStream.use { os ->
                    val input = payload.toString().toByteArray(Charsets.UTF_8)
                    os.write(input, 0, input.size)
                }
                
                val code = conn.responseCode
                Log.d("AiSupport", "Sheets response code: $code")
            } catch (e: Exception) {
                Log.e("AiSupport", "Failed to send to Sheets", e)
            } finally {
                _callState.value = CallState.COMPLETED
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        voiceManager.cleanup()
    }
}
