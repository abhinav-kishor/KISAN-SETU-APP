package com.example.ui.screens

import androidx.compose.ui.res.stringResource

import com.example.R

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.ui.MarketRepository
import com.example.ui.availableVehicles
import com.example.ui.calculateEstimatedFare
import kotlinx.coroutines.flow.map

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransportOptionsScreen(navController: NavController, mandiId: String, quantity: Int, mapViewModel: MapViewModel) {
    val distances by mapViewModel.routeDistancesKm.collectAsState()
    val durations by mapViewModel.routeDurations.collectAsState()
    val isLoading by mapViewModel.isLoading.collectAsState()
    val error by mapViewModel.locationError.collectAsState()

    val market = MarketRepository.availableMarkets.value.find { it.id == mandiId }
    val distanceKm = distances[mandiId] ?: market?.distanceKm?.toDouble() ?: 0.0
    val durationStr = durations[mandiId] ?: "Unknown time"

    val suitableVehicles = availableVehicles.filter { it.isAvailable && it.capacityQuintals >= quantity }
        .map { it to calculateEstimatedFare(it, distanceKm) }
        .sortedBy { it.second }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.transport_options)) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.back))
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            if (error != null) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
                ) {
                    Text(
                        text = error ?: "",
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }

            if (suitableVehicles.isEmpty()) {
                Text("No suitable vehicle is available for this quantity.", style = MaterialTheme.typography.bodyLarge)
            } else {
                suitableVehicles.forEachIndexed { index, (vehicle, fare) ->
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        onClick = {
                            navController.navigate("transport_details/${mandiId}/${vehicle.id}/$quantity/$distanceKm/$fare")
                        }
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            if (index == 0) {
                                Surface(
                                    color = MaterialTheme.colorScheme.primary,
                                    shape = MaterialTheme.shapes.small,
                                    modifier = Modifier.padding(bottom = 8.dp)
                                ) {
                                    Text(
                                        text = stringResource(R.string.recommended_badge),
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onPrimary,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Text(vehicle.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(stringResource(R.string.capacity_quintals, vehicle.capacityQuintals))
                            Text("Road Distance: ${"%.1f".format(distanceKm)} km")
                            Text(stringResource(R.string.travel_time_val, durationStr))
                            Spacer(modifier = Modifier.height(16.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("Estimated Fare", style = MaterialTheme.typography.labelMedium)
                                    Text("₹$fare", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                }
                                Button(onClick = { navController.navigate("transport_details/${mandiId}/${vehicle.id}/$quantity/$distanceKm/$fare") }) {
                                    Text(stringResource(R.string.select))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
