package com.example.ui.screens

import com.example.R

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.ui.Market
import com.example.ui.MarketCalculation
import com.example.ui.MarketRepository
import com.example.ui.calculateMarketReturns
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ChatMessage(
    val id: String,
    val text: String,
    val isFromUser: Boolean,
    val isLoading: Boolean = false,
    val recommendedMarketId: String? = null,
    val transportMandiId: String? = null
)

class ChatViewModel : ViewModel() {
    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages = _messages.asStateFlow()
    
    private val _isChatOpen = MutableStateFlow(false)
    val isChatOpen = _isChatOpen.asStateFlow()
    
    private val conversationHistory = mutableListOf<GeminiContent>()

    init {
        _messages.value = listOf(
            ChatMessage(
                id = "welcome",
                text = "Namaste! 👋\nMain Kisan Sahayak hoon.\n\nAap mujhse Hindi, Hinglish ya English mein baat kar sakte hain.\n\nMain aapko mandi prices samajhne, market compare karne aur behtar mandi choose karne mein help kar sakta hoon.",
                isFromUser = false
            )
        )
    }

    fun toggleChat(open: Boolean) {
        _isChatOpen.value = open
    }

    fun sendMessage(text: String, mapViewModel: MapViewModel, userLanguage: String = "English") {
        if (text.isBlank()) return
        
        val userMsgId = java.util.UUID.randomUUID().toString()
        val userMsg = ChatMessage(id = userMsgId, text = text, isFromUser = true)
        
        val loadingMsgId = java.util.UUID.randomUUID().toString()
        val loadingMsg = ChatMessage(id = loadingMsgId, text = "Kisan Sahayak is thinking...", isFromUser = false, isLoading = true)
        
        _messages.value = _messages.value + userMsg + loadingMsg
        
        conversationHistory.add(GeminiContent(role = "user", parts = listOf(Part(text = text))))
        
        viewModelScope.launch {
            try {
                // Get current market data context
                val routeDistancesKm = mapViewModel.routeDistancesKm.value
                val routeDurations = mapViewModel.routeDurations.value
                val calcs = calculateMarketReturns(
                    markets = MarketRepository.availableMarkets.value,
                    quantityQuintals = 10, // Defaulting to 10 if not specified by user
                    actualRouteDistancesKm = routeDistancesKm,
                    actualRouteDurations = routeDurations
                )
                
                val contextData = buildContextString(calcs)
                val systemPrompt = """
                    You are 'Kisan Sahayak', a conversational assistant for farmers on the KisanSetu app.
                    Your goal is to help them find the best mandi (market), understand prices, and calculate transport costs.
                    
                    CRITICAL: You MUST respond PRIMARILY in the user's selected app language: $userLanguage.
                    If $userLanguage is Hindi, respond primarily in Hindi (using Devanagari script).
                    If $userLanguage is Marathi, respond primarily in Marathi.
                    If $userLanguage is Bengali, respond primarily in Bengali.
                    If $userLanguage is Telugu, respond primarily in Telugu.
                    If the user speaks a different language, reply in their language, but prioritize $userLanguage.
                    Use simple, farmer-friendly language. Do not use complex technical terms.
                    
                    CRITICAL RULE:
                    You MUST use ONLY the following actual KisanSetu data for your answers.
                    DO NOT invent prices, distances, transport costs, or recommendations.
                    DO NOT hallucinate. If data is missing, say "Verified market data is currently unavailable."
                    
                    CURRENT DATA CONTEXT:
                    $contextData
                    
                    RECOMMENDATION RULES:
                    - Recommend the market with the HIGHEST Estimated Net Return.
                    - Explain why it is recommended based on the Net Return after Transport Cost.
                    - Format the recommendation clearly, e.g., Mandi Price, Quantity, Gross Value, Driving Distance, Estimated Transport Cost, Estimated Net Return.
                    - If the farmer asks about transport, recommend the best vehicle option available (based on quantity and actual distance). Use the actual transport fare calculation logic and clearly label "Estimated Transport Fare".

                    If a specific market is recommended in your answer, you can optionally include its ID inside brackets at the very end of your message like [RECOMMEND_MANDI:1] so the UI can show navigation buttons.
                    If the user wants to book transport, append [SHOW_TRANSPORT:1] where 1 is the Mandi ID.
                """.trimIndent()

                val request = GenerateContentRequest(
                    contents = conversationHistory,
                    systemInstruction = GeminiContent(parts = listOf(Part(text = systemPrompt))),
                    generationConfig = GenerationConfig(temperature = 0.7f)
                )

                val apiKey = BuildConfig.GEMINI_API_KEY
                if (apiKey.isBlank() || apiKey == "YOUR_GEMINI_API_KEY") {
                    _messages.value = _messages.value.filter { it.id != loadingMsgId } + 
                        ChatMessage(id = java.util.UUID.randomUUID().toString(), text = "API Key missing. Please set GEMINI_API_KEY in .env", isFromUser = false)
                    return@launch
                }
                
                val response = GeminiApiClient.service.generateContent(apiKey, request)
                val replyText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: "Sorry, I couldn't understand that."
                
                var finalReplyText = replyText
                var recommendedId: String? = null
                var transportId: String? = null
                
                val regex = Regex("""\[RECOMMEND_MANDI:(.+?)\]""")
                val match = regex.find(finalReplyText)
                if (match != null) {
                    recommendedId = match.groupValues[1].trim()
                    finalReplyText = finalReplyText.replace(regex, "").trim()
                }

                val tRegex = Regex("""\[SHOW_TRANSPORT:(.+?)\]""")
                val tMatch = tRegex.find(finalReplyText)
                if (tMatch != null) {
                    transportId = tMatch.groupValues[1].trim()
                    finalReplyText = finalReplyText.replace(tRegex, "").trim()
                }

                conversationHistory.add(GeminiContent(role = "model", parts = listOf(Part(text = finalReplyText))))
                
                _messages.value = _messages.value.filter { it.id != loadingMsgId } + 
                    ChatMessage(id = java.util.UUID.randomUUID().toString(), text = finalReplyText, isFromUser = false, recommendedMarketId = recommendedId, transportMandiId = transportId)
                
            } catch (e: Exception) {
                _messages.value = _messages.value.filter { it.id != loadingMsgId } + 
                    ChatMessage(id = java.util.UUID.randomUUID().toString(), text = "Sorry, Kisan Sahayak is temporarily unavailable. Please try again.", isFromUser = false)
            }
        }
    }
    
    private fun buildContextString(calcs: List<MarketCalculation>): String {
        return calcs.joinToString("\n\n") { calc ->
            val m = calc.market
            val dist = calc.actualDistanceKm?.let { "${"%.1f".format(it)} km (Actual)" } ?: "${m.distanceKm} km (Estimate)"
            """
            Market ID: ${m.id}
            Name: ${m.name}
            Price per Quintal: ₹${m.pricePerQuintal}
            Distance: $dist
            Travel Time: ${calc.actualDurationStr ?: "Unknown"}
            Transport Cost: ₹${calc.estTransport}
            Gross Value (10 quintals): ₹${calc.grossValue}
            Estimated Net Return: ₹${calc.netReturn}
            Is Recommended by System: ${calc.isRecommended}
            """.trimIndent()
        }
    }
}
