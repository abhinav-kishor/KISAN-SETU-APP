package com.example.ui.screens

import androidx.compose.ui.res.stringResource


import com.example.R

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.ui.Market
import com.example.ui.MarketRepository
import com.example.ui.calculateMarketReturns
import com.example.ui.MarketCalculation
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.Polyline
import com.google.maps.android.PolyUtil
import androidx.compose.ui.graphics.Color
import com.google.maps.android.compose.rememberCameraPositionState
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.LatLngBounds
import com.google.android.gms.maps.model.BitmapDescriptorFactory

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapScreen(navController: NavController, mapViewModel: MapViewModel = viewModel()) {
    val context = LocalContext.current
    
    val userLocation by mapViewModel.userLocation.collectAsState()
    val routeDistancesKm by mapViewModel.routeDistancesKm.collectAsState()
    val routeDurations by mapViewModel.routeDurations.collectAsState()
    val isLoading by mapViewModel.isLoading.collectAsState()
    val locationError by mapViewModel.locationError.collectAsState()
    
    var hasLocationPermission by remember { 
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        )
    }
    
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions(),
        onResult = { permissions ->
            hasLocationPermission = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                                    permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
            if (hasLocationPermission) {
                mapViewModel.loadLocationAndRoutes(context, MarketRepository.availableMarkets.value)
            }
        }
    )

    LaunchedEffect(userLocation, hasLocationPermission) {
        if (hasLocationPermission || userLocation != null) {
            mapViewModel.loadLocationAndRoutes(context, MarketRepository.availableMarkets.value)
        } else {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }

    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("All Mandis") }
    var selectedMarket by remember { mutableStateOf<Market?>(null) }
    
    val calcs = calculateMarketReturns(MarketRepository.availableMarkets.value, 10, actualRouteDistancesKm = routeDistancesKm, actualRouteDurations = routeDurations)
    val recommendedMarketCalc = calcs.find { it.isRecommended }

    val displayedMarkets = when (selectedFilter) {
        "Nearby" -> MarketRepository.availableMarkets.value.sortedBy { routeDistancesKm[it.id] ?: it.distanceKm.toDouble() }
        "Best Price" -> MarketRepository.availableMarkets.value.sortedByDescending { it.pricePerQuintal }
        "Best Return" -> calcs.sortedByDescending { it.netReturn }.map { it.market }
        else -> MarketRepository.availableMarkets.value
    }.filter {
        searchQuery.isBlank() || it.name.contains(searchQuery, ignoreCase = true)
    }

    var mapLoaded by remember { androidx.compose.runtime.mutableStateOf(false) }
    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(LatLng(28.6139, 77.2090), 8f) // Default India
    }

    LaunchedEffect(userLocation, displayedMarkets, mapLoaded) {
        if (mapLoaded) {
            if (displayedMarkets.isNotEmpty()) {
                val boundsBuilder = LatLngBounds.builder()
                userLocation?.let { boundsBuilder.include(it) }
                displayedMarkets.forEach { boundsBuilder.include(LatLng(it.latitude, it.longitude)) }
                try {
                    // Use a smaller padding (64px) to avoid pushing the map out of bounds on small screens
                    cameraPositionState.animate(CameraUpdateFactory.newLatLngBounds(boundsBuilder.build(), 64))
                } catch (e: Exception) {
                    // Ignore layout not ready
                }
            } else if (userLocation != null) {
                try {
                    cameraPositionState.animate(CameraUpdateFactory.newLatLngZoom(userLocation!!, 10f))
                } catch (e: Exception) {}
            }
        }
    }

    Scaffold(
        topBar = {
            Column(modifier = Modifier.background(MaterialTheme.colorScheme.primary)) {
                Text(
                    text = stringResource(R.string.kisansetu_map),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.padding(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 4.dp)
                )
                Text(
                    text = stringResource(R.string.find_nearby_mandis),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f),
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    placeholder = { Text(stringResource(R.string.search_mandi)) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = stringResource(R.string.search)) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                        disabledContainerColor = MaterialTheme.colorScheme.surface,
                    ),
                    shape = RoundedCornerShape(24.dp),
                    singleLine = true
                )
                LazyRow(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(listOf("All Mandis", "Nearby", "Best Price", "Best Return")) { filter ->
                        FilterChip(
                            selected = selectedFilter == filter,
                            onClick = { selectedFilter = filter },
                            label = { Text(filter) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.secondaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            
            GoogleMap(
                modifier = Modifier.fillMaxSize(),
                cameraPositionState = cameraPositionState,
                onMapLoaded = { mapLoaded = true }
            ) {
                userLocation?.let {
                    Marker(
                        state = MarkerState(position = it),
                        title = stringResource(R.string.your_location),
                        icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE)
                    )
                }

                displayedMarkets.forEach { market ->
                    val isRecommended = market.id == recommendedMarketCalc?.market?.id
                    Marker(
                        state = MarkerState(position = LatLng(market.latitude, market.longitude)),
                        title = market.name,
                        snippet = "₹${market.pricePerQuintal}/q",
                        icon = BitmapDescriptorFactory.defaultMarker(
                            if (isRecommended) BitmapDescriptorFactory.HUE_GREEN else BitmapDescriptorFactory.HUE_RED
                        ),
                        onClick = {
                            selectedMarket = market
                            false
                        }
                    )
                }
            
                // Draw polyline if a market is selected
                if (selectedMarket != null) {
                    val polyline = mapViewModel.routePolylines.collectAsState().value[selectedMarket!!.id]
                    if (polyline != null && polyline.isNotEmpty()) {
                        val decodedPath = remember(polyline) { PolyUtil.decode(polyline) }
                        Polyline(
                            points = decodedPath,
                            color = Color.Blue,
                            width = 12f
                        )
                    }
                } else if (recommendedMarketCalc != null) {
                    val polyline = mapViewModel.routePolylines.collectAsState().value[recommendedMarketCalc.market.id]
                    if (polyline != null && polyline.isNotEmpty()) {
                        val decodedPath = remember(polyline) { PolyUtil.decode(polyline) }
                        Polyline(
                            points = decodedPath,
                            color = Color.Blue,
                            width = 12f
                        )
                    }
                }
            }
            if (!hasLocationPermission && locationError != null) {
                Card(
                    modifier = Modifier.align(Alignment.TopCenter).padding(16.dp).fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(locationError ?: "Location access is needed to show nearby mandis.", color = MaterialTheme.colorScheme.onErrorContainer)
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(onClick = {
                            permissionLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                        }) {
                            Text(stringResource(R.string.retry_permission))
                        }
                    }
                }
            }

            if (isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.align(Alignment.Center)
                )
            }

            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(16.dp)
                    .fillMaxWidth()
            ) {
                if (selectedMarket != null) {
                    val calc = calcs.find { it.market.id == selectedMarket!!.id }
                    if (calc != null) {
                        MarketInfoCard(
                            calc = calc,
                            title = stringResource(R.string.selected_mandi),
                            onNavigate = { openGoogleMapsDirections(context, userLocation, LatLng(selectedMarket!!.latitude, selectedMarket!!.longitude)) },
                            onViewDetails = { navController.navigate("market_details/${selectedMarket!!.id}") },
                            onClose = { selectedMarket = null }
                        )
                    }
                } else if (recommendedMarketCalc != null) {
                    MarketInfoCard(
                        calc = recommendedMarketCalc,
                        title = stringResource(R.string.recommended_mandi),
                        onNavigate = { openGoogleMapsDirections(context, userLocation, LatLng(recommendedMarketCalc.market.latitude, recommendedMarketCalc.market.longitude)) },
                        onViewDetails = { navController.navigate("market_details/${recommendedMarketCalc.market.id}") },
                        onClose = null
                    )
                }
            }
        }
    }
}

@Composable
fun MarketInfoCard(
    calc: MarketCalculation,
    title: String,
    onNavigate: () -> Unit,
    onViewDetails: () -> Unit,
    onClose: (() -> Unit)?
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = MaterialTheme.shapes.large,
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                if (onClose != null) {
                    IconButton(onClick = onClose, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.Close, contentDescription = stringResource(R.string.close), modifier = Modifier.size(16.dp))
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(calc.market.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("₹${calc.market.pricePerQuintal}/q", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(4.dp))
            
            val distanceText = calc.actualDistanceKm?.let { "%.1f km".format(it) } ?: "${calc.market.distanceKm} km"
            Text("Road Distance: $distanceText", style = MaterialTheme.typography.bodyMedium)
            if (calc.actualDurationStr != null) {
                Text("Travel Time: ${calc.actualDurationStr}", style = MaterialTheme.typography.bodyMedium)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text("Estimated Net Return: ₹${calc.netReturn}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            
            Spacer(modifier = Modifier.height(16.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onViewDetails,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Text("View Market", color = MaterialTheme.colorScheme.onSurface)
                }
                Button(
                    onClick = onNavigate,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Navigation, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(stringResource(R.string.navigate))
                }
            }
        }
    }
}
