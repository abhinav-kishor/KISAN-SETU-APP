package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.mutableStateOf
import java.util.Locale

class VoiceManager(private val context: Context) {
    var tts: TextToSpeech? = null
    var speechRecognizer: SpeechRecognizer? = null
    
    val isListening = mutableStateOf(false)
    val playingMessageId = mutableStateOf<String?>(null)
    
    var onSpeechResult: ((String) -> Unit)? = null
    var onSpeechError: ((String) -> Unit)? = null

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        if (playingMessageId.value == utteranceId) {
                            playingMessageId.value = null
                        }
                    }
                    override fun onError(utteranceId: String?) {
                        if (playingMessageId.value == utteranceId) {
                            playingMessageId.value = null
                        }
                    }
                })
            }
        }
        
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)
            speechRecognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {
                    isListening.value = false
                }
                override fun onError(error: Int) {
                    isListening.value = false
                    onSpeechError?.invoke("Could not recognize speech. Please try again.")
                }
                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    if (!matches.isNullOrEmpty()) {
                        onSpeechResult?.invoke(matches[0])
                    }
                    isListening.value = false
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
    }

    fun startListening() {
        isListening.value = true
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().language)
        }
        try {
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            isListening.value = false
            onSpeechError?.invoke("Voice recognition not available on this device.")
        }
    }

    fun stopListening() {
        speechRecognizer?.stopListening()
        isListening.value = false
    }

    fun speak(messageId: String, text: String) {
        if (playingMessageId.value == messageId) {
            tts?.stop()
            playingMessageId.value = null
        } else {
            tts?.stop()
            val result = tts?.setLanguage(Locale.getDefault())
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale("en", "IN"))
            }
            val cleanText = text.replace(Regex("\\[.*?\\]"), "").replace("*", "")
            tts?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, null, messageId)
            playingMessageId.value = messageId
        }
    }

    fun cleanup() {
        tts?.stop()
        tts?.shutdown()
        speechRecognizer?.destroy()
    }
}
