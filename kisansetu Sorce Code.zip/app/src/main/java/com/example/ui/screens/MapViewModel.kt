package com.example.ui.screens

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.ui.Market
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import com.google.android.gms.maps.model.LatLng
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll

class MapViewModel : ViewModel() {
    private val _userLocation = MutableStateFlow<LatLng?>(null)
    val userLocation: StateFlow<LatLng?> = _userLocation.asStateFlow()

    private val _routeDistancesKm = MutableStateFlow<Map<String, Double>>(emptyMap())
    val routeDistancesKm: StateFlow<Map<String, Double>> = _routeDistancesKm.asStateFlow()

    private val _routeDurations = MutableStateFlow<Map<String, String>>(emptyMap())
    val routeDurations: StateFlow<Map<String, String>> = _routeDurations.asStateFlow()

    private val _routePolylines = MutableStateFlow<Map<String, String>>(emptyMap())
    val routePolylines: StateFlow<Map<String, String>> = _routePolylines.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading = _isLoading.asStateFlow()

    private val _locationError = MutableStateFlow<String?>(null)
    val locationError = _locationError.asStateFlow()

    fun setUserLocation(latLng: LatLng) {
        _userLocation.value = latLng
        _routePolylines.value = emptyMap() // Clear old routes to force recalculation
        _routeDistancesKm.value = emptyMap()
        _routeDurations.value = emptyMap()
    }

    fun loadLocationAndRoutes(context: Context, markets: List<Market>) {
        if (_isLoading.value) return // already loading
        viewModelScope.launch {
            _isLoading.value = true
            _locationError.value = null
            
            if (_userLocation.value != null) {
                // Use explicitly set location
                fetchRoutesForMarkets(_userLocation.value!!, markets)
            } else {
                val location = getCurrentLocation(context)
                if (location != null) {
                    val originLatLng = LatLng(location.latitude, location.longitude)
                    _userLocation.value = originLatLng
                    fetchRoutesForMarkets(originLatLng, markets)
                } else {
                    _locationError.value = "Location access is required to calculate the actual driving route and transport cost."
                    _isLoading.value = false
                }
            }
        }
    }

    private suspend fun fetchRoutesForMarkets(origin: LatLng, markets: List<Market>) {
        val apiKey = BuildConfig.GOOGLE_MAPS_API_KEY
        if (apiKey.isBlank() || apiKey == "YOUR_API_KEY_HERE") {
            _locationError.value = "Google Maps configuration is missing."
            _isLoading.value = false
            return
        }

        try {
            val fieldMask = "routes.distanceMeters,routes.duration,routes.polyline.encodedPolyline"
            
            val deferredRoutes = markets.map { market ->
                viewModelScope.async {
                    try {
                        val req = ComputeRoutesRequest(
                            origin = Waypoint(LocationObj(LatLngObj(origin.latitude, origin.longitude))),
                            destination = Waypoint(LocationObj(LatLngObj(market.latitude, market.longitude)))
                        )
                        val response = RoutesApiClient.service.computeRoutes(apiKey, fieldMask, req)
                        val route = response.routes?.firstOrNull()
                        if (route != null) {
                            val distKm = route.distanceMeters / 1000.0
                            val dur = route.duration // e.g. "3600s"
                            val durFormatted = formatDuration(dur)
                            Pair(market.id, Triple(distKm, durFormatted, route.polyline?.encodedPolyline ?: ""))
                        } else null
                    } catch (e: Exception) {
                        null
                    }
                }
            }

            val results = deferredRoutes.awaitAll().filterNotNull()
            
            val distances = mutableMapOf<String, Double>()
            val durations = mutableMapOf<String, String>()
            val polylines = mutableMapOf<String, String>()
            
            for (res in results) {
                distances[res.first] = res.second.first
                durations[res.first] = res.second.second
                polylines[res.first] = res.second.third
            }
            
            _routeDistancesKm.value = distances
            _routeDurations.value = durations
            _routePolylines.value = polylines
            
        } catch (e: Exception) {
            _locationError.value = "Unable to calculate the driving route right now."
        } finally {
            _isLoading.value = false
        }
    }

    private fun formatDuration(duration: String): String {
        val seconds = duration.replace("s", "").toLongOrNull() ?: return "Unknown time"
        val hours = seconds / 3600
        val minutes = (seconds % 3600) / 60
        return if (hours > 0) {
            "$hours hr $minutes min"
        } else {
            "$minutes min"
        }
    }
    
    fun resetError() {
        _locationError.value = null
    }
}
