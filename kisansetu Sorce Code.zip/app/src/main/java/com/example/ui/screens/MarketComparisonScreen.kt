package com.example.ui.screens

import com.example.R

import android.Manifest
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.ui.res.stringResource
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.ui.MarketRepository
import com.example.ui.calculateMarketReturns
import com.example.ui.MarketCalculation
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import com.google.accompanist.permissions.isGranted

@OptIn(ExperimentalMaterial3Api::class, ExperimentalPermissionsApi::class)
@Composable
fun MarketComparisonScreen(navController: NavController, quantity: Int, selectedCrop: String? = null, mapViewModel: MapViewModel = viewModel()) {
    val context = LocalContext.current
    val isLoading by mapViewModel.isLoading.collectAsState()
    val locationError by mapViewModel.locationError.collectAsState()
    val routeDistancesKm by mapViewModel.routeDistancesKm.collectAsState()
    val routeDurations by mapViewModel.routeDurations.collectAsState()
    val userLocation by mapViewModel.userLocation.collectAsState()

    val locationPermissionsState = rememberMultiplePermissionsState(
        permissions = listOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
    )

    LaunchedEffect(locationPermissionsState.allPermissionsGranted, userLocation) {
        if (locationPermissionsState.allPermissionsGranted || userLocation != null) {
            mapViewModel.loadLocationAndRoutes(context, MarketRepository.availableMarkets.value)
        }
    }

    val sortedMarkets = calculateMarketReturns(
        markets = MarketRepository.availableMarkets.value, 
        quantityQuintals = quantity,
        actualRouteDistancesKm = routeDistancesKm,
        actualRouteDurations = routeDurations,
        cropName = selectedCrop
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.compare_markets)) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground,
                    navigationIconContentColor = MaterialTheme.colorScheme.onBackground
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            if (!locationPermissionsState.allPermissionsGranted && userLocation == null) {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Location access is required to calculate the actual driving route and transport cost.", color = MaterialTheme.colorScheme.onErrorContainer)
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(onClick = { locationPermissionsState.launchMultiplePermissionRequest() }) {
                            Text(stringResource(R.string.grant_permission))
                        }
                    }
                }
            } else if (locationError != null) {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(locationError ?: "", color = MaterialTheme.colorScheme.onErrorContainer)
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(onClick = { mapViewModel.loadLocationAndRoutes(context, MarketRepository.availableMarkets.value) }) {
                            Text(stringResource(R.string.retry))
                        }
                    }
                }
            } else if (isLoading) {
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, modifier = Modifier.padding(bottom = 16.dp)) {
                    CircularProgressIndicator(modifier = Modifier.padding(end = 8.dp))
                    Text(stringResource(R.string.calculating_route))
                }
            }

            val cropDisplayName = if (!selectedCrop.isNullOrBlank()) selectedCrop else "Wheat"
            Text("Found ${sortedMarkets.size} markets for $cropDisplayName", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
            Spacer(modifier = Modifier.height(16.dp))
            LazyColumn {
                items(sortedMarkets) { calc ->
                    MarketCard(calc) {
                        if (selectedCrop.isNullOrBlank()) {
                            navController.navigate("mandi_overview/${calc.market.id}/$quantity")
                        } else {
                            val cropId = calc.market.crops.find { it.cropName.equals(selectedCrop.trim(), ignoreCase = true) }?.id
                            if (cropId != null) {
                                navController.navigate("crop_details/${calc.market.id}/$cropId/$quantity")
                            } else {
                                navController.navigate("mandi_overview/${calc.market.id}/$quantity")
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }
            }
        }
    }
}


@Composable
fun MarketCard(calc: MarketCalculation, onClick: () -> Unit) {
    val market = calc.market
    val isRecommended = calc.isRecommended
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (isRecommended) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.surface
        ),
        border = if (isRecommended) null else androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        shape = if (isRecommended) MaterialTheme.shapes.extraLarge else MaterialTheme.shapes.large,
        onClick = onClick
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text(
                    text = market.name,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = if (isRecommended) MaterialTheme.colorScheme.onSecondary else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )
                if (isRecommended) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                        shape = androidx.compose.foundation.shape.CircleShape
                    ) {
                        Text(stringResource(R.string.recommended_badge), modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp), color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    }
                }
            }
            if (isRecommended) {
                Spacer(modifier = Modifier.height(4.dp))
                Text("Highest estimated net return after transportation costs.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSecondary.copy(alpha = 0.8f))
            }
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Gross Value", style = MaterialTheme.typography.labelSmall, color = if (isRecommended) MaterialTheme.colorScheme.onSecondary.copy(alpha = 0.7f) else MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("₹${calc.grossValue}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = if (isRecommended) MaterialTheme.colorScheme.onSecondary else MaterialTheme.colorScheme.onSurface)
                }
                Column {
                    Text("Transport (-)", style = MaterialTheme.typography.labelSmall, color = if (isRecommended) MaterialTheme.colorScheme.onSecondary.copy(alpha = 0.7f) else MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("₹${calc.estTransport}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = if (isRecommended) MaterialTheme.colorScheme.onSecondary else MaterialTheme.colorScheme.onSurface)
                }
                Column {
                    Text("Est. Return", style = MaterialTheme.typography.labelSmall, color = if (isRecommended) MaterialTheme.colorScheme.onSecondary.copy(alpha = 0.7f) else MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("₹${calc.netReturn}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = if (isRecommended) MaterialTheme.colorScheme.onSecondary else MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}
