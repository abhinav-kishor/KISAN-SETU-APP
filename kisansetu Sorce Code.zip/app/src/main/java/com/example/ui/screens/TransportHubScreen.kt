package com.example.ui.screens

import androidx.compose.ui.res.stringResource

import com.example.R

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.ui.MarketRepository

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransportHubScreen(navController: NavController, mapViewModel: MapViewModel) {
    var crop by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("10") }
    var pickupLocation by remember { mutableStateOf("Current Location") }
    var selectedMandiId by remember { mutableStateOf(MarketRepository.availableMarkets.value.first().id) }

    val cropList = listOf("Wheat", "Rice", "Maize", "Tomato", "Potato", "Onion", "Cotton", "Soybean", "Mustard", "Gram", "Sugarcane", "Groundnut", "Bajra", "Jowar", "Barley")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            shape = MaterialTheme.shapes.extraLarge
        ) {
            Column(modifier = Modifier.padding(24.dp)) {
                Text(
                    text = stringResource(R.string.request_transport),
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Spacer(modifier = Modifier.height(24.dp))
                
                var expandedCrop by remember { mutableStateOf(false) }
                val filteredCrops = if (crop.isEmpty()) emptyList() else cropList.filter { it.startsWith(crop, ignoreCase = true) }.take(6)
                
                ExposedDropdownMenuBox(
                    expanded = expandedCrop,
                    onExpandedChange = { expandedCrop = it }
                ) {
                    OutlinedTextField(
                        value = crop,
                        onValueChange = { 
                             crop = it
                            expandedCrop = true
                        },
                        label = { Text(stringResource(R.string.crop_eg_wheat)) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(),
                        colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors()
                    )
                    ExposedDropdownMenu(
                        expanded = expandedCrop && crop.isNotEmpty(),
                        onDismissRequest = { expandedCrop = false }
                    ) {
                        if (filteredCrops.isEmpty()) {
                            DropdownMenuItem(
                                text = { Text("No matching crops found", color = MaterialTheme.colorScheme.onSurfaceVariant) },
                                onClick = { }
                            )
                        } else {
                            filteredCrops.forEach { selectionOption ->
                                DropdownMenuItem(
                                    text = { Text(selectionOption) },
                                    onClick = {
                                        crop = selectionOption
                                        expandedCrop = false
                                    }
                                )
                            }
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                OutlinedTextField(
                    value = quantity,
                    onValueChange = { quantity = it },
                    label = { Text(stringResource(R.string.quantity_quintals)) },
                    modifier = Modifier.fillMaxWidth()
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                OutlinedTextField(
                    value = pickupLocation,
                    onValueChange = { pickupLocation = it },
                    label = { Text(stringResource(R.string.pickup_location)) },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                var expandedMandi by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(
                    expanded = expandedMandi,
                    onExpandedChange = { expandedMandi = it }
                ) {
                    OutlinedTextField(
                        value = MarketRepository.availableMarkets.value.find { it.id == selectedMandiId }?.name ?: "",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text(stringResource(R.string.destination_mandi)) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(),
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedMandi) },
                        colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors()
                    )
                    ExposedDropdownMenu(
                        expanded = expandedMandi,
                        onDismissRequest = { expandedMandi = false }
                    ) {
                        MarketRepository.availableMarkets.value.forEach { mandi ->
                            DropdownMenuItem(
                                text = { Text(mandi.name) },
                                onClick = {
                                    selectedMandiId = mandi.id
                                    expandedMandi = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
                Button(
                    onClick = { 
                        val qty = quantity.toIntOrNull() ?: 10
                        navController.navigate("transport_options/$selectedMandiId/$qty")
                    },
                    modifier = Modifier.fillMaxWidth().height(56.dp)
                ) {
                    Text("Find Transport", style = MaterialTheme.typography.titleMedium)
                }
            }
        }
    }
}
