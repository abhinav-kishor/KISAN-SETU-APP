package com.example.ui.screens

import androidx.compose.ui.res.stringResource


import com.example.R

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.ui.CropListing
import com.example.ui.Market
import com.example.ui.MarketRepository
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MandiDashboardScreen(navController: NavController, mandiViewModel: MandiViewModel) {
    val mandiProfile by mandiViewModel.mandiProfile.collectAsState()
    val availableMarkets by MarketRepository.availableMarkets.collectAsState()
    val sellRequests by mandiViewModel.sellRequests.collectAsState()
    
    // Find market associated with this mandi or create one
    var market = availableMarkets.find { it.id == mandiProfile?.mandiId }
    
    LaunchedEffect(mandiProfile) {
        if (mandiProfile != null && market == null) {
            val newMarket = Market(
                id = mandiProfile!!.mandiId,
                name = mandiProfile!!.mandiName,
                pricePerQuintal = 0,
                distanceKm = 10,
                latitude = 28.0,
                longitude = 77.0,
                crops = emptyList()
            )
            MarketRepository.addMarket(newMarket)
        }
    }

    var showAddCropDialog by remember { mutableStateOf(false) }
    var showNotificationsDialog by remember { mutableStateOf(false) }
    var cropToEdit by remember { mutableStateOf<CropListing?>(null) }
    
    val pendingRequests = sellRequests.count { it.status == "Pending" }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(mandiProfile?.mandiName ?: "Mandi Dashboard") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    actionIconContentColor = MaterialTheme.colorScheme.onPrimary
                ),
                actions = {
                    Box {
                        IconButton(onClick = { showNotificationsDialog = true }) {
                            Icon(Icons.Default.Notifications, contentDescription = stringResource(R.string.notifications))
                        }
                        if (pendingRequests > 0) {
                            Badge(
                                modifier = Modifier.align(Alignment.TopEnd).padding(4.dp),
                                containerColor = MaterialTheme.colorScheme.error
                            ) {
                                Text("$pendingRequests")
                            }
                        }
                    }
                    IconButton(onClick = { }) {
                        Icon(Icons.Default.Person, contentDescription = stringResource(R.string.profile))
                    }
                    IconButton(onClick = {
                        mandiViewModel.logout()
                        navController.navigate("role_selection") {
                            popUpTo(0)
                        }
                    }) {
                        Icon(Icons.Default.ExitToApp, contentDescription = stringResource(R.string.logout))
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddCropDialog = true }, containerColor = MaterialTheme.colorScheme.primary) {
                Icon(Icons.Default.Add, contentDescription = stringResource(R.string.add_crop), tint = MaterialTheme.colorScheme.onPrimary)
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            Text("Market Listings", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(16.dp))

            if (market?.crops.isNullOrEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No crops listed. Click + to add.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn {
                    items(market!!.crops) { crop ->
                        CropCard(crop = crop, onEdit = { cropToEdit = crop })
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }
            }
        }

        if (showAddCropDialog || cropToEdit != null) {
            AddEditCropDialog(
                cropToEdit = cropToEdit,
                onDismiss = {
                    showAddCropDialog = false
                    cropToEdit = null
                },
                onSave = { name, price, demand ->
                    val newCrop = CropListing(
                        id = cropToEdit?.id ?: UUID.randomUUID().toString(),
                        cropName = name,
                        pricePerQuintal = price.toIntOrNull() ?: 0,
                        demand = demand
                    )
                    
                    market?.let { currentMarket ->
                        val updatedCrops = if (cropToEdit != null) {
                            currentMarket.crops.map { if (it.id == newCrop.id) newCrop else it }
                        } else {
                            currentMarket.crops + newCrop
                        }
                        MarketRepository.updateMarket(currentMarket.id, updatedCrops)
                    }
                    
                    showAddCropDialog = false
                    cropToEdit = null
                }
            )
        }
        
        if (showNotificationsDialog) {
            NotificationsDialog(
                requests = sellRequests,
                onDismiss = { showNotificationsDialog = false },
                onAccept = { id -> mandiViewModel.updateSellRequestStatus(id, "Accepted") },
                onDecline = { id -> mandiViewModel.updateSellRequestStatus(id, "Declined") }
            )
        }
    }
}

@Composable
fun CropCard(crop: CropListing, onEdit: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(crop.cropName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                IconButton(onClick = onEdit, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Default.Edit, contentDescription = stringResource(R.string.edit), tint = MaterialTheme.colorScheme.primary)
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text("Price: ₹${crop.pricePerQuintal} / quintal", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(4.dp))
            Text("Demand: ${crop.demand}", style = MaterialTheme.typography.bodyMedium)
            Spacer(modifier = Modifier.height(8.dp))
            Text("Last updated: just now", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun AddEditCropDialog(
    cropToEdit: CropListing?,
    onDismiss: () -> Unit,
    onSave: (name: String, price: String, demand: String) -> Unit
) {
    var name by remember { mutableStateOf(cropToEdit?.cropName ?: "") }
    var price by remember { mutableStateOf(cropToEdit?.pricePerQuintal?.toString() ?: "") }
    var demand by remember { mutableStateOf(cropToEdit?.demand ?: "Normal") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (cropToEdit != null) "Edit Crop" else stringResource(R.string.add_crop)) },
        text = {
            Column {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text(stringResource(R.string.crop_name)) }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(value = price, onValueChange = { price = it }, label = { Text(stringResource(R.string.price_per_quintal)) }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(value = demand, onValueChange = { demand = it }, label = { Text(stringResource(R.string.demand_high_normal_low)) }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            Button(onClick = { onSave(name, price, demand) }) {
                Text(if (cropToEdit != null) "Update" else "Add")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.cancel))
            }
        }
    )
}

@Composable
fun NotificationsDialog(
    requests: List<SellRequest>,
    onDismiss: () -> Unit,
    onAccept: (String) -> Unit,
    onDecline: (String) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.mandi_notifications)) },
        text = {
            if (requests.isEmpty()) {
                Text(stringResource(R.string.no_notifications))
            } else {
                LazyColumn {
                    items(requests) { req ->
                        Card(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("NEW SELL REQUEST", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("Crop: ${req.cropName} (${req.quantity} Quintals)", fontWeight = FontWeight.Bold)
                                Text(stringResource(R.string.farmer_name, req.farmerName))
                                Text(stringResource(R.string.location_name, req.farmerLocation))
                                Spacer(modifier = Modifier.height(8.dp))
                                
                                if (req.status == "Pending") {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(onClick = { onAccept(req.id) }, colors = ButtonDefaults.buttonColors(containerColor = androidx.compose.ui.graphics.Color(0xFF4CAF50))) {
                                            Text(stringResource(R.string.accept))
                                        }
                                        OutlinedButton(onClick = { onDecline(req.id) }) {
                                            Text("Decline", color = MaterialTheme.colorScheme.error)
                                        }
                                    }
                                } else {
                                    Text("Status: ${req.status}", fontWeight = FontWeight.Bold, color = if (req.status == "Accepted") androidx.compose.ui.graphics.Color(0xFF4CAF50) else MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.close)) }
        }
    )
}
