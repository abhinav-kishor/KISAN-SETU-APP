package com.example.ui.screens

import androidx.compose.ui.res.stringResource


import com.example.R

import android.Manifest
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.ui.MarketRepository
import com.google.android.gms.maps.model.LatLng
import kotlinx.coroutines.launch

@Composable
fun KisanSahayakChatPanel(
    chatViewModel: ChatViewModel,
    mapViewModel: MapViewModel,
    navController: NavController,
    onClose: () -> Unit
) {
    val messages by chatViewModel.messages.collectAsState()
    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current
    val prefs = context.getSharedPreferences("settings", android.content.Context.MODE_PRIVATE)
    val langCode = prefs.getString("language", "en") ?: "en"
    val langName = when (langCode) {
        "hi" -> "Hindi"
        "mr" -> "Marathi"
        "bn" -> "Bengali"
        "te" -> "Telugu"
        else -> "English"
    }
    
    val voiceManager = remember { VoiceManager(context) }
    
    DisposableEffect(context) {
        voiceManager.onSpeechResult = { result ->
            inputText = result
        }
        voiceManager.onSpeechError = { error ->
            Toast.makeText(context, error, Toast.LENGTH_SHORT).show()
        }
        onDispose {
            voiceManager.cleanup()
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { isGranted ->
            if (isGranted) {
                voiceManager.startListening()
            } else {
                Toast.makeText(context, context.getString(R.string.mic_permission_required), Toast.LENGTH_SHORT).show()
            }
        }
    )

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight(0.9f)
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primary)
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(stringResource(R.string.kisan_sahayak), color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("Your smart farming & market assistant", color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f), style = MaterialTheme.typography.bodySmall)
                Text("🌐 Hindi | Hinglish | English", color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f), style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 4.dp))
            }
            IconButton(onClick = onClose) {
                Icon(Icons.Default.Close, contentDescription = stringResource(R.string.close), tint = MaterialTheme.colorScheme.onPrimary)
            }
        }

        // Quick Actions
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val quickActions = listOf(
                "🌾 Meri fasal ke liye mandi batao",
                "💰 Mandi ka bhav batao",
                "📊 Markets compare karo",
                "🚚 Transport cost batao",
                "❓ KisanSetu kaise use karein?"
            )
            items(quickActions) { action ->
                SuggestionChip(
                    onClick = { chatViewModel.sendMessage(action, mapViewModel, langName) },
                    label = { Text(action) }
                )
            }
        }

        HorizontalDivider()

        // Chat Messages
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { Spacer(modifier = Modifier.height(8.dp)) }
            items(messages) { msg ->
                ChatBubble(msg, navController, mapViewModel, voiceManager, onClose)
            }
            item { Spacer(modifier = Modifier.height(8.dp)) }
        }

        // Input Area
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                .padding(8.dp)
        ) {
            if (voiceManager.isListening.value) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Listening...", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(onClick = { voiceManager.stopListening() }) {
                        Icon(Icons.Default.Stop, contentDescription = stringResource(R.string.stop_listening), tint = MaterialTheme.colorScheme.error)
                    }
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        if (voiceManager.isListening.value) {
                            voiceManager.stopListening()
                        } else {
                            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    },
                    modifier = Modifier.padding(end = 4.dp)
                ) {
                    Icon(
                        imageVector = if (voiceManager.isListening.value) Icons.Default.Stop else Icons.Default.Mic,
                        contentDescription = stringResource(R.string.speak),
                        tint = if (voiceManager.isListening.value) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                    )
                }

                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    modifier = Modifier
                        .weight(1f)
                        .padding(end = 8.dp),
                    placeholder = { Text(stringResource(R.string.apna_sawaal)) },
                    shape = RoundedCornerShape(24.dp),
                    maxLines = 3
                )
                
                FloatingActionButton(
                    onClick = {
                        if (inputText.isNotBlank()) {
                            chatViewModel.sendMessage(inputText, mapViewModel, langName)
                            inputText = ""
                        }
                    },
                    modifier = Modifier.size(48.dp),
                    containerColor = MaterialTheme.colorScheme.primary,
                    elevation = FloatingActionButtonDefaults.elevation(0.dp)
                ) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = stringResource(R.string.send), tint = MaterialTheme.colorScheme.onPrimary)
                }
            }
        }
    }
}

@Composable
fun ChatBubble(
    message: ChatMessage,
    navController: NavController,
    mapViewModel: MapViewModel,
    voiceManager: VoiceManager,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val alignment = if (message.isFromUser) Alignment.CenterEnd else Alignment.CenterStart
    val bgColor = if (message.isFromUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.secondaryContainer
    val textColor = if (message.isFromUser) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSecondaryContainer
    val shape = if (message.isFromUser) {
        RoundedCornerShape(16.dp, 16.dp, 0.dp, 16.dp)
    } else {
        RoundedCornerShape(16.dp, 16.dp, 16.dp, 0.dp)
    }

    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = alignment) {
        Column(horizontalAlignment = if (message.isFromUser) Alignment.End else Alignment.Start) {
            Box(
                modifier = Modifier
                    .widthIn(max = 280.dp)
                    .clip(shape)
                    .background(bgColor)
                    .padding(12.dp)
            ) {
                Column {
                    if (message.isLoading) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = textColor, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(message.text, color = textColor)
                        }
                    } else {
                        Text(message.text, color = textColor)
                        
                        if (!message.isFromUser) {
                            val isPlaying = voiceManager.playingMessageId.value == message.id
                            Spacer(modifier = Modifier.height(8.dp))
                            FilledTonalButton(
                                onClick = { voiceManager.speak(message.id, message.text) },
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                modifier = Modifier.height(32.dp)
                            ) {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Default.Stop else Icons.Default.VolumeUp,
                                    contentDescription = if (isPlaying) "Stop" else "Listen",
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (isPlaying) "Stop" else "Listen", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
            
            if (message.recommendedMarketId != null || message.transportMandiId != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (message.recommendedMarketId != null) {
                        Button(
                            onClick = {
                                onClose()
                                navController.navigate("mandi_overview/${message.recommendedMarketId}/10")
                            },
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.height(36.dp)
                        ) {
                            Text("View Market", style = MaterialTheme.typography.labelSmall)
                        }
                        
                        Button(
                            onClick = {
                                val market = MarketRepository.availableMarkets.value.find { it.id == message.recommendedMarketId }
                                if (market != null) {
                                    val userLoc = mapViewModel.userLocation.value
                                    openGoogleMapsDirections(context, userLoc, LatLng(market.latitude, market.longitude))
                                }
                            },
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.height(36.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary)
                        ) {
                            Icon(Icons.Default.Navigation, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Start Nav", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                    if (message.transportMandiId != null) {
                        Button(
                            onClick = {
                                onClose()
                                // Defaulting quantity to 10 for chatbot request
                                navController.navigate("transport_options/${message.transportMandiId}/10")
                            },
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.height(36.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                        ) {
                            Icon(Icons.Default.LocalShipping, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Find Transport", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
    }
}
