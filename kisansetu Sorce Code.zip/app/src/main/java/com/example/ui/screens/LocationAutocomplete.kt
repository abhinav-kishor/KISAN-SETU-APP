package com.example.ui.screens

import android.content.Context
import android.util.Log
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.res.stringResource
import com.example.R
import androidx.compose.ui.unit.dp
import com.example.BuildConfig
import com.google.android.gms.maps.model.LatLng
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.model.AutocompleteSessionToken
import com.google.android.libraries.places.api.model.Place
import com.google.android.libraries.places.api.net.FetchPlaceRequest
import com.google.android.libraries.places.api.net.FindAutocompletePredictionsRequest
import com.google.android.libraries.places.api.net.PlacesClient
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class AutocompleteResult(
    val placeId: String,
    val primaryText: String,
    val secondaryText: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LocationAutocomplete(
    location: String,
    onLocationChange: (String) -> Unit,
    onPlaceSelected: (LatLng?, String?, String?) -> Unit, // LatLng, PlaceId, FormattedAddress
    modifier: Modifier = Modifier,
    label: String = "Location"
) {
    val context = LocalContext.current
    var isInitialized by remember { mutableStateOf(false) }
    var placesClient by remember { mutableStateOf<PlacesClient?>(null) }
    
    LaunchedEffect(Unit) {
        if (!Places.isInitialized()) {
            Places.initializeWithNewPlacesApiEnabled(context.applicationContext, BuildConfig.GOOGLE_MAPS_API_KEY)
        }
        placesClient = Places.createClient(context)
        isInitialized = true
    }

    var expanded by remember { mutableStateOf(false) }
    var predictions by remember { mutableStateOf<List<AutocompleteResult>>(emptyList()) }
    var isSearching by remember { mutableStateOf(false) }
    var searchError by remember { mutableStateOf<String?>(null) }
    
    val coroutineScope = rememberCoroutineScope()
    var searchJob by remember { mutableStateOf<Job?>(null) }

    val sessionToken = remember { AutocompleteSessionToken.newInstance() }

    Column(modifier = modifier) {
        OutlinedTextField(
            value = location,
            onValueChange = { newValue ->
                onLocationChange(newValue)
                expanded = true
                
                searchJob?.cancel()
                searchJob = coroutineScope.launch {
                    delay(300) // Debounce
                    if (newValue.length > 1 && placesClient != null) {
                        isSearching = true
                        searchError = null
                        val request = FindAutocompletePredictionsRequest.builder()
                            .setSessionToken(sessionToken)
                            .setQuery(newValue)
                            .build()
                        
                        placesClient?.findAutocompletePredictions(request)
                            ?.addOnSuccessListener { response ->
                                predictions = response.autocompletePredictions.map {
                                    AutocompleteResult(
                                        it.placeId,
                                        it.getPrimaryText(null).toString(),
                                        it.getSecondaryText(null).toString()
                                    )
                                }
                                isSearching = false
                            }
                            ?.addOnFailureListener { exception ->
                                val apiException = exception as? com.google.android.gms.common.api.ApiException
                                val statusCode = apiException?.statusCode
                                val statusMessage = apiException?.status?.statusMessage
                                val errorMsg = "Places API Error: $statusCode - ${statusMessage ?: exception.message}"
                                Log.e("Places", errorMsg, exception)
                                searchError = errorMsg
                                predictions = emptyList()
                                isSearching = false
                            }
                    } else {
                        predictions = emptyList()
                        isSearching = false
                    }
                }
            },
            label = { Text(label) },
            modifier = Modifier
                .fillMaxWidth()
                .onFocusChanged { focusState ->
                    if (!focusState.isFocused) {
                        // Delay hiding so clicks on items can register
                        coroutineScope.launch {
                            delay(200)
                            expanded = false
                        }
                    }
                },
            singleLine = true
        )

        if (expanded && location.length > 1) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                if (isSearching) {
                    Box(modifier = Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp))
                    }
                } else if (searchError != null) {
                    Text(
                        text = if (searchError == "location_search_error") stringResource(R.string.location_search_error) else searchError!!,
                        modifier = Modifier.padding(16.dp),
                        color = MaterialTheme.colorScheme.error
                    )
                } else if (predictions.isEmpty()) {
                    Text(
                        text = stringResource(R.string.no_matching_locations),
                        modifier = Modifier.padding(16.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    LazyColumn(modifier = Modifier.heightIn(max = 200.dp)) {
                        items(predictions) { prediction ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        val fullAddress = "${prediction.primaryText}, ${prediction.secondaryText}"
                                        onLocationChange(fullAddress)
                                        expanded = false
                                        
                                        // Fetch place details
                                        val placeFields = listOf(Place.Field.LAT_LNG, Place.Field.ID, Place.Field.FORMATTED_ADDRESS)
                                        val fetchRequest = FetchPlaceRequest.newInstance(prediction.placeId, placeFields)
                                        
                                        placesClient?.fetchPlace(fetchRequest)
                                            ?.addOnSuccessListener { response ->
                                                val place = response.place
                                                onPlaceSelected(place.latLng, place.id, place.formattedAddress)
                                            }
                                            ?.addOnFailureListener { exception ->
                                                val apiException = exception as? com.google.android.gms.common.api.ApiException
                                                val statusCode = apiException?.statusCode
                                                val statusMessage = apiException?.status?.statusMessage
                                                Log.e("Places", "Place fetch failed: $statusCode - ${statusMessage ?: exception.message}", exception)
                                                onPlaceSelected(null, null, fullAddress)
                                            }
                                    }
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.LocationOn,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(end = 16.dp)
                                )
                                Column {
                                    Text(text = prediction.primaryText, fontWeight = FontWeight.Bold)
                                    Text(text = prediction.secondaryText, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
