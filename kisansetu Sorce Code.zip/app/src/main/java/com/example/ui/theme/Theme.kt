package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.util.AppTheme

private val AppShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

private val DefaultLight = lightColorScheme(
    primary = LightPrimary, onPrimary = LightOnPrimary, primaryContainer = LightPrimaryContainer, onPrimaryContainer = LightOnPrimaryContainer,
    secondary = LightSecondary, onSecondary = LightOnSecondary, secondaryContainer = LightSecondaryContainer, onSecondaryContainer = LightOnSecondaryContainer,
    error = LightError, onError = LightOnError, background = LightBackground, onBackground = LightOnBackground,
    surface = LightSurface, onSurface = LightOnSurface, surfaceVariant = LightSurfaceVariant, onSurfaceVariant = LightOnSurfaceVariant
)
private val DefaultDark = darkColorScheme(
    primary = DarkPrimary, onPrimary = DarkOnPrimary, primaryContainer = DarkPrimaryContainer, onPrimaryContainer = DarkOnPrimaryContainer,
    secondary = DarkSecondary, onSecondary = DarkOnSecondary, secondaryContainer = DarkSecondaryContainer, onSecondaryContainer = DarkOnSecondaryContainer,
    error = DarkError, onError = DarkOnError, background = DarkBackground, onBackground = DarkOnBackground,
    surface = DarkSurface, onSurface = DarkOnSurface, surfaceVariant = DarkSurfaceVariant, onSurfaceVariant = DarkOnSurfaceVariant
)

private val OceanLight = lightColorScheme(
    primary = OceanLightPrimary, primaryContainer = OceanLightPrimaryContainer,
    secondary = OceanLightSecondary, secondaryContainer = OceanLightSecondaryContainer,
    background = OceanLightBackground, surfaceVariant = OceanLightSurfaceVariant
)
private val OceanDark = darkColorScheme(
    primary = OceanDarkPrimary, primaryContainer = OceanDarkPrimaryContainer,
    secondary = OceanDarkSecondary, secondaryContainer = OceanDarkSecondaryContainer,
    background = OceanDarkBackground, surfaceVariant = OceanDarkSurfaceVariant
)

private val ForestLight = lightColorScheme(
    primary = ForestLightPrimary, primaryContainer = ForestLightPrimaryContainer,
    secondary = ForestLightSecondary, secondaryContainer = ForestLightSecondaryContainer,
    background = ForestLightBackground, surfaceVariant = ForestLightSurfaceVariant
)
private val ForestDark = darkColorScheme(
    primary = ForestDarkPrimary, primaryContainer = ForestDarkPrimaryContainer,
    secondary = ForestDarkSecondary, secondaryContainer = ForestDarkSecondaryContainer,
    background = ForestDarkBackground, surfaceVariant = ForestDarkSurfaceVariant
)

private val SunsetLight = lightColorScheme(
    primary = SunsetLightPrimary, primaryContainer = SunsetLightPrimaryContainer,
    secondary = SunsetLightSecondary, secondaryContainer = SunsetLightSecondaryContainer,
    background = SunsetLightBackground, surfaceVariant = SunsetLightSurfaceVariant
)
private val SunsetDark = darkColorScheme(
    primary = SunsetDarkPrimary, primaryContainer = SunsetDarkPrimaryContainer,
    secondary = SunsetDarkSecondary, secondaryContainer = SunsetDarkSecondaryContainer,
    background = SunsetDarkBackground, surfaceVariant = SunsetDarkSurfaceVariant
)

private val LavenderLight = lightColorScheme(
    primary = LavenderLightPrimary, primaryContainer = LavenderLightPrimaryContainer,
    secondary = LavenderLightSecondary, secondaryContainer = LavenderLightSecondaryContainer,
    background = LavenderLightBackground, surfaceVariant = LavenderLightSurfaceVariant
)
private val LavenderDark = darkColorScheme(
    primary = LavenderDarkPrimary, primaryContainer = LavenderDarkPrimaryContainer,
    secondary = LavenderDarkSecondary, secondaryContainer = LavenderDarkSecondaryContainer,
    background = LavenderDarkBackground, surfaceVariant = LavenderDarkSurfaceVariant
)

@Composable
fun KisanSetuTheme(
    appTheme: AppTheme = AppTheme.DEFAULT,
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && appTheme == AppTheme.DEFAULT -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        else -> when (appTheme) {
            AppTheme.DEFAULT -> if (darkTheme) DefaultDark else DefaultLight
            AppTheme.OCEAN -> if (darkTheme) OceanDark else OceanLight
            AppTheme.FOREST -> if (darkTheme) ForestDark else ForestLight
            AppTheme.SUNSET -> if (darkTheme) SunsetDark else SunsetLight
            AppTheme.LAVENDER -> if (darkTheme) LavenderDark else LavenderLight
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = AppShapes,
        content = content
    )
}
