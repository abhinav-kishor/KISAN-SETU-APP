package com.example.ui

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class CropListing(
    val id: String,
    val cropName: String,
    val pricePerQuintal: Int,
    val demand: String // High, Normal, Low
)

data class Market(
    val id: String,
    val name: String,
    val pricePerQuintal: Int,
    val distanceKm: Int,
    val latitude: Double,
    val longitude: Double,
    val crops: List<CropListing> = emptyList()
)

object MarketRepository {
    private val _availableMarkets = MutableStateFlow(
        listOf(
            Market("1", "Agra Mandi", 2550, 40, 27.2023, 77.9396, listOf(
                CropListing("c1_1", "Wheat", 2550, "High"),
                CropListing("c1_2", "Corn", 2200, "Normal"),
                CropListing("c1_3", "Potato", 1800, "High")
            )),
            Market("2", "Sikandra Mandi", 2480, 15, 27.2204, 77.9343, listOf(
                CropListing("c2_1", "Potato", 1850, "High"),
                CropListing("c2_2", "Tomato", 3000, "Normal"),
                CropListing("c2_3", "Wheat", 2480, "Normal"),
                CropListing("c2_4", "Brinjal", 1500, "Low")
            )),
            Market("3", "Etmadpur Mandi", 2400, 10, 27.2354, 78.1983, listOf(
                CropListing("c3_1", "Wheat", 2400, "Low"),
                CropListing("c3_2", "Mustard", 5000, "High"),
                CropListing("c3_3", "Onion", 2100, "High"),
                CropListing("c3_4", "Potato", 1700, "Normal")
            ))
        )
    )
    val availableMarkets: StateFlow<List<Market>> = _availableMarkets.asStateFlow()

    fun addMarket(market: Market) {
        _availableMarkets.update { it + market }
    }

    fun updateMarket(marketId: String, newCrops: List<CropListing>) {
        _availableMarkets.update { markets ->
            markets.map { market ->
                if (market.id == marketId) {
                    // Update pricePerQuintal based on Wheat if it exists, to not break existing hardcoded wheat logic in other screens
                    val wheatPrice = newCrops.find { it.cropName.equals("Wheat", ignoreCase = true) }?.pricePerQuintal 
                                     ?: newCrops.firstOrNull()?.pricePerQuintal 
                                     ?: market.pricePerQuintal
                    market.copy(crops = newCrops, pricePerQuintal = wheatPrice)
                } else {
                    market
                }
            }
        }
    }
}

data class MarketCalculation(
    val market: Market,
    val grossValue: Int,
    val estTransport: Int,
    val netReturn: Int,
    val isRecommended: Boolean = false,
    val actualDistanceKm: Double? = null,
    val actualDurationStr: String? = null
)

fun calculateMarketReturns(
    markets: List<Market>, 
    quantityQuintals: Int, 
    transportCostPerKm: Int = 50,
    actualRouteDistancesKm: Map<String, Double> = emptyMap(),
    actualRouteDurations: Map<String, String> = emptyMap(),
    cropName: String? = null
): List<MarketCalculation> {
    val calculations = markets.map { market ->
        val price = if (!cropName.isNullOrBlank()) {
            market.crops.find { it.cropName.equals(cropName.trim(), ignoreCase = true) }?.pricePerQuintal ?: market.pricePerQuintal
        } else {
            market.pricePerQuintal
        }
        val grossValue = quantityQuintals * price
        val distanceToUse = actualRouteDistancesKm[market.id] ?: market.distanceKm.toDouble()
        
        val bestVehicle = getBestSuitableVehicle(quantityQuintals, distanceToUse)
        val estTransport = bestVehicle?.second ?: (distanceToUse * transportCostPerKm).toInt()
        
        val netReturn = grossValue - estTransport
        MarketCalculation(
            market = market,
            grossValue = grossValue,
            estTransport = estTransport,
            netReturn = netReturn,
            actualDistanceKm = actualRouteDistancesKm[market.id],
            actualDurationStr = actualRouteDurations[market.id]
        )
    }
    
    val sorted = calculations.sortedWith(compareByDescending<MarketCalculation> { it.netReturn }
        .thenBy { it.actualDistanceKm ?: it.market.distanceKm.toDouble() })
        
    return sorted.mapIndexed { index, calc ->
        calc.copy(isRecommended = index == 0)
    }
}
