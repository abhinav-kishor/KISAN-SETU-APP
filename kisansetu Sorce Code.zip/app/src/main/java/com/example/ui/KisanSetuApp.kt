package com.example.ui

import com.example.R

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.LocalShipping
import androidx.navigation.NavType
import androidx.navigation.navArgument
import /* androidx.compose.material.icons.filled.Person */ androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material3.Icon
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.collectAsState
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.ui.res.stringResource
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.screens.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KisanSetuApp() {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    val bottomNavRoutes = listOf("farmer_home", "market_comparison", "transport_hub", "map", "alerts")
    val showBottomNav = currentDestination?.route in bottomNavRoutes

    val authViewModel: AuthViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
    val mapViewModel: MapViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
    val chatViewModel: ChatViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
    val mandiViewModel: MandiViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
    val aiSupportViewModel: AiSupportViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
    val isChatOpen by chatViewModel.isChatOpen.collectAsState()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        floatingActionButton = {
            if (showBottomNav) {
                FloatingActionButton(onClick = { chatViewModel.toggleChat(true) }) {
                    Icon(Icons.Default.Chat, contentDescription = stringResource(R.string.kisan_sahayak))
                }
            }
        },
        bottomBar = {
            if (showBottomNav) {
                NavigationBar {
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.Home, contentDescription = stringResource(R.string.home)) },
                        label = { Text(stringResource(R.string.home)) },
                        selected = currentDestination?.hierarchy?.any { it.route == "farmer_home" } == true,
                        onClick = {
                            navController.navigate("farmer_home") {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.List, contentDescription = stringResource(R.string.markets)) },
                        label = { Text(stringResource(R.string.markets)) },
                        selected = currentDestination?.hierarchy?.any { it.route == "market_comparison" } == true,
                        onClick = {
                            navController.navigate("market_comparison") {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.LocalShipping, contentDescription = stringResource(R.string.transport)) },
                        label = { Text(stringResource(R.string.transport)) },
                        selected = currentDestination?.hierarchy?.any { it.route == "transport_hub" } == true,
                        onClick = {
                            navController.navigate("transport_hub") {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.Map, contentDescription = stringResource(R.string.map)) },
                        label = { Text(stringResource(R.string.map)) },
                        selected = currentDestination?.hierarchy?.any { it.route == "map" } == true,
                        onClick = {
                            navController.navigate("map") {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.Notifications, contentDescription = stringResource(R.string.alerts)) },
                        label = { Text(stringResource(R.string.alerts)) },
                        selected = currentDestination?.hierarchy?.any { it.route == "alerts" } == true,
                        onClick = {
                            navController.navigate("alerts") {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = "splash",
            modifier = Modifier.padding(innerPadding)
        ) {
            composable("splash") { SplashScreen(navController, authViewModel) }
            composable("language_selection") { LanguageSelectionScreen(navController) }
            composable("settings_language") { LanguageSelectionScreen(navController, isFromSettings = true) }
            composable("onboarding") { OnboardingScreen(navController) }
            composable("login") { LoginScreen(navController, authViewModel) }
            composable("signup") { SignUpScreen(navController, authViewModel) }
            composable(
                route = "phone_verification/{phone}/{name}/{email}/{pass}",
                arguments = listOf(
                    navArgument("phone") { type = NavType.StringType },
                    navArgument("name") { type = NavType.StringType },
                    navArgument("email") { type = NavType.StringType },
                    navArgument("pass") { type = NavType.StringType }
                )
            ) { backStackEntry ->
                val phone = backStackEntry.arguments?.getString("phone") ?: ""
                val name = backStackEntry.arguments?.getString("name") ?: ""
                val email = backStackEntry.arguments?.getString("email") ?: ""
                val pass = backStackEntry.arguments?.getString("pass") ?: ""
                PhoneVerificationScreen(navController, authViewModel, phone, name, email, pass)
            }
            composable("profile") { ProfileScreen(navController, authViewModel) }
            composable("ai_support_call") {
                aiSupportViewModel.setAuthViewModel(authViewModel)
                AiSupportCallScreen(navController, aiSupportViewModel)
            }
            composable("email_verification") { EmailVerificationScreen(navController, authViewModel) }
            composable("role_selection") { 
                RoleSelectionScreen(navController, authViewModel, mandiViewModel) 
            }
            composable("farmer_home") { FarmerHomeScreen(navController, mapViewModel) }
            composable("mandi_bhav") { MandiBhavScreen() }
            composable(
                route = "market_comparison/{quantity}?crop={crop}",
                arguments = listOf(
                    navArgument("quantity") { type = NavType.StringType },
                    navArgument("crop") { 
                        type = NavType.StringType
                        nullable = true
                        defaultValue = null
                    }
                )
            ) { backStackEntry ->
                val quantity = backStackEntry.arguments?.getString("quantity")?.toIntOrNull() ?: 10
                val crop = backStackEntry.arguments?.getString("crop")
                MarketComparisonScreen(navController, quantity, crop, mapViewModel) 
            }
            composable("market_comparison") { 
                MarketComparisonScreen(navController, 10, null, mapViewModel) 
            }
            composable("mandi_overview/{marketId}/{quantity}") { backStackEntry ->
                val marketId = backStackEntry.arguments?.getString("marketId")
                val quantity = backStackEntry.arguments?.getString("quantity")?.toIntOrNull() ?: 10
                MandiOverviewScreen(navController, marketId, quantity, mandiViewModel)
            }
            composable("crop_details/{marketId}/{cropId}/{quantity}") { backStackEntry ->
                val marketId = backStackEntry.arguments?.getString("marketId")
                val cropId = backStackEntry.arguments?.getString("cropId")
                val quantity = backStackEntry.arguments?.getString("quantity")?.toIntOrNull() ?: 10
                MarketDetailsScreen(navController, marketId, cropId, quantity, mapViewModel, mandiViewModel)
            }
            composable("price_trends") { PriceTrendsScreen(navController) }
            composable("map") { MapScreen(navController) }
            composable("alerts") { AlertsScreen(navController) }
            composable("ai_assistant") { AiAssistantScreen(navController) }
            composable("mandi_registration") { MandiRegistrationScreen(navController, mandiViewModel) }
            composable("mandi_dashboard") { MandiDashboardScreen(navController, mandiViewModel) }
            
            composable("transport_hub") { TransportHubScreen(navController, mapViewModel) }
            composable(
                route = "transport_options/{mandiId}/{quantity}",
                arguments = listOf(
                    navArgument("mandiId") { type = NavType.StringType },
                    navArgument("quantity") { type = NavType.IntType }
                )
            ) { backStackEntry ->
                val mandiId = backStackEntry.arguments?.getString("mandiId") ?: ""
                val quantity = backStackEntry.arguments?.getInt("quantity") ?: 10
                TransportOptionsScreen(navController, mandiId, quantity, mapViewModel)
            }
            composable(
                route = "transport_details/{mandiId}/{vehicleId}/{quantity}/{distance}/{fare}",
                arguments = listOf(
                    navArgument("mandiId") { type = NavType.StringType },
                    navArgument("vehicleId") { type = NavType.StringType },
                    navArgument("quantity") { type = NavType.IntType },
                    navArgument("distance") { type = NavType.FloatType },
                    navArgument("fare") { type = NavType.IntType }
                )
            ) { backStackEntry ->
                val mandiId = backStackEntry.arguments?.getString("mandiId") ?: ""
                val vehicleId = backStackEntry.arguments?.getString("vehicleId") ?: ""
                val quantity = backStackEntry.arguments?.getInt("quantity") ?: 10
                val distance = backStackEntry.arguments?.getFloat("distance")?.toDouble() ?: 0.0
                val fare = backStackEntry.arguments?.getInt("fare") ?: 0
                TransportDetailsScreen(navController, mandiId, vehicleId, quantity, distance, fare)
            }
            composable(
                route = "transport_status/{requestId}",
                arguments = listOf(navArgument("requestId") { type = NavType.StringType })
            ) { backStackEntry ->
                val requestId = backStackEntry.arguments?.getString("requestId") ?: ""
                TransportStatusScreen(navController, requestId)
            }
        }

        if (isChatOpen) {
            ModalBottomSheet(
                onDismissRequest = { chatViewModel.toggleChat(false) },
                sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
            ) {
                KisanSahayakChatPanel(
                    chatViewModel = chatViewModel,
                    mapViewModel = mapViewModel,
                    navController = navController,
                    onClose = { chatViewModel.toggleChat(false) }
                )
            }
        }
    }
}
