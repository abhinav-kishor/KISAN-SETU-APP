package com.example.ui.screens

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory

@JsonClass(generateAdapter = true)
data class ComputeRoutesRequest(
    val origin: Waypoint,
    val destination: Waypoint,
    val travelMode: String = "DRIVE",
    val routingPreference: String = "TRAFFIC_AWARE_OPTIMAL"
)

@JsonClass(generateAdapter = true)
data class Waypoint(
    val location: LocationObj
)

@JsonClass(generateAdapter = true)
data class LocationObj(
    val latLng: LatLngObj
)

@JsonClass(generateAdapter = true)
data class LatLngObj(
    val latitude: Double,
    val longitude: Double
)

@JsonClass(generateAdapter = true)
data class ComputeRoutesResponse(
    val routes: List<Route>?
)

@JsonClass(generateAdapter = true)
data class Route(
    val distanceMeters: Int,
    val duration: String,
    val polyline: PolylineObj?
)

@JsonClass(generateAdapter = true)
data class PolylineObj(
    val encodedPolyline: String
)

interface RoutesApiService {
    @POST("directions/v2:computeRoutes")
    suspend fun computeRoutes(
        @Header("X-Goog-Api-Key") apiKey: String,
        @Header("X-Goog-FieldMask") fieldMask: String,
        @Body request: ComputeRoutesRequest
    ): ComputeRoutesResponse
}

object RoutesApiClient {
    private val retrofit = Retrofit.Builder()
        .baseUrl("https://routes.googleapis.com/")
        .addConverterFactory(MoshiConverterFactory.create())
        .build()

    val service: RoutesApiService = retrofit.create(RoutesApiService::class.java)
}
