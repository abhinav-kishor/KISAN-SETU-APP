package com.example.ui.screens

import androidx.compose.ui.res.stringResource
import com.example.R

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.Polyline
import com.google.maps.android.compose.rememberCameraPositionState
import com.google.maps.android.compose.CameraPositionState
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.LatLngBounds
import com.google.maps.android.PolyUtil

@Composable
fun GoogleMapRoute(
    origin: LatLng?,
    destination: LatLng,
    marketName: String,
    encodedPolyline: String?,
    modifier: Modifier = Modifier
) {
    var mapLoaded by remember { androidx.compose.runtime.mutableStateOf(false) }
    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(origin ?: destination, 10f)
    }

    LaunchedEffect(mapLoaded, origin, destination, encodedPolyline) {
        if (mapLoaded) {
            val boundsBuilder = LatLngBounds.builder()
            boundsBuilder.include(destination)
            if (origin != null) {
                boundsBuilder.include(origin)
            }
            val bounds = boundsBuilder.build()
            try {
                // Using 64px padding to prevent map layout breaking
                cameraPositionState.animate(CameraUpdateFactory.newLatLngBounds(bounds, 64))
            } catch (e: Exception) {
                // Ignored, happens if layout is not ready
            }
        }
    }

        val context = LocalContext.current
    GoogleMap(
        modifier = modifier,
        cameraPositionState = cameraPositionState,
        onMapLoaded = { mapLoaded = true },
        onMapClick = {
            openGoogleMapsDirections(context, origin, destination)
        }
    ) {
        if (origin != null) {
            Marker(
                state = MarkerState(position = origin),
                title = stringResource(R.string.your_location)
            )
        }
        Marker(
            state = MarkerState(position = destination),
            title = marketName
        )

        if (encodedPolyline != null) {
            val decodedPath = remember(encodedPolyline) { PolyUtil.decode(encodedPolyline) }
            Polyline(
                points = decodedPath,
                color = androidx.compose.ui.graphics.Color.Blue,
                width = 12f
            )
        }
    }
}

fun openGoogleMapsDirections(context: android.content.Context, origin: LatLng?, destination: LatLng) {
    val originParam = origin?.let { "${it.latitude},${it.longitude}" } ?: ""
    val destParam = "${destination.latitude},${destination.longitude}"
    val uriStr = if (originParam.isNotEmpty()) {
        "https://www.google.com/maps/dir/?api=1&origin=$originParam&destination=$destParam&travelmode=driving"
    } else {
        "https://www.google.com/maps/dir/?api=1&destination=$destParam&travelmode=driving"
    }
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(uriStr))
    intent.setPackage("com.google.android.apps.maps")
    try {
        context.startActivity(intent)
    } catch (e: Exception) {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(uriStr)))
    }
}
