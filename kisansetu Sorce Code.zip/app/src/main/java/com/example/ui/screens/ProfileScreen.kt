package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.navigation.NavController
import com.example.R
import com.example.ui.AuthViewModel
import com.example.ui.BankDetails
import com.example.ui.UserState
import com.example.util.AppTheme
import com.example.util.ThemeManager

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(navController: NavController, authViewModel: AuthViewModel) {
    val userState by authViewModel.userState.collectAsState()

    LaunchedEffect(userState) {
        if (userState is UserState.SignedOut) {
            navController.navigate("login") {
                popUpTo(0) { inclusive = true }
            }
        }
    }

    var showEmailDialog by remember { mutableStateOf(false) }
    var showBankDialog by remember { mutableStateOf(false) }
    var showThemeDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.profile)) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground,
                    navigationIconContentColor = MaterialTheme.colorScheme.onBackground
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // Profile Picture
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(100.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer)
            ) {
                Icon(
                    Icons.Default.Person,
                    contentDescription = null,
                    modifier = Modifier.size(56.dp),
                    tint = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (userState is UserState.SignedIn) {
                val user = userState as UserState.SignedIn

                Text(
                    text = user.displayName,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Spacer(modifier = Modifier.height(24.dp))

                // 1. Personal Details
                ProfileSectionCard(
                    title = stringResource(R.string.personal_details),
                    icon = Icons.Default.Person
                ) {
                    DetailRow(label = "Name", value = user.displayName)
                    DetailRow(label = "Phone", value = user.phoneNumber)
                    
                    val displayEmail = if (user.email.isBlank() || user.email.contains("@kisansetu.app")) null else user.email
                    if (displayEmail != null) {
                        DetailRow(
                            label = stringResource(R.string.email), 
                            value = displayEmail,
                            actionText = stringResource(R.string.edit),
                            onAction = { showEmailDialog = true }
                        )
                    } else {
                        DetailRow(
                            label = stringResource(R.string.email), 
                            value = stringResource(R.string.not_available),
                            valueColor = MaterialTheme.colorScheme.error,
                            actionText = stringResource(R.string.add_email),
                            onAction = { showEmailDialog = true }
                        )
                    }
                }

                // 2. Language
                ProfileItemCard(
                    title = stringResource(R.string.language),
                    icon = Icons.Default.Language,
                    onClick = { navController.navigate("settings_language") }
                )

                // 3. Theme
                ProfileItemCard(
                    title = stringResource(R.string.theme),
                    icon = Icons.Default.Palette,
                    onClick = { showThemeDialog = true }
                )

                // 4. About KisanSetu
                ProfileItemCard(
                    title = stringResource(R.string.about_kisansetu),
                    icon = Icons.Default.Info,
                    onClick = { showAboutDialog = true }
                )

                // 5. Bank Account Details
                ProfileSectionCard(
                    title = stringResource(R.string.bank_account_details),
                    icon = Icons.Default.AccountBalance
                ) {
                    if (user.bankDetails == null || user.bankDetails.accountNumber.isBlank()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(stringResource(R.string.not_available), color = MaterialTheme.colorScheme.error)
                            TextButton(onClick = { showBankDialog = true }) {
                                Text("Add Bank Details")
                            }
                        }
                    } else {
                        val maskedAccount = "XXXX XXXX " + user.bankDetails.accountNumber.takeLast(4)
                        DetailRow(label = stringResource(R.string.account_holder_name), value = user.bankDetails.accountHolderName)
                        DetailRow(label = stringResource(R.string.bank_name), value = user.bankDetails.bankName)
                        DetailRow(label = stringResource(R.string.account_number), value = maskedAccount)
                        DetailRow(label = stringResource(R.string.ifsc_code), value = user.bankDetails.ifscCode)
                        
                        Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
                            TextButton(onClick = { showBankDialog = true }) {
                                Text(stringResource(R.string.edit))
                            }
                        }
                    }
                }

                // 6. Customer Support
                ProfileSectionCard(
                    title = stringResource(R.string.customer_support),
                    icon = Icons.Default.SupportAgent
                ) {
                    val context = LocalContext.current
                    SupportRow(
                        title = stringResource(R.string.email_support),
                        subtitle = "mr.zyvix@gmail.com",
                        icon = Icons.Default.Email,
                        onClick = {
                            val intent = Intent(Intent.ACTION_SENDTO).apply {
                                data = Uri.parse("mailto:mr.zyvix@gmail.com")
                            }
                            context.startActivity(Intent.createChooser(intent, "Email Us"))
                        }
                    )
                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                    SupportRow(
                        title = stringResource(R.string.contact_ai),
                        subtitle = "Chat with AI Assistant",
                        icon = Icons.Default.SmartToy,
                        onClick = { navController.navigate("ai_support_call") }
                    )
                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                    SupportRow(
                        title = stringResource(R.string.whatsapp),
                        subtitle = "Message us on WhatsApp",
                        icon = Icons.Default.Chat,
                        onClick = { /* Placeholder for next prompt */ }
                    )
                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                    SupportRow(
                        title = stringResource(R.string.telegram),
                        subtitle = "Message us on Telegram",
                        icon = Icons.Default.Send,
                        onClick = {
                            val telegramUrl = "https://t.me/kisansetuassistbot"
                            try {
                                val telegramIntent = Intent(Intent.ACTION_VIEW, Uri.parse(telegramUrl)).apply {
                                    setPackage("org.telegram.messenger")
                                }
                                context.startActivity(telegramIntent)
                            } catch (e: Exception) {
                                try {
                                    val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(telegramUrl))
                                    context.startActivity(browserIntent)
                                } catch (e: Exception) {
                                    // Fallback if no browser or activity can handle the intent
                                }
                            }
                        }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // 7. Logout
                Button(
                    onClick = { authViewModel.signOut() },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Icon(Icons.Default.Logout, contentDescription = null, modifier = Modifier.padding(end = 8.dp))
                    Text(stringResource(R.string.logout), style = MaterialTheme.typography.titleMedium)
                }
                
                Spacer(modifier = Modifier.height(32.dp))
            } else if (userState is UserState.Error) {
                val errorMsg = (userState as UserState.Error).message
                Text(
                    text = "Failed to load profile",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                Text(
                    text = errorMsg,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
                Button(onClick = { authViewModel.reloadUser() }) {
                    Text("Retry")
                }
            } else {
                CircularProgressIndicator(modifier = Modifier.padding(32.dp))
            }
        }
    }

    // Dialogs
    val user = userState as? UserState.SignedIn
    if (showEmailDialog && user != null) {
        EmailDialog(
            currentEmail = if (user.email.contains("@kisansetu.app")) "" else user.email,
            onDismiss = { showEmailDialog = false },
            onSave = { newEmail ->
                authViewModel.updateEmail(newEmail)
                showEmailDialog = false
            }
        )
    }

    if (showBankDialog && user != null) {
        BankDetailsDialog(
            currentDetails = user.bankDetails ?: BankDetails(),
            onDismiss = { showBankDialog = false },
            onSave = { newDetails ->
                authViewModel.updateBankDetails(newDetails)
                showBankDialog = false
            }
        )
    }

    if (showThemeDialog) {
        ThemeDialog(onDismiss = { showThemeDialog = false })
    }

    if (showAboutDialog) {
        AboutDialog(onDismiss = { showAboutDialog = false })
    }
}

@Composable
fun ProfileSectionCard(title: String, icon: ImageVector, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = MaterialTheme.shapes.large
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
            }
            Spacer(modifier = Modifier.height(16.dp))
            content()
        }
    }
}

@Composable
fun ProfileItemCard(title: String, icon: ImageVector, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 16.dp)
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = MaterialTheme.shapes.large
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(8.dp))
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.weight(1f))
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun DetailRow(label: String, value: String, valueColor: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.onSurface, actionText: String? = null, onAction: (() -> Unit)? = null) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
        
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.End, modifier = Modifier.weight(2f)) {
            Text(value, fontWeight = FontWeight.Medium, color = valueColor, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (actionText != null && onAction != null) {
                Spacer(modifier = Modifier.width(8.dp))
                TextButton(onClick = onAction, contentPadding = PaddingValues(0.dp)) {
                    Text(actionText)
                }
            }
        }
    }
}

@Composable
fun SupportRow(title: String, subtitle: String, icon: ImageVector, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
        }
        Spacer(modifier = Modifier.width(16.dp))
        Column {
            Text(title, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(modifier = Modifier.weight(1f))
        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun EmailDialog(currentEmail: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var email by remember { mutableStateOf(currentEmail) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.add_email)) },
        text = {
            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text(stringResource(R.string.email)) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
        },
        confirmButton = {
            TextButton(onClick = { onSave(email) }) {
                Text(stringResource(R.string.save))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.cancel))
            }
        }
    )
}

@Composable
fun BankDetailsDialog(currentDetails: BankDetails, onDismiss: () -> Unit, onSave: (BankDetails) -> Unit) {
    var holder by remember { mutableStateOf(currentDetails.accountHolderName) }
    var bank by remember { mutableStateOf(currentDetails.bankName) }
    var account by remember { mutableStateOf(currentDetails.accountNumber) }
    var ifsc by remember { mutableStateOf(currentDetails.ifscCode) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            shape = MaterialTheme.shapes.extraLarge,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(24.dp)) {
                Text(stringResource(R.string.bank_account_details), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(16.dp))
                
                OutlinedTextField(value = holder, onValueChange = { holder = it }, label = { Text(stringResource(R.string.account_holder_name)) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(value = bank, onValueChange = { bank = it }, label = { Text(stringResource(R.string.bank_name)) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(value = account, onValueChange = { account = it }, label = { Text(stringResource(R.string.account_number)) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(value = ifsc, onValueChange = { ifsc = it }, label = { Text(stringResource(R.string.ifsc_code)) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                
                Spacer(modifier = Modifier.height(24.dp))
                
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(onClick = { onSave(BankDetails(holder, bank, account, ifsc)) }) { Text(stringResource(R.string.save)) }
                }
            }
        }
    }
}

@Composable
fun ThemeDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    val currentTheme by ThemeManager.themeState.collectAsState()
    
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            shape = MaterialTheme.shapes.extraLarge,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(24.dp)) {
                Text(stringResource(R.string.theme), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(16.dp))
                
                AppTheme.values().forEach { theme ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { 
                                ThemeManager.setTheme(context, theme)
                                onDismiss() 
                            }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = theme == currentTheme,
                            onClick = { 
                                ThemeManager.setTheme(context, theme)
                                onDismiss() 
                            }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        
                        // Theme color preview circle
                        val previewColor = when (theme) {
                            AppTheme.DEFAULT -> com.example.ui.theme.LightPrimary
                            AppTheme.OCEAN -> com.example.ui.theme.OceanLightPrimary
                            AppTheme.FOREST -> com.example.ui.theme.ForestLightPrimary
                            AppTheme.SUNSET -> com.example.ui.theme.SunsetLightPrimary
                            AppTheme.LAVENDER -> com.example.ui.theme.LavenderLightPrimary
                        }
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(androidx.compose.foundation.shape.CircleShape)
                                .background(previewColor)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        
                        Text(theme.displayName, style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
        }
    }
}

@Composable
fun AboutDialog(onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            shape = MaterialTheme.shapes.extraLarge,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(24.dp).verticalScroll(rememberScrollState())) {
                Text(stringResource(R.string.about_kisansetu), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.height(16.dp))
                Text(stringResource(R.string.about_desc), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
                Spacer(modifier = Modifier.height(24.dp))
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
                    TextButton(onClick = onDismiss) {
                        Text("Close")
                    }
                }
            }
        }
    }
}
