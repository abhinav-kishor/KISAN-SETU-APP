package com.example.ui.screens

import com.example.R

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Agriculture
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.ui.res.stringResource
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.ui.MarketRepository
import com.example.ui.calculateMarketReturns

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FarmerHomeScreen(navController: NavController, mapViewModel: MapViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {
    var crop by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("Dayalbagh, Agra, Uttar Pradesh") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                            shape = MaterialTheme.shapes.small,
                            modifier = Modifier.padding(end = 12.dp)
                        ) {
                            Icon(
                                Icons.Default.Agriculture,
                                contentDescription = null,
                                modifier = Modifier.padding(8.dp),
                                tint = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }
                        Column {
                            Text(stringResource(R.string.app_name), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.LocationOn, contentDescription = null, modifier = Modifier.height(14.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(location.split(",").take(2).joinToString(",").take(20), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground,
                    actionIconContentColor = MaterialTheme.colorScheme.onSurfaceVariant
                ),
                actions = {
                    Card(
                        shape = androidx.compose.foundation.shape.CircleShape,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        IconButton(onClick = { navController.navigate("profile") }) {
                            Icon(Icons.Default.Person, contentDescription = stringResource(R.string.profile), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer),
                onClick = { navController.navigate("mandi_bhav") },
                shape = MaterialTheme.shapes.large
            ) {
                Row(
                    modifier = Modifier.padding(16.dp).fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(stringResource(R.string.mandi_bhav_title), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onTertiaryContainer)
                        Text(stringResource(R.string.govt_mandi_prices), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.8f))
                    }
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "View", tint = MaterialTheme.colorScheme.onTertiaryContainer)
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = MaterialTheme.shapes.extraLarge
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Text(
                        text = stringResource(R.string.where_should_sell),
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Spacer(modifier = Modifier.height(24.dp))

                    var expanded by remember { mutableStateOf(false) }
                    val cropList = listOf("Wheat", "Rice", "Maize", "Tomato", "Potato", "Onion", "Cotton", "Soybean", "Mustard", "Gram", "Sugarcane", "Groundnut", "Bajra", "Jowar", "Barley")
                    val filteredCrops = if (crop.isEmpty()) {
                        emptyList()
                    } else {
                        cropList.filter { it.startsWith(crop, ignoreCase = true) }.take(6)
                    }

                    androidx.compose.material3.ExposedDropdownMenuBox(
                        expanded = expanded,
                        onExpandedChange = { expanded = it }
                    ) {
                        OutlinedTextField(
                            value = crop,
                            onValueChange = { 
                                crop = it
                                expanded = true
                            },
                            label = { Text(stringResource(R.string.crop_eg_wheat)) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(),
                            colors = androidx.compose.material3.ExposedDropdownMenuDefaults.outlinedTextFieldColors()
                        )
                        ExposedDropdownMenu(
                            expanded = expanded && crop.isNotEmpty(),
                            onDismissRequest = { expanded = false }
                        ) {
                            if (filteredCrops.isEmpty()) {
                                androidx.compose.material3.DropdownMenuItem(
                                    text = { Text("No matching crops found", color = MaterialTheme.colorScheme.onSurfaceVariant) },
                                    onClick = { }
                                )
                            } else {
                                filteredCrops.forEach { selectionOption ->
                                    androidx.compose.material3.DropdownMenuItem(
                                        text = { Text(selectionOption) },
                                        onClick = {
                                            crop = selectionOption
                                            expanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = quantity,
                        onValueChange = { quantity = it },
                        label = { Text(stringResource(R.string.quantity_quintals)) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    LocationAutocomplete(
                        location = location,
                        onLocationChange = { location = it },
                        onPlaceSelected = { latLng, placeId, address ->
                            if (latLng != null) {
                                mapViewModel.setUserLocation(latLng)
                            }
                        },
                        label = stringResource(R.string.location)
                    )
                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = { 
                            val qty = quantity.toIntOrNull() ?: 10
                            val cropParam = if (crop.isNotBlank()) "?crop=${crop.trim()}" else ""
                            navController.navigate("market_comparison/$qty$cropParam") 
                        },
                        modifier = Modifier.fillMaxWidth().height(56.dp)
                    ) {
                        Text(stringResource(R.string.find_best_market), style = MaterialTheme.typography.titleMedium)
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween
            ) {
                Text(stringResource(R.string.recommendation), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(modifier = Modifier.height(16.dp))

            val qtyInt = quantity.toIntOrNull() ?: 10
            val bestMarketCalc = calculateMarketReturns(MarketRepository.availableMarkets.value, qtyInt, cropName = crop).first()

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondary),
                shape = MaterialTheme.shapes.extraLarge,
                onClick = {
                    val cropId = if (crop.isNotBlank()) {
                        bestMarketCalc.market.crops.find { it.cropName.equals(crop.trim(), ignoreCase = true) }?.id
                    } else null
                    
                    if (cropId != null) {
                        navController.navigate("crop_details/${bestMarketCalc.market.id}/$cropId/$qtyInt")
                    } else {
                        navController.navigate("mandi_overview/${bestMarketCalc.market.id}/$qtyInt")
                    }
                }
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                            shape = androidx.compose.foundation.shape.CircleShape
                        ) {
                            Text(stringResource(R.string.recommended_badge), modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary)
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(bestMarketCalc.market.name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSecondary)
                    Text("Distance: ${bestMarketCalc.market.distanceKm} km", color = MaterialTheme.colorScheme.onSecondary.copy(alpha = 0.7f), style = MaterialTheme.typography.bodySmall)
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Column {
                            Text(stringResource(R.string.estimated_return), color = MaterialTheme.colorScheme.onSecondary.copy(alpha = 0.7f), style = MaterialTheme.typography.labelSmall)
                            Text("₹${bestMarketCalc.netReturn}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSecondary)
                        }
                        Card(
                            shape = androidx.compose.foundation.shape.CircleShape,
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = stringResource(R.string.view_details), tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.padding(12.dp))
                        }
                    }
                }
            }
        }
    }
}
