package com.example.ui

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialException
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.*
import com.google.firebase.auth.PhoneAuthProvider.OnVerificationStateChangedCallbacks
import com.google.firebase.auth.PhoneAuthProvider.ForceResendingToken
import com.google.firebase.firestore.firestore
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.firestore.SetOptions
import com.google.firebase.FirebaseException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.concurrent.TimeUnit

class AuthViewModel : ViewModel() {
    private val auth = Firebase.auth
    private val db = Firebase.firestore

    private val _userState = MutableStateFlow<UserState>(UserState.Loading)
    val userState: StateFlow<UserState> = _userState.asStateFlow()
    
    private val _verificationId = MutableStateFlow<String?>(null)
    val verificationId: StateFlow<String?> = _verificationId.asStateFlow()
    
    private var resendToken: ForceResendingToken? = null

    init {
        /**
         * =========================================================================
         * DEVELOPER DOCUMENTATION: FIREBASE PHONE AUTHENTICATION (DEMO/TESTING)
         * =========================================================================
         * 
         * To test Phone OTP Verification in an emulator or without sending real SMS:
         * 
         * 1. Go to Firebase Console -> Authentication -> Sign-in method -> Phone.
         * 2. Scroll down to "Phone numbers for testing".
         * 3. Add a test phone number (e.g., +91 9999999999) and a fixed OTP (e.g., 123456).
         * 
         * When this test number is entered in the app:
         * - Firebase will intentionally NOT send a real SMS.
         * - Firebase will successfully trigger `onCodeSent()`.
         * - Enter the fixed OTP assigned in the console to verify successfully.
         * - The flow uses the standard `PhoneAuthCredential` and behaves exactly like a real phone.
         * 
         * WARNING: Real SMS authentication requires Play Integrity/SafetyNet and may fail
         * in emulators. Do not claim real SMS is working unless tested on a physical device.
         * =========================================================================
         */
        auth.firebaseAuthSettings.setAppVerificationDisabledForTesting(true)
        
        auth.addAuthStateListener { firebaseAuth ->
            val user = firebaseAuth.currentUser
            if (user != null) {
                val rawEmail = user.email ?: ""
                val cleanEmail = if (rawEmail.contains("@kisansetu.app")) "" else rawEmail
                // We just set basic info first, then call loadProfile
                _userState.value = UserState.SignedIn(
                    uid = user.uid,
                    displayName = user.displayName ?: "Farmer",
                    email = cleanEmail,
                    phoneNumber = user.phoneNumber ?: "Not available",
                    isEmailVerified = user.isEmailVerified
                )
                loadProfile()
            } else {
                _userState.value = UserState.SignedOut
            }
        }
    }

    fun startPhoneVerification(phoneNumber: String, activity: Activity) {
        _userState.value = UserState.Loading
        val optionsBuilder = PhoneAuthOptions.newBuilder(auth)
            .setPhoneNumber(phoneNumber)
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(activity)
            .setCallbacks(object : OnVerificationStateChangedCallbacks() {
                override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                    // Auto-retrieval or Instant verification (Test numbers)
                    // Wait for user to tap verify or we could auto sign-in
                    // For simplicity, we just fill the OTP or sign in, but let's let the user type if they want, 
                    // or auto sign in. Since we need to create account with password, we just store credential.code
                    if (credential.smsCode != null) {
                        // We could auto-fill, but we are not passing a callback to UI for that yet.
                    }
                    _userState.value = UserState.SignedOut // stop loading
                }

                override fun onVerificationFailed(e: com.google.firebase.FirebaseException) {
                    _userState.value = UserState.Error(e.localizedMessage ?: "Phone verification failed")
                }

                override fun onCodeSent(
                    verificationId: String,
                    token: ForceResendingToken
                ) {
                    _verificationId.value = verificationId
                    resendToken = token
                    _userState.value = UserState.SignedOut
                }
            })
            
        if (resendToken != null) {
            optionsBuilder.setForceResendingToken(resendToken!!)
        }
        PhoneAuthProvider.verifyPhoneNumber(optionsBuilder.build())
    }

    fun verifyOTPAndSignUp(verId: String, otp: String, name: String, phone: String, email: String, pass: String) {
        viewModelScope.launch {
            _userState.value = UserState.Loading
            try {
                val phoneCredential = PhoneAuthProvider.getCredential(verId, otp)
                val sanitizedPhone = phone.replace(Regex("[^0-9]"), "")
                val formattedPhone = if (phone.startsWith("+")) phone else "+91$phone"
                val hasRealEmail = email.isNotBlank() && email != "NONE" && android.util.Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()
                val realEmail = if (hasRealEmail) email.trim() else null
                val syntheticEmail = "$sanitizedPhone@kisansetu.app"

                var user: FirebaseUser? = null

                // 1. If user provided a real email, attempt creating or signing into the Email/Password user first,
                //    then attach the verified phone number using updatePhoneNumber / linkWithCredential.
                if (realEmail != null) {
                    try {
                        val createResult = auth.createUserWithEmailAndPassword(realEmail, pass).await()
                        user = createResult.user
                        Log.i("Auth", "Created new Firebase user with email: $realEmail (UID: ${user?.uid})")
                    } catch (e: FirebaseAuthUserCollisionException) {
                        Log.i("Auth", "Email $realEmail already exists, attempting sign in with password to attach phone")
                        try {
                            val signResult = auth.signInWithEmailAndPassword(realEmail, pass).await()
                            user = signResult.user
                        } catch (e2: Exception) {
                            Log.w("Auth", "Could not sign in with existing email/pass: ${e2.message}")
                        }
                    } catch (e: Exception) {
                        Log.w("Auth", "createUserWithEmailAndPassword failed: ${e.message}")
                    }

                    if (user != null) {
                        // Attach the verified phone number to this email account
                        try {
                            user.updatePhoneNumber(phoneCredential).await()
                            Log.i("Auth", "Successfully attached phone number ($formattedPhone) to user: ${user.uid}")
                        } catch (e: Exception) {
                            Log.w("Auth", "updatePhoneNumber failed: ${e.message}, trying linkWithCredential")
                            try {
                                user.linkWithCredential(phoneCredential).await()
                                Log.i("Auth", "Successfully linked phone credential to user: ${user.uid}")
                            } catch (e2: Exception) {
                                Log.w("Auth", "linkWithCredential for phone also failed: ${e2.message}")
                            }
                        }

                        // Send verification email for real email
                        try {
                            user.sendEmailVerification().await()
                        } catch (e: Exception) {
                            Log.w("Auth", "Failed to send email verification: ${e.message}")
                        }
                    }
                }

                // 2. If user is still null (no real email provided, or email creation/login failed), authenticate with PhoneAuthCredential
                if (user == null) {
                    val authResult = auth.signInWithCredential(phoneCredential).await()
                    user = authResult.user
                    Log.i("Auth", "Signed in with PhoneAuthCredential (UID: ${user?.uid}, phone: ${user?.phoneNumber})")

                    if (user != null) {
                        if (realEmail != null) {
                            // User provided real email, attempt to link email/pass credential
                            try {
                                val emailCred = EmailAuthProvider.getCredential(realEmail, pass)
                                user.linkWithCredential(emailCred).await()
                                Log.i("Auth", "Successfully linked real email ($realEmail) to phone user: ${user.uid}")
                                try { user.sendEmailVerification().await() } catch (e: Exception) { Log.w("Auth", "Email verify failed", e) }
                            } catch (e: Exception) {
                                Log.w("Auth", "Could not link real email credential: ${e.message}")
                                try {
                                    user.verifyBeforeUpdateEmail(realEmail).await()
                                } catch (e2: Exception) {
                                    Log.w("Auth", "verifyBeforeUpdateEmail also failed: ${e2.message}")
                                }
                            }
                        } else {
                            // User did not provide email; link synthetic email so user can log in with password
                            val isPasswordLinked = user.providerData.any { it.providerId == EmailAuthProvider.PROVIDER_ID }
                            if (!isPasswordLinked) {
                                try {
                                    val emailCred = EmailAuthProvider.getCredential(syntheticEmail, pass)
                                    user.linkWithCredential(emailCred).await()
                                    Log.i("Auth", "Linked synthetic email ($syntheticEmail) for password login")
                                } catch (e: Exception) {
                                    Log.w("Auth", "Linking synthetic email failed: ${e.message}")
                                    if (pass.isNotBlank()) {
                                        try { user.updatePassword(pass).await() } catch (e2: Exception) { Log.w("Auth", "updatePassword failed", e2) }
                                    }
                                }
                            }
                        }
                    }
                }

                if (user != null) {
                    // Update display name
                    try {
                        val profileUpdates = userProfileChangeRequest { displayName = name }
                        user.updateProfile(profileUpdates).await()
                    } catch (e: Exception) {
                        Log.e("Auth", "Failed to update profile name", e)
                    }

                    // Reload user to ensure currentUser has latest profile, email, and phone
                    try {
                        user.reload().await()
                    } catch (e: Exception) {
                        Log.w("Auth", "Failed to reload user", e)
                    }

                    // 3. Save to Firestore
                    val userDoc = db.collection("users").document(user.uid)
                    val existingSnapshot = try { userDoc.get().await() } catch (e: Exception) { null }
                    val isNewUser = existingSnapshot == null || !existingSnapshot.exists()

                    val actualPhone = user.phoneNumber ?: formattedPhone
                    val actualEmail = if (user.email != null && !user.email!!.contains("@kisansetu.app")) user.email else realEmail

                    val userData = hashMapOf<String, Any?>(
                        "uid" to user.uid,
                        "displayName" to name,
                        "phoneNumber" to actualPhone,
                        "phoneVerified" to true,
                        "emailVerified" to user.isEmailVerified,
                        "updatedAt" to System.currentTimeMillis(),
                        "lastLogin" to System.currentTimeMillis()
                    )
                    if (actualEmail != null) {
                        userData["email"] = actualEmail
                    } else if (isNewUser) {
                        userData["email"] = null
                    }
                    if (isNewUser) {
                        userData["role"] = "farmer"
                        userData["createdAt"] = System.currentTimeMillis()
                    }
                    userDoc.set(userData, SetOptions.merge()).await()

                    loadProfile()
                } else {
                    _userState.value = UserState.Error("Failed to authenticate user")
                }
            } catch (e: FirebaseAuthInvalidCredentialsException) {
                _userState.value = UserState.Error("Invalid OTP. Please try again.")
            } catch (e: Exception) {
                val msg = e.message ?: ""
                if (msg.contains("session expired", ignoreCase = true)) {
                    _userState.value = UserState.Error("OTP expired. Please resend.")
                } else {
                    _userState.value = UserState.Error(e.localizedMessage ?: "Verification failed")
                }
            }
        }
    }

    fun signInWithEmailPassword(identifier: String, password: String) {
        viewModelScope.launch {
            _userState.value = UserState.Loading
            try {
                val trimmedId = identifier.trim()
                if (trimmedId.contains("@") && !trimmedId.endsWith("@kisansetu.app")) {
                    // Standard email login
                    auth.signInWithEmailAndPassword(trimmedId, password).await()
                } else {
                    // Phone number or synthetic email login
                    val phonePart = if (trimmedId.contains("@kisansetu.app")) {
                        trimmedId.substringBefore("@kisansetu.app")
                    } else {
                        trimmedId
                    }
                    val sanitized = phonePart.replace(Regex("[^0-9]"), "")
                    val formatted = if (phonePart.startsWith("+")) phonePart else "+91$phonePart"

                    var signedIn = false
                    // 1. Try digits-only synthetic email (e.g. 919876543210@kisansetu.app)
                    try {
                        auth.signInWithEmailAndPassword("$sanitized@kisansetu.app", password).await()
                        signedIn = true
                    } catch (e: Exception) {
                        Log.d("Auth", "Login with $sanitized@kisansetu.app failed, trying with +")
                    }

                    // 2. Try with '+' formatted synthetic email (e.g. +919876543210@kisansetu.app)
                    if (!signedIn) {
                        try {
                            auth.signInWithEmailAndPassword("$formatted@kisansetu.app", password).await()
                            signedIn = true
                        } catch (e: Exception) {
                            Log.d("Auth", "Login with $formatted@kisansetu.app failed")
                        }
                    }

                    // 3. Fallback: try raw identifier directly
                    if (!signedIn) {
                        auth.signInWithEmailAndPassword(trimmedId, password).await()
                    }
                }
                // The auth state listener will update the state to SignedIn
            } catch (e: FirebaseAuthInvalidCredentialsException) {
                _userState.value = UserState.Error("Invalid phone/email or password.")
            } catch (e: FirebaseAuthInvalidUserException) {
                _userState.value = UserState.Error("No account found. If you registered with an email, please use your email address to sign in.")
            } catch (e: Exception) {
                val msg = e.message ?: ""
                if (msg.contains("invalid credential", ignoreCase = true) || msg.contains("invalid password", ignoreCase = true)) {
                    _userState.value = UserState.Error("Invalid phone/email or password.")
                } else if (msg.contains("no user record", ignoreCase = true)) {
                    _userState.value = UserState.Error("No account found. If you registered with an email, please use your email address to sign in.")
                } else {
                    _userState.value = UserState.Error(e.localizedMessage ?: "Sign in failed")
                }
            }
        }
    }

    fun resetPassword(email: String) {
        viewModelScope.launch {
            try {
                auth.sendPasswordResetEmail(email).await()
            } catch (e: Exception) {
                _userState.value = UserState.Error(e.localizedMessage ?: "Password reset failed")
            }
        }
    }

    fun clearError() {
        if (_userState.value is UserState.Error) {
            _userState.value = UserState.SignedOut
        }
    }

    fun signInWithGoogle(context: Context) {
        viewModelScope.launch {
            try {
                // IMPORTANT: The google-services.json provided does NOT have a Web Client ID
                // configured in the oauth_client array. Google Sign-In requires a Web Client ID.
                // Replace "YOUR_WEB_CLIENT_ID" with the actual Web Client ID from your Firebase Console.
                val serverClientId = "YOUR_WEB_CLIENT_ID_PLACEHOLDER"
                val credentialManager = CredentialManager.create(context)
                
                val googleIdOption = GetGoogleIdOption.Builder()
                    .setFilterByAuthorizedAccounts(false)
                    .setServerClientId(serverClientId)
                    .setAutoSelectEnabled(true)
                    .build()
                
                val request = GetCredentialRequest.Builder()
                    .addCredentialOption(googleIdOption)
                    .build()
                
                val result = credentialManager.getCredential(context, request)
                val credential = result.credential
                
                if (credential is GoogleIdTokenCredential) {
                    val idToken = credential.idToken
                    val firebaseCredential = GoogleAuthProvider.getCredential(idToken, null)
                    
                    val authResult = auth.signInWithCredential(firebaseCredential).await()
                    
                    // Save user profile to Firestore
                    authResult.user?.let { user ->
                        val userData = hashMapOf(
                            "uid" to user.uid,
                            "displayName" to user.displayName,
                            "email" to user.email,
                            "lastLogin" to System.currentTimeMillis()
                        )
                        db.collection("users").document(user.uid).set(userData).await()
                    }
                } else {
                    Log.e("Auth", "Unexpected credential type")
                }
            } catch (e: Exception) {
                Log.e("Auth", "Sign-in failed", e)
            }
        }
    }


    fun updateEmail(newEmail: String) {
        val user = auth.currentUser
        if (user != null) {
            viewModelScope.launch {
                try {
                    db.collection("users").document(user.uid).update("email", newEmail).await()
                    val currentState = _userState.value
                    if (currentState is UserState.SignedIn) {
                        _userState.value = currentState.copy(email = newEmail)
                    }
                } catch (e: Exception) {
                    Log.e("Auth", "Firestore Email update failed", e)
                }
                
                try {
                    user.verifyBeforeUpdateEmail(newEmail).await()
                } catch (e: Exception) {
                    Log.w("Auth", "verifyBeforeUpdateEmail failed, attempting direct updateEmail", e)
                    try {
                        user.updateEmail(newEmail).await()
                    } catch (e2: Exception) {
                        Log.w("Auth", "Firebase Auth Email update failed", e2)
                    }
                }
            }
        }
    }

    fun updateBankDetails(bankDetails: BankDetails) {
        val user = auth.currentUser
        if (user != null) {
            viewModelScope.launch {
                try {
                    db.collection("users").document(user.uid).update(
                        "bankDetails", mapOf(
                            "accountHolderName" to bankDetails.accountHolderName,
                            "bankName" to bankDetails.bankName,
                            "accountNumber" to bankDetails.accountNumber,
                            "ifscCode" to bankDetails.ifscCode
                        )
                    ).await()
                    val currentState = _userState.value
                    if (currentState is UserState.SignedIn) {
                        _userState.value = currentState.copy(bankDetails = bankDetails)
                    }
                } catch (e: Exception) {
                    Log.e("Auth", "Bank details update failed", e)
                }
            }
        }
    }

    
    fun loadProfile() {
        val user = auth.currentUser
        if (user == null) {
            _userState.value = UserState.SignedOut
            return
        }
        
        viewModelScope.launch {
            // Keep basic SignedIn state while loading profile data, or use Loading if you prefer.
            // But we don't want to disrupt the UI if they are just navigating.
            try {
                val document = db.collection("users").document(user.uid).get().await()
                if (document.exists()) {
                    val firestoreName = document.getString("displayName")
                    val phone = document.getString("phoneNumber") ?: user.phoneNumber ?: "Not available"
                    val rawEmail = document.getString("email") ?: user.email ?: ""
                    val cleanEmail = if (rawEmail.contains("@kisansetu.app")) "" else rawEmail

                    var bankDetails: BankDetails? = null
                    val bd = document.get("bankDetails") as? Map<String, String>
                    if (bd != null) {
                        bankDetails = BankDetails(
                            accountHolderName = bd["accountHolderName"] ?: "",
                            bankName = bd["bankName"] ?: "",
                            accountNumber = bd["accountNumber"] ?: "",
                            ifscCode = bd["ifscCode"] ?: ""
                        )
                    }

                    _userState.value = UserState.SignedIn(
                        uid = user.uid,
                        displayName = firestoreName ?: user.displayName ?: "Farmer",
                        email = cleanEmail,
                        phoneNumber = phone,
                        isEmailVerified = user.isEmailVerified,
                        bankDetails = bankDetails
                    )
                } else {
                    // Profile document doesn't exist yet, that's fine.
                }
            } catch (e: Exception) {
                // If it fails due to permissions or network, we should probably let them know,
                // but setting Error will break the home screen if they are on it?
                // Wait, FarmerHomeScreen doesn't crash on Error. It just ignores it.
                // But if they are on ProfileScreen, they will see it.
                Log.e("Auth", "Failed to load profile", e)
                _userState.value = UserState.Error(e.localizedMessage ?: "Failed to load profile data")
            }
        }
    }

    fun reloadUser() {

        viewModelScope.launch {
            try {
                auth.currentUser?.reload()?.await()
                loadProfile()
            } catch (e: Exception) {
                Log.e("Auth", "Failed to reload user", e)
            }
        }
    }

    fun signOut() {
        auth.signOut()
    }
}

data class BankDetails(val accountHolderName: String = "", val bankName: String = "", val accountNumber: String = "", val ifscCode: String = "")

sealed class UserState {
    object Loading : UserState()
    object SignedOut : UserState()
    data class SignedIn(val uid: String, val displayName: String, val email: String, val phoneNumber: String, val isEmailVerified: Boolean = false, val bankDetails: BankDetails? = null) : UserState()
    data class Error(val message: String) : UserState()
}
