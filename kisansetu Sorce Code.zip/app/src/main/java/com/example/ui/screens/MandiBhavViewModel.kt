package com.example.ui.screens

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.network.MandiBhavRecord
import com.example.network.MandiBhavRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class MandiBhavState {
    object Idle : MandiBhavState()
    object Loading : MandiBhavState()
    data class Success(val records: List<MandiBhavRecord>) : MandiBhavState()
    data class Error(val message: String, val type: ErrorType = ErrorType.UNKNOWN) : MandiBhavState()
}

enum class ErrorType {
    NETWORK, SERVER, AUTH, UNKNOWN
}

class MandiBhavViewModel : ViewModel() {
    private val repository = MandiBhavRepository()
    
    private val _uiState = MutableStateFlow<MandiBhavState>(MandiBhavState.Idle)
    val uiState = _uiState.asStateFlow()
    
    val selectedState = MutableStateFlow("")
    val selectedDistrict = MutableStateFlow("All Districts")
    val selectedCrop = MutableStateFlow("All Crops")
    
    // We cache the state records to derive filters and avoid redundant calls
    private var cachedStateRecords: List<MandiBhavRecord>? = null
    
    val filterModeActive = MutableStateFlow(false)
    
    private val _dynamicDistricts = MutableStateFlow<List<String>>(emptyList())
    val dynamicDistricts = _dynamicDistricts.asStateFlow()
    
    private val _dynamicCrops = MutableStateFlow<List<String>>(emptyList())
    val dynamicCrops = _dynamicCrops.asStateFlow()

    val availableStates = listOf(
        "Andaman and Nicobar", "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", 
        "Chandigarh", "Chhattisgarh", "Dadra and Nagar Haveli", "Daman and Diu", "Delhi", 
        "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jammu and Kashmir", "Jharkhand", 
        "Karnataka", "Kerala", "Lakshadweep", "Madhya Pradesh", "Maharashtra", "Manipur", 
        "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Puducherry", "Punjab", "Rajasthan", 
        "Sikkim", "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal"
    )

    fun onStateSelected(state: String) {
        if (selectedState.value == state) return
        selectedState.value = state
        selectedDistrict.value = "All Districts"
        selectedCrop.value = "All Crops"
        cachedStateRecords = null
        filterModeActive.value = false
        _uiState.value = MandiBhavState.Idle
        _dynamicDistricts.value = emptyList()
        _dynamicCrops.value = emptyList()
    }

    fun onDistrictSelected(district: String) {
        selectedDistrict.value = district
        // If district changes, we should update available crops based on the new district
        updateDynamicCrops()
    }

    fun onCropSelected(crop: String) {
        selectedCrop.value = crop
    }
    
    fun setFilterMode(active: Boolean) {
        filterModeActive.value = active
        if (active && cachedStateRecords == null) {
            // Need to fetch data to populate dropdowns
            fetchStateData(showAll = false)
        } else if (active) {
            _uiState.value = MandiBhavState.Idle // Clear results until they click "Get"
        }
    }
    
    fun browseAll() {
        filterModeActive.value = false
        selectedDistrict.value = "All Districts"
        selectedCrop.value = "All Crops"
        
        if (cachedStateRecords != null) {
            displayCachedData()
        } else {
            fetchStateData(showAll = true)
        }
    }
    
    fun getFilteredMandiBhav() {
        if (cachedStateRecords != null) {
            displayCachedData()
        } else {
            fetchStateData(showAll = true)
        }
    }
    
    private fun updateDynamicCrops() {
        val records = cachedStateRecords ?: return
        val currentDistrict = selectedDistrict.value
        
        val crops = if (currentDistrict == "All Districts") {
            records.mapNotNull { it.commodity }.distinct().sorted()
        } else {
            records.filter { it.district == currentDistrict }.mapNotNull { it.commodity }.distinct().sorted()
        }
        
        _dynamicCrops.value = listOf("All Crops") + crops
        
        if (selectedCrop.value !in _dynamicCrops.value) {
            selectedCrop.value = "All Crops"
        }
    }

    private fun fetchStateData(showAll: Boolean) {
        val state = selectedState.value
        if (state.isBlank()) return
        
        viewModelScope.launch {
            _uiState.value = MandiBhavState.Loading
            try {
                // Fetch all records for the state
                val records = repository.getMandiPrices(state, "", "")
                cachedStateRecords = records
                
                // Derive dynamic filters
                val districts = records.mapNotNull { it.district }.distinct().sorted()
                _dynamicDistricts.value = listOf("All Districts") + districts
                
                updateDynamicCrops()
                
                if (showAll) {
                    displayCachedData()
                } else {
                    _uiState.value = MandiBhavState.Idle
                }
            } catch (e: Exception) {
                Log.e("MandiBhavViewModel", "Failed to fetch prices", e)
                val type = when(e.message) {
                    "NETWORK_ERROR" -> ErrorType.NETWORK
                    "SERVER_ERROR" -> ErrorType.SERVER
                    "Missing API Key" -> ErrorType.AUTH
                    else -> ErrorType.UNKNOWN
                }
                _uiState.value = MandiBhavState.Error(e.message ?: "Unknown error", type)
            }
        }
    }
    
    private fun displayCachedData() {
        val records = cachedStateRecords ?: return
        val currentDistrict = selectedDistrict.value
        val currentCrop = selectedCrop.value
        
        val filtered = records.filter { record ->
            val matchDistrict = currentDistrict == "All Districts" || record.district == currentDistrict
            val matchCrop = currentCrop == "All Crops" || record.commodity == currentCrop
            matchDistrict && matchCrop
        }
        
        if (filtered.isEmpty()) {
            _uiState.value = MandiBhavState.Error("NO_DATA")
        } else {
            _uiState.value = MandiBhavState.Success(filtered)
        }
    }
}
