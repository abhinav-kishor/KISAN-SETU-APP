package com.example.ui.screens

import androidx.compose.ui.res.stringResource
import com.example.R
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.ui.AuthViewModel
import com.example.ui.UserState
import kotlinx.coroutines.launch

@Composable
fun LoginScreen(navController: NavController, authViewModel: AuthViewModel) {
    val userState by authViewModel.userState.collectAsState()
    
    var identifier by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(userState) {
        if (userState is UserState.SignedIn) {
            navController.navigate("role_selection") {
                popUpTo("login") { inclusive = true }
            }
        } else if (userState is UserState.Error) {
            val message = (userState as UserState.Error).message
            scope.launch {
                snackbarHostState.showSnackbar(message)
                authViewModel.clearError()
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = stringResource(R.string.welcome_back),
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(32.dp))
            
            OutlinedTextField(
                value = identifier,
                onValueChange = { identifier = it },
                label = { Text(stringResource(R.string.phone_or_email)) },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                singleLine = true
            )
            Spacer(modifier = Modifier.height(16.dp))
            
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text(stringResource(R.string.password)) },
                modifier = Modifier.fillMaxWidth(),
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                singleLine = true
            )
            Spacer(modifier = Modifier.height(8.dp))
            
            TextButton(
                onClick = { 
                    val trimmedId = identifier.trim()
                    if (trimmedId.isBlank()) {
                        scope.launch { snackbarHostState.showSnackbar("Please enter your phone number or email first") }
                    } else {
                        val emailForReset = if (android.util.Patterns.PHONE.matcher(trimmedId).matches() && !trimmedId.contains("@")) {
                            val formatted = if (trimmedId.startsWith("+")) trimmedId else "+91$trimmedId"
                            "$formatted@kisansetu.app"
                        } else {
                            trimmedId
                        }
                        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(emailForReset).matches()) {
                            scope.launch { snackbarHostState.showSnackbar("Please enter a valid phone number or email") }
                        } else {
                            authViewModel.resetPassword(emailForReset)
                            scope.launch { snackbarHostState.showSnackbar("Password reset email sent (if account exists and has real email)") }
                        }
                    }
                },
                modifier = Modifier.align(Alignment.End)
            ) {
                Text(stringResource(R.string.forgot_password))
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            Button(
                onClick = {
                    val trimmedId = identifier.trim()
                    if (trimmedId.isBlank() || password.isBlank()) {
                        scope.launch { snackbarHostState.showSnackbar("Phone/Email and password cannot be empty") }
                    } else {
                        authViewModel.signInWithEmailPassword(trimmedId, password)
                    }
                },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                enabled = userState !is UserState.Loading
            ) {
                if (userState is UserState.Loading) {
                    CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.onPrimary)
                } else {
                    Text(stringResource(R.string.login), style = MaterialTheme.typography.titleMedium)
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Don't have an account?", color = MaterialTheme.colorScheme.onSurfaceVariant)
                TextButton(onClick = { navController.navigate("signup") }) {
                    Text(stringResource(R.string.signup))
                }
            }
        }
    }
}
