package com.example.ui.screens

import androidx.compose.ui.res.stringResource


import com.example.R

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.ui.MarketRepository
import com.example.ui.getBestSuitableVehicle
import com.google.android.gms.maps.model.LatLng
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MarketDetailsScreen(
    navController: NavController,
    marketId: String?,
    cropId: String?,
    quantity: Int,
    mapViewModel: MapViewModel = viewModel(),
    mandiViewModel: MandiViewModel = viewModel()
) {
    val context = LocalContext.current
    val userLocation by mapViewModel.userLocation.collectAsState()
    val routeDistancesKm by mapViewModel.routeDistancesKm.collectAsState()
    val routeDurations by mapViewModel.routeDurations.collectAsState()
    val routePolylines by mapViewModel.routePolylines.collectAsState()
    val availableMarkets by MarketRepository.availableMarkets.collectAsState()

    val market = availableMarkets.find { it.id == marketId }
    val crop = market?.crops?.find { it.id == cropId }

    val sellRequests by mandiViewModel.sellRequests.collectAsState()
    // Finding existing sell request by matching crop and farmer name logic as requested in prompt.
    
    LaunchedEffect(userLocation) {
        if (routePolylines.isEmpty() && (userLocation != null || androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED)) {
            mapViewModel.loadLocationAndRoutes(context, MarketRepository.availableMarkets.value)
        }
    }
    val existingRequest = sellRequests.find { 
        it.farmerName == "Demo Farmer" && it.cropName == crop?.cropName 
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (crop != null && market != null) "${crop.cropName} at ${market.name}" else "Crop Details") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground,
                    navigationIconContentColor = MaterialTheme.colorScheme.onBackground
                )
            )
        }
    ) { innerPadding ->
        if (market == null || crop == null) {
            Column(modifier = Modifier.padding(innerPadding).padding(16.dp)) {
                Text(stringResource(R.string.crop_not_found))
            }
            return@Scaffold
        }

        val distanceToUse = routeDistancesKm[market.id] ?: market.distanceKm.toDouble()
        val bestVehicle = getBestSuitableVehicle(quantity, distanceToUse)
        val estTransport = bestVehicle?.second ?: (distanceToUse * 50).toInt()
        val grossValue = quantity * crop.pricePerQuintal
        val netReturn = grossValue - estTransport
        val actualDurationStr = routeDurations[market.id]

        // Recheck if it's the recommended market for THIS SPECIFIC CROP
        val allMarketCalculations = availableMarkets.mapNotNull { m ->
            val mCrop = m.crops.find { it.cropName.equals(crop.cropName, ignoreCase = true) }
            if (mCrop != null) {
                val mDist = routeDistancesKm[m.id] ?: m.distanceKm.toDouble()
                val mTrans = getBestSuitableVehicle(quantity, mDist)?.second ?: (mDist * 50).toInt()
                val mNet = (quantity * mCrop.pricePerQuintal) - mTrans
                Pair(m.id, mNet)
            } else null
        }
        val bestMarketId = allMarketCalculations.maxByOrNull { it.second }?.first
        val isRecommended = (bestMarketId == market.id)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Text(market.name, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
            Text("Updated 25 min ago", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
            
            Spacer(modifier = Modifier.height(24.dp))
            
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                shape = MaterialTheme.shapes.extraLarge
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Text("Crop: ${crop.cropName}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Demand: ${crop.demand}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    Text("Price", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("₹${crop.pricePerQuintal} per Quintal", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Text(stringResource(R.string.quantity_val_quintals, quantity.toString()), color = MaterialTheme.colorScheme.onSurface)
                    Text("Gross Value: ₹$grossValue", color = MaterialTheme.colorScheme.onSurface)
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    val distanceText = "%.1f km".format(distanceToUse)
                    Text("Distance: $distanceText", color = MaterialTheme.colorScheme.onSurface)
                    if (actualDurationStr != null) {
                        Text("Estimated Travel Time: $actualDurationStr", color = MaterialTheme.colorScheme.onSurface)
                    }
                    Text("Estimated Transport: ₹$estTransport", color = MaterialTheme.colorScheme.onSurface)
                    Text("Other Costs: ₹0", color = MaterialTheme.colorScheme.onSurface)
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Estimated Net Return: ₹$netReturn", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.titleMedium)
                }
            }
            Spacer(modifier = Modifier.height(32.dp))
            
            if (isRecommended) {
                Text("Why this market?", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                Spacer(modifier = Modifier.height(8.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                    shape = MaterialTheme.shapes.large
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text("This market is recommended because it provides the highest estimated net return after considering transportation costs.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSecondaryContainer)
                    }
                }
                Spacer(modifier = Modifier.height(32.dp))
            }
            
            Text("Route & Travel", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
            Spacer(modifier = Modifier.height(8.dp))
            
            val destLatLng = LatLng(market.latitude, market.longitude)
            val polyline = routePolylines[market.id]
            GoogleMapRoute(
                origin = userLocation,
                destination = destLatLng,
                marketName = market.name,
                encodedPolyline = polyline,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
            )
            Spacer(modifier = Modifier.height(24.dp))
            
            var showSellConfirmation by remember { mutableStateOf(false) }

            if (existingRequest != null) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Sell Request Status", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            existingRequest.status, 
                            fontWeight = FontWeight.Bold, 
                            style = MaterialTheme.typography.titleMedium, 
                            color = if (existingRequest.status == "Accepted") androidx.compose.ui.graphics.Color(0xFF4CAF50) else if (existingRequest.status == "Declined") MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            } else {
                Button(
                    onClick = { showSellConfirmation = true },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary)
                ) {
                    Text(stringResource(R.string.send_sell_request), style = MaterialTheme.typography.titleMedium)
                }
            }

            if (showSellConfirmation) {
                AlertDialog(
                    onDismissRequest = { showSellConfirmation = false },
                    title = { Text(stringResource(R.string.sell_crop_at_market, crop.cropName, market.name)) },
                    text = {
                        Column {
                            Text(stringResource(R.string.quantity_val_quintals_cap, quantity.toString()))
                            Text(stringResource(R.string.price_per_quintal_val, crop.pricePerQuintal.toString()))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(stringResource(R.string.estimated_value_val, grossValue.toString()))
                            Text("Estimated Net Return: ₹$netReturn", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                val req = SellRequest(
                                    id = UUID.randomUUID().toString(),
                                    cropName = crop.cropName,
                                    quantity = quantity,
                                    farmerName = "Demo Farmer",
                                    farmerLocation = "Current Location",
                                    status = "Pending"
                                )
                                mandiViewModel.addSellRequest(req)
                                showSellConfirmation = false
                            }
                        ) {
                            Text(stringResource(R.string.send_sell_request))
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showSellConfirmation = false }) {
                            Text(stringResource(R.string.cancel))
                        }
                    }
                )
            }
        }
    }
}
