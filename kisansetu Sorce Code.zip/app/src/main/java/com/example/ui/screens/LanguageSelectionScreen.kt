package com.example.ui.screens

import android.app.Activity
import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.R
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle

data class LanguageOption(val code: String, val name: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LanguageSelectionScreen(navController: NavController, isFromSettings: Boolean = false) {
    val context = LocalContext.current
    val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
    val currentLang = prefs.getString("language", "en") ?: "en"
    
    var selectedLang by remember { mutableStateOf(currentLang) }

    val languages = listOf(
        LanguageOption("en", "English"),
        LanguageOption("hi", "हिंदी (Hindi)"),
        LanguageOption("mr", "मराठी (Marathi)"),
        LanguageOption("bn", "বাংলা (Bengali)"),
        LanguageOption("te", "తెలుగు (Telugu)")
    )

    Scaffold(
        topBar = {
            if (isFromSettings) {
                TopAppBar(
                    title = { Text(stringResource(R.string.language)) },
                    navigationIcon = {
                        IconButton(onClick = { navController.popBackStack() }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    }
                )
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (!isFromSettings) {
                Spacer(modifier = Modifier.height(48.dp))
            }
            Text(
                text = if (isFromSettings) stringResource(R.string.choose_your_language) else "Choose Your Language",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(32.dp))

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(languages) { lang ->
                    LanguageCard(
                        language = lang,
                        isSelected = selectedLang == lang.code,
                        onClick = { selectedLang = lang.code }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    prefs.edit().putString("language", selectedLang).apply()
                    if (currentLang != selectedLang) {
                        // Recreate activity to apply language immediately
                        (context as? Activity)?.recreate()
                    }
                    if (!isFromSettings) {
                        prefs.edit().putBoolean("language_selected", true).apply()
                        navController.navigate("onboarding") {
                            popUpTo("language_selection") { inclusive = true }
                        }
                    } else {
                        navController.popBackStack()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = MaterialTheme.shapes.large
            ) {
                Text(
                    text = if (isFromSettings) stringResource(R.string.save) else "Next",
                    style = MaterialTheme.typography.titleMedium
                )
            }
            if (!isFromSettings) {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LanguageCard(language: LanguageOption, isSelected: Boolean, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
        ),
        shape = MaterialTheme.shapes.medium
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = language.name,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.weight(1f)
            )
            if (isSelected) {
                Icon(
                    imageVector = Icons.Filled.CheckCircle,
                    contentDescription = "Selected",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}
