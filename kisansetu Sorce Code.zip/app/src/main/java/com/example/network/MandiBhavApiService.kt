package com.example.network

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import retrofit2.http.GET
import retrofit2.http.Query
import retrofit2.http.QueryMap

@JsonClass(generateAdapter = true)
data class MandiBhavResponse(
    val records: List<MandiBhavRecord>?,
    val total: Int?,
    val count: Int?,
    val limit: Int?,
    val offset: Int?
)

@JsonClass(generateAdapter = true)
data class MandiBhavRecord(
    val state: String?,
    val district: String?,
    val market: String?,
    val commodity: String?,
    val variety: String?,
    val grade: String?,
    @Json(name = "arrival_date") val arrivalDate: String?,
    @Json(name = "min_price") val minPrice: String?,
    @Json(name = "max_price") val maxPrice: String?,
    @Json(name = "modal_price") val modalPrice: String?
)

interface MandiBhavApiService {
    @GET("resource/9ef84268-d588-465a-a308-a864a43d0070")
    suspend fun getMandiPrices(
        @Query("api-key") apiKey: String,
        @Query("format") format: String = "json",
        @Query("limit") limit: Int = 1000,
        @Query("offset") offset: Int = 0,
        @QueryMap(encoded = true) filters: Map<String, String>
    ): MandiBhavResponse
}
