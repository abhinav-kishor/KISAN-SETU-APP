package com.example.network

import com.example.BuildConfig
import java.net.UnknownHostException
import java.net.URLEncoder
import retrofit2.HttpException
import android.util.Log

class MandiBhavRepository {
    suspend fun getMandiPrices(state: String, district: String, commodity: String): List<MandiBhavRecord> {
        val apiKey = BuildConfig.DATA_GOV_API_KEY
        if (apiKey == "YOUR_DATA_GOV_API_KEY" || apiKey.isBlank()) {
            throw Exception("Missing API Key")
        }

        try {
            val filters = mutableMapOf<String, String>()
            if (state.isNotBlank() && state != "All States") {
                filters["filters[state.keyword]"] = URLEncoder.encode(state, "UTF-8").replace("+", "%20")
            }
            if (district.isNotBlank() && district != "All Districts") {
                filters["filters[district]"] = URLEncoder.encode(district, "UTF-8").replace("+", "%20")
            }
            if (commodity.isNotBlank() && commodity != "All Crops") {
                filters["filters[commodity]"] = URLEncoder.encode(commodity, "UTF-8").replace("+", "%20")
            }

            Log.d("MandiBhavRepo", "Applying filters: $filters")

            val allRecords = mutableListOf<MandiBhavRecord>()
            var currentOffset = 0
            val limit = 1000
            var hasMore = true

            while (hasMore) {
                val response = MandiBhavApiClient.apiService.getMandiPrices(
                    apiKey = apiKey,
                    limit = limit,
                    offset = currentOffset,
                    filters = filters
                )
                
                val records = response.records ?: emptyList()
                allRecords.addAll(records)
                
                val total = response.total ?: 0
                val returnedCount = response.count ?: records.size
                
                if (returnedCount < limit || allRecords.size >= total) {
                    hasMore = false
                } else {
                    currentOffset += limit
                }
            }

            return allRecords
        } catch (e: UnknownHostException) {
            throw Exception("NETWORK_ERROR")
        } catch (e: HttpException) {
            throw Exception("SERVER_ERROR")
        } catch (e: Exception) {
            throw e
        }
    }
}
