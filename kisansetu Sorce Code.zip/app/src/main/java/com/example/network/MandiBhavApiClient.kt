package com.example.network

import android.util.Log
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory

object MandiBhavApiClient {
    private const val BASE_URL = "https://api.data.gov.in/"

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val loggingInterceptor = Interceptor { chain ->
        val request = chain.request()
        val url = request.url
        
        // Log URL safely without API key
        val safeUrl = url.newBuilder().removeAllQueryParameters("api-key").addQueryParameter("api-key", "HIDDEN").build()
        Log.d("MandiBhavAPI", "Sending request to: $safeUrl")
        
        val response = chain.proceed(request)
        Log.d("MandiBhavAPI", "Response code: ${response.code}")
        
        response
    }

    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(loggingInterceptor)
        .build()

    val retrofit: Retrofit by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
    }

    val apiService: MandiBhavApiService by lazy {
        retrofit.create(MandiBhavApiService::class.java)
    }
}
