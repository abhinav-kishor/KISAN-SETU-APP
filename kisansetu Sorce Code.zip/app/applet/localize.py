import os
import re

strings = {
    "choose_your_language": {"en": "Choose Your Language", "hi": "अपनी भाषा चुनें", "mr": "तुमची भाषा निवडा", "bn": "আপনার ভাষা চয়ন করুন", "te": "మీ భాషను ఎంచుకోండి"},
    "language": {"en": "Language", "hi": "भाषा", "mr": "भाषा", "bn": "ভাষা", "te": "భాష"},
    "save": {"en": "Save", "hi": "सहेजें", "mr": "जतन करा", "bn": "সংরক্ষণ করুন", "te": "సేవ్ చేయండి"},
    "app_name": {"en": "KisanSetu", "hi": "किसानसेतु", "mr": "किसानसेतू", "bn": "কিষাণসেতু", "te": "కిసాన్‌సేతు"},
    "home": {"en": "Home", "hi": "होम", "mr": "होम", "bn": "হোম", "te": "హోమ్"},
    "markets": {"en": "Markets", "hi": "मंडी", "mr": "बाजार", "bn": "বাজার", "te": "మార్కెట్లు"},
    "transport": {"en": "Transport", "hi": "परिवहन", "mr": "वाहतूक", "bn": "পরিবহন", "te": "రవాణా"},
    "map": {"en": "Map", "hi": "नक्शा", "mr": "नकाशा", "bn": "মানচিত্র", "te": "మ్యాప్"},
    "alerts": {"en": "Alerts", "hi": "अलर्ट", "mr": "सूचना", "bn": "সতর্কতা", "te": "హెచ్చరికలు"},
    "profile": {"en": "Profile", "hi": "प्रोफ़ाइल", "mr": "प्रोफाइल", "bn": "প্রোফাইল", "te": "ప్రొఫైల్"},
    "login": {"en": "Login", "hi": "लॉगिन", "mr": "लॉगिन", "bn": "লগইন", "te": "లాగిన్"},
    "signup": {"en": "Sign Up", "hi": "साइन अप", "mr": "साइन अप करा", "bn": "সাইন আপ করুন", "te": "సైన్ అప్ చేయండి"},
    "logout": {"en": "Logout", "hi": "लॉगआउट", "mr": "लॉगआउट", "bn": "লগআউট", "te": "లాగ్అవుట్"},
    "kisan_sahayak": {"en": "Kisan Sahayak", "hi": "किसान सहायक", "mr": "किसान सहाय्यक", "bn": "কিষাণ সহায়ক", "te": "కిసాన్ సహాయక్"},
    "role_selection": {"en": "Role Selection", "hi": "भूमिका चयन", "mr": "भूमिका निवड", "bn": "ভূমিকা নির্বাচন", "te": "పాత్ర ఎంపిక"},
    "compare_markets": {"en": "Compare Markets", "hi": "मंडियों की तुलना करें", "mr": "बाजारांची तुलना करा", "bn": "বাজারের তুলনা করুন", "te": "మార్కెట్లను సరిపోల్చండి"},
    "market_details": {"en": "Market Details", "hi": "मंडी विवरण", "mr": "बाजार तपशील", "bn": "বাজারের বিবরণ", "te": "మార్కెట్ వివరాలు"},
    "price_trends": {"en": "Price Trends", "hi": "कीमत के रुझान", "mr": "किंमतीचा कल", "bn": "দামের প্রবণতা", "te": "ధర ధోరణులు"},
    "mandi_dashboard": {"en": "Mandi Dashboard", "hi": "मंडी डैशबोर्ड", "mr": "मंडी डॅशबोर्ड", "bn": "মাণ্ডি ড্যাশবোর্ড", "te": "మండి డాష్‌బోర్డ్"},
    "quantity": {"en": "Quantity", "hi": "मात्रा", "mr": "प्रमाण", "bn": "পরিমাণ", "te": "పరిమాణం"},
    "location": {"en": "Location", "hi": "स्थान", "mr": "स्थान", "bn": "অবস্থান", "te": "స్థానం"},
    "cancel": {"en": "Cancel", "hi": "रद्द करें", "mr": "रद्द करा", "bn": "বাতিল করুন", "te": "రద్దు చేయండి"},
    "close": {"en": "Close", "hi": "बंद करें", "mr": "बंद करा", "bn": "বন্ধ করুন", "te": "మూసివేయండి"},
    "accept": {"en": "Accept", "hi": "स्वीकार करें", "mr": "स्वीकारा", "bn": "গ্রহণ করুন", "te": "అంగీకరించండి"},
    "email": {"en": "Email", "hi": "ईमेल", "mr": "ईमेल", "bn": "ইমেইল", "te": "ఇమెయిల్"},
    "password": {"en": "Password", "hi": "पासवर्ड", "mr": "पासवर्ड", "bn": "পাসওয়ার্ড", "te": "పాస్‌వర్డ్"},
    "forgot_password": {"en": "Forgot Password?", "hi": "पासवर्ड भूल गए?", "mr": "पासवर्ड विसरलात?", "bn": "পাসওয়ার্ড ভুলে গেছেন?", "te": "పాస్‌వర్డ్ మర్చిపోయారా?"},
    "full_name": {"en": "Full Name", "hi": "पूरा नाम", "mr": "पूर्ण नाव", "bn": "পুরো নাম", "te": "పూర్తి పేరు"},
    "address": {"en": "Address", "hi": "पता", "mr": "पत्ता", "bn": "ঠিকানা", "te": "చిరునామా"},
    "contact_number": {"en": "Contact Number *", "hi": "संपर्क नंबर *", "mr": "संपर्क क्रमांक *", "bn": "যোগাযোগের নম্বর *", "te": "సంప్రదింపు నంబర్ *"},
    "city_district": {"en": "City / District *", "hi": "शहर / जिला *", "mr": "शहर / जिल्हा *", "bn": "শহর / জেলা *", "te": "నగరం / జిల్లా *"},
    "mandi_id": {"en": "Mandi ID / Shop ID *", "hi": "मंडी आईडी / दुकान आईडी *", "mr": "मंडी आयडी / दुकान आयडी *", "bn": "মন্ডি আইডি / দোকান আইডি *", "te": "మండి ID / షాప్ ID *"},
    "crop_name": {"en": "Crop Name", "hi": "फसल का नाम", "mr": "पिकाचे नाव", "bn": "ফসলের নাম", "te": "పంట పేరు"},
    "grant_permission": {"en": "Grant Permission", "hi": "अनुमति दें", "mr": "परवानगी द्या", "bn": "অনুমতি দিন", "te": "అనుమతి ఇవ్వండి"},
    "next": {"en": "Next", "hi": "अगला", "mr": "पुढे", "bn": "পরবর্তী", "te": "తదుపరి"},
    "welcome": {"en": "Welcome", "hi": "स्वागत है", "mr": "स्वागत आहे", "bn": "স্বাগতম", "te": "స్వాగతం"},
    "farmer": {"en": "Farmer", "hi": "किसान", "mr": "शेतकरी", "bn": "কৃষক", "te": "రైతు"},
    "mandi_agent": {"en": "Mandi Agent", "hi": "मंडी एजेंट", "mr": "मंडी एजंट", "bn": "মন্ডি এজেন্ট", "te": "మండి ఏజెంట్"},
    "sell_request": {"en": "Sell Request", "hi": "बिक्री अनुरोध", "mr": "विक्री विनंती", "bn": "বিক্রয়ের অনুরোধ", "te": "విక్రయ అభ్యర్థన"},
    "search": {"en": "Search", "hi": "खोजें", "mr": "शोधा", "bn": "অনুসন্ধান করুন", "te": "శోధించండి"},
    "type_your_message": {"en": "Type your message...", "hi": "अपना संदेश टाइप करें...", "mr": "तुमचा संदेश टाइप करा...", "bn": "আপনার বার্তা টাইপ করুন...", "te": "మీ సందేశాన్ని టైప్ చేయండి..."},
}

# Create string resources
res_dir = "/app/applet/app/src/main/res"
os.makedirs(os.path.join(res_dir, "values"), exist_ok=True)
os.makedirs(os.path.join(res_dir, "values-hi"), exist_ok=True)
os.makedirs(os.path.join(res_dir, "values-mr"), exist_ok=True)
os.makedirs(os.path.join(res_dir, "values-bn"), exist_ok=True)
os.makedirs(os.path.join(res_dir, "values-te"), exist_ok=True)

langs = ["en", "hi", "mr", "bn", "te"]
dirs = {"en": "values", "hi": "values-hi", "mr": "values-mr", "bn": "values-bn", "te": "values-te"}

for lang in langs:
    xml_content = '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n'
    for key, trans in strings.items():
        val = trans.get(lang, trans["en"])
        val = val.replace("'", "\\'").replace("&", "&amp;")
        xml_content += f'    <string name="{key}">{val}</string>\n'
    xml_content += '</resources>'
    
    with open(os.path.join(res_dir, dirs[lang], "strings.xml"), "w") as f:
        f.write(xml_content)

print("Created string resources.")
