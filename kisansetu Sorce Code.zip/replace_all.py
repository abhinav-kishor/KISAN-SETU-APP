import os
import re

replacements = [
    # Static Strings
    (r'"Welcome to KisanSetu"', 'stringResource(R.string.welcome_title)'),
    (r'"Know Your Market"', 'stringResource(R.string.know_your_market)'),
    (r'"Get up-to-date market prices for your crops across different mandis."', 'stringResource(R.string.know_your_market_desc)'),
    (r'"Make Smarter Decisions"', 'stringResource(R.string.make_smarter_decisions)'),
    (r'"Compare prices, transport costs, and estimated returns easily."', 'stringResource(R.string.make_smarter_decisions_desc)'),
    (r'"Stay Updated"', 'stringResource(R.string.stay_updated)'),
    (r'"Receive timely alerts on market trends and price changes."', 'stringResource(R.string.stay_updated_desc)'),
    (r'"Get Started"', 'stringResource(R.string.get_started)'),
    (r'"Where should you sell today\?"', 'stringResource(R.string.where_should_sell)'),
    (r'"Crop \(e\.g\., Wheat\)"', 'stringResource(R.string.crop_eg_wheat)'),
    (r'"Quantity \(Quintals\)"', 'stringResource(R.string.quantity_quintals)'),
    (r'"View Details"', 'stringResource(R.string.view_details)'),
    (r'"Find Best Market"', 'stringResource(R.string.find_best_market)'),
    (r'"Recommendation"', 'stringResource(R.string.recommendation)'),
    (r'"Distance"', 'stringResource(R.string.distance)'),
    (r'"Estimated Return"', 'stringResource(R.string.estimated_return)'),
    (r'"RECOMMENDED"', 'stringResource(R.string.recommended_badge)'),
    (r'"AI Assistant Coming Soon"', 'stringResource(R.string.ai_assistant_soon)'),
    (r'"Apna sawaal likhein ya bolein\.\.\."', 'stringResource(R.string.apna_sawaal)'),
    (r'"App Logo"', 'stringResource(R.string.app_logo)'),
    (r'"Back"', 'stringResource(R.string.back)'),
    (r'"Back to Home"', 'stringResource(R.string.back_to_home)'),
    (r'"Calculating best driving route\.\.\."', 'stringResource(R.string.calculating_route)'),
    (r'"Connecting Farmers to Better Markets"', 'stringResource(R.string.connecting_farmers)'),
    (r'"Create Account"', 'stringResource(R.string.create_account)'),
    (r'"Crop or Market not found"', 'stringResource(R.string.crop_not_found)'),
    (r'"Demand \(High/Normal/Low\)"', 'stringResource(R.string.demand_high_normal_low)'),
    (r'"Destination Mandi"', 'stringResource(R.string.destination_mandi)'),
    (r'"Edit"', 'stringResource(R.string.edit)'),
    (r'"Find nearby mandis & plan your route"', 'stringResource(R.string.find_nearby_mandis)'),
    (r'"I\'m a Farmer"', 'stringResource(R.string.im_farmer)'),
    (r'"I\'m a Mandi / Market"', 'stringResource(R.string.im_mandi)'),
    (r'"Kisan Sahayak is thinking\.\.\."', 'stringResource(R.string.kisan_thinking)'),
    (r'"KisanSetu"', 'stringResource(R.string.app_name)'),
    (r'"KisanSetu Map"', 'stringResource(R.string.kisansetu_map)'),
    (r'"Mandi / Shop Name \*"', 'stringResource(R.string.mandi_shop_name)'),
    (r'"Mandi Notifications"', 'stringResource(R.string.mandi_notifications)'),
    (r'"Mandi Registration"', 'stringResource(R.string.mandi_registration)'),
    (r'"Microphone permission is required for voice input\."', 'stringResource(R.string.mic_permission_required)'),
    (r'"Navigate"', 'stringResource(R.string.navigate)'),
    (r'"No new alerts\. We\'ll notify you when something important changes\."', 'stringResource(R.string.no_new_alerts)'),
    (r'"No notifications\."', 'stringResource(R.string.no_notifications)'),
    (r'"Notifications"', 'stringResource(R.string.notifications)'),
    (r'"Owner / Manager Name \*"', 'stringResource(R.string.owner_name)'),
    (r'"Pickup Location"', 'stringResource(R.string.pickup_location)'),
    (r'"Please fill required fields"', 'stringResource(R.string.please_fill_required)'),
    (r'"Price Trends Coming Soon"', 'stringResource(R.string.price_trends_soon)'),
    (r'"Price per Quintal \(₹\)"', 'stringResource(R.string.price_per_quintal)'),
    (r'"Profile Picture"', 'stringResource(R.string.profile_picture)'),
    (r'"Recommended Mandi"', 'stringResource(R.string.recommended_mandi)'),
    (r'"Register Mandi"', 'stringResource(R.string.register_mandi)'),
    (r'"Request Transport"', 'stringResource(R.string.request_transport)'),
    (r'"Retry"', 'stringResource(R.string.retry)'),
    (r'"Retry Permission"', 'stringResource(R.string.retry_permission)'),
    (r'"Search mandi or location"', 'stringResource(R.string.search_mandi)'),
    (r'"Select"', 'stringResource(R.string.select)'),
    (r'"Selected"', 'stringResource(R.string.selected)'),
    (r'"Selected Mandi"', 'stringResource(R.string.selected_mandi)'),
    (r'"Send"', 'stringResource(R.string.send)'),
    (r'"Send Sell Request"', 'stringResource(R.string.send_sell_request)'),
    (r'"Sorry, Kisan Sahayak is temporarily unavailable\. Please try again\."', 'stringResource(R.string.sahayak_unavailable)'),
    (r'"Speak"', 'stringResource(R.string.speak)'),
    (r'"Stop Listening"', 'stringResource(R.string.stop_listening)'),
    (r'"Transport Options"', 'stringResource(R.string.transport_options)'),
    (r'"Transport Summary"', 'stringResource(R.string.transport_summary)'),
    (r'"Who are you\?"', 'stringResource(R.string.who_are_you)'),
    (r'"Add Crop"', 'stringResource(R.string.add_crop)'),
    (r'"Welcome Back"', 'stringResource(R.string.welcome_back)'),
    (r'"View details"', 'stringResource(R.string.view_details_lower)'),
    
    # Parametrized strings
    (r'"Capacity: \$\{vehicle\.capacityQuintals\} quintals"', 'stringResource(R.string.capacity_quintals, vehicle.capacityQuintals)'),
    (r'"Vehicle Capacity: \$\{vehicle\.capacityQuintals\} quintals"', 'stringResource(R.string.vehicle_capacity_quintals, vehicle.capacityQuintals)'),
    (r'"Quantity: \$quantity quintals"', 'stringResource(R.string.quantity_val_quintals, quantity.toString())'),
    (r'"Quantity: \$quantity Quintals"', 'stringResource(R.string.quantity_val_quintals_cap, quantity.toString())'),
    (r'"Sell \$\{crop\.cropName\} at \$\{market\.name\}"', 'stringResource(R.string.sell_crop_at_market, crop.cropName, market.name)'),
    (r'"Price: ₹\$\{crop\.pricePerQuintal\} / Quintal"', 'stringResource(R.string.price_per_quintal_val, crop.pricePerQuintal.toString())'),
    (r'"Estimated Value: ₹\$grossValue"', 'stringResource(R.string.estimated_value_val, grossValue.toString())'),
    (r'"Travel Time: \$durationStr"', 'stringResource(R.string.travel_time_val, durationStr)'),
    (r'"Request #\$requestId"', 'stringResource(R.string.request_id, requestId)'),
    (r'"Farmer: \$\{req\.farmerName\}"', 'stringResource(R.string.farmer_name, req.farmerName)'),
    (r'"Location: \$\{req\.farmerLocation\}"', 'stringResource(R.string.location_name, req.farmerLocation)'),
]

for root, _, files in os.walk('app/src/main/java'):
    for file in files:
        if file.endswith('.kt') and file != 'LanguageSelectionScreen.kt':
            path = os.path.join(root, file)
            with open(path, 'r') as f:
                content = f.read()
            
            original_content = content
            for pat, repl in replacements:
                content = re.sub(pat, repl, content)

            if content != original_content:
                if 'import androidx.compose.ui.res.stringResource' not in content:
                    content = content.replace('import androidx.compose.runtime.Composable', 'import androidx.compose.ui.res.stringResource\nimport androidx.compose.runtime.Composable')
                if 'import com.example.R' not in content:
                    content = content.replace('package com.example.ui.screens\n', 'package com.example.ui.screens\n\nimport com.example.R\n')
                    content = content.replace('package com.example.ui\n', 'package com.example.ui\n\nimport com.example.R\n')
                with open(path, 'w') as f:
                    f.write(content)
                print(f"Updated {file}")

print("Done bulk replacement.")
