import re

with open("app/src/main/java/com/example/ui/screens/LocationAutocomplete.kt", "r") as f:
    content = f.read()

# Replace initialization
old_init = """        if (!Places.isInitialized()) {
            Places.initialize(context.applicationContext, BuildConfig.GOOGLE_MAPS_API_KEY)
        }"""
new_init = """        if (!Places.isInitialized()) {
            Places.initializeWithNewPlacesApiEnabled(context.applicationContext, BuildConfig.GOOGLE_MAPS_API_KEY)
        }"""
content = content.replace(old_init, new_init)

# Replace failure listener for autocomplete
old_failure_auto = """                            ?.addOnFailureListener {
                                Log.e("Places", "Error finding predictions", it)
                                searchError = "location_search_error"
                                predictions = emptyList()
                                isSearching = false
                            }"""
new_failure_auto = """                            ?.addOnFailureListener { exception ->
                                val apiException = exception as? com.google.android.gms.common.api.ApiException
                                val statusCode = apiException?.statusCode
                                val statusMessage = apiException?.status?.statusMessage
                                val errorMsg = "Places API Error: $statusCode - ${statusMessage ?: exception.message}"
                                Log.e("Places", errorMsg, exception)
                                searchError = errorMsg
                                predictions = emptyList()
                                isSearching = false
                            }"""
content = content.replace(old_failure_auto, new_failure_auto)

# Replace failure listener for fetch place
old_failure_fetch = """                                            ?.addOnFailureListener {
                                                Log.e("Places", "Place fetch failed", it)
                                                onPlaceSelected(null, null, fullAddress)
                                            }"""
new_failure_fetch = """                                            ?.addOnFailureListener { exception ->
                                                val apiException = exception as? com.google.android.gms.common.api.ApiException
                                                val statusCode = apiException?.statusCode
                                                val statusMessage = apiException?.status?.statusMessage
                                                Log.e("Places", "Place fetch failed: $statusCode - ${statusMessage ?: exception.message}", exception)
                                                onPlaceSelected(null, null, fullAddress)
                                            }"""
content = content.replace(old_failure_fetch, new_failure_fetch)

# Need to update the display of the error so it doesn't just show the generic resource string if it's an API error
old_error_display = 'text = if (searchError == "location_search_error") stringResource(R.string.location_search_error) else searchError!!,'
new_error_display = 'text = if (searchError == "location_search_error") stringResource(R.string.location_search_error) else searchError!!,'

with open("app/src/main/java/com/example/ui/screens/LocationAutocomplete.kt", "w") as f:
    f.write(content)
