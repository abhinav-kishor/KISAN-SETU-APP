import re

with open("app/src/main/java/com/example/ui/screens/MarketComparisonScreen.kt", "r") as f:
    content = f.read()

# Collect user location
content = content.replace(
    'val routeDurations by mapViewModel.routeDurations.collectAsState()',
    'val routeDurations by mapViewModel.routeDurations.collectAsState()\n    val userLocation by mapViewModel.userLocation.collectAsState()'
)

# Update LaunchedEffect
content = content.replace(
    """    LaunchedEffect(locationPermissionsState.allPermissionsGranted) {
        if (locationPermissionsState.allPermissionsGranted) {
            mapViewModel.loadLocationAndRoutes(context, MarketRepository.availableMarkets.value)
        }
    }""",
    """    LaunchedEffect(locationPermissionsState.allPermissionsGranted, userLocation) {
        if (locationPermissionsState.allPermissionsGranted || userLocation != null) {
            mapViewModel.loadLocationAndRoutes(context, MarketRepository.availableMarkets.value)
        }
    }"""
)

# Update UI conditional
content = content.replace(
    'if (!locationPermissionsState.allPermissionsGranted) {',
    'if (!locationPermissionsState.allPermissionsGranted && userLocation == null) {'
)

with open("app/src/main/java/com/example/ui/screens/MarketComparisonScreen.kt", "w") as f:
    f.write(content)
