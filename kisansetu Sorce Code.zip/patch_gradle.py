import re

with open("app/build.gradle.kts", "r") as f:
    content = f.read()

if "implementation(libs.places)" not in content:
    content = content.replace(
        'implementation(libs.play.services.maps)',
        'implementation(libs.play.services.maps)\n  implementation(libs.places)'
    )

with open("app/build.gradle.kts", "w") as f:
    f.write(content)
