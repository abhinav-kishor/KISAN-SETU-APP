import re

with open('app/src/main/java/com/example/ui/AuthViewModel.kt', 'r') as f:
    content = f.read()

# Fix verifyOTPAndSignUp
old_verify = """                    try {
                        user.updateEmail(finalEmail).await()
                        user.updatePassword(pass).await()
                        
                        if (realEmail != null) {
                            user.sendEmailVerification().await()
                        }
                    } catch (e: Exception) {
                        // It might fail if they already have an account with that email.
                        Log.e("Auth", "Failed to update email/pwd. Proceeding with phone auth", e)
                    }"""

new_verify = """                    try { user.updateEmail(finalEmail).await() } catch (e: Exception) { Log.e("Auth", "Failed to update email", e) }
                    try { user.updatePassword(pass).await() } catch (e: Exception) { Log.e("Auth", "Failed to update password", e) }
                    if (realEmail != null) {
                        try { user.sendEmailVerification().await() } catch (e: Exception) { Log.e("Auth", "Failed to send email verification", e) }
                    }"""

content = content.replace(old_verify, new_verify)

# Fix updateEmail
old_update_email = """                try {
                    // Update in Firebase Auth and Firestore
                    user.updateEmail(newEmail).await()
                    db.collection("users").document(user.uid).update("email", newEmail).await()
                    // Re-trigger listener or reload
                    val currentState = _userState.value
                    if (currentState is UserState.SignedIn) {
                        _userState.value = currentState.copy(email = newEmail)
                    }
                } catch (e: Exception) {
                    Log.e("Auth", "Email update failed", e)
                }"""

new_update_email = """                try {
                    db.collection("users").document(user.uid).update("email", newEmail).await()
                    val currentState = _userState.value
                    if (currentState is UserState.SignedIn) {
                        _userState.value = currentState.copy(email = newEmail)
                    }
                } catch (e: Exception) {
                    Log.e("Auth", "Firestore Email update failed", e)
                }
                
                try {
                    user.updateEmail(newEmail).await()
                } catch (e: Exception) {
                    Log.e("Auth", "Firebase Auth Email update failed (ignored)", e)
                }"""

content = content.replace(old_update_email, new_update_email)

with open('app/src/main/java/com/example/ui/AuthViewModel.kt', 'w') as f:
    f.write(content)
