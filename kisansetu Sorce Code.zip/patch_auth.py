import re

with open('app/src/main/java/com/example/ui/AuthViewModel.kt', 'r') as f:
    content = f.read()

# Add BankDetails data class and update UserState.SignedIn
content = content.replace(
    'data class SignedIn(val uid: String, val displayName: String, val email: String, val phoneNumber: String, val isEmailVerified: Boolean = false) : UserState()',
    'data class SignedIn(val uid: String, val displayName: String, val email: String, val phoneNumber: String, val isEmailVerified: Boolean = false, val bankDetails: BankDetails? = null) : UserState()'
)

if 'data class BankDetails' not in content:
    content = content.replace(
        'sealed class UserState {',
        'data class BankDetails(val accountHolderName: String = "", val bankName: String = "", val accountNumber: String = "", val ifscCode: String = "")\n\nsealed class UserState {'
    )

# Fix the auth state listener to be robust and fetch bank details
old_listener = """        auth.addAuthStateListener { firebaseAuth ->
            val user = firebaseAuth.currentUser
            if (user != null) {
                // Fetch the user's display name from Firestore if it's missing in FirebaseAuth
                viewModelScope.launch {
                    try {
                        val document = db.collection("users").document(user.uid).get().await()
                        val firestoreName = document.getString("displayName")
                        val phone = document.getString("phoneNumber") ?: "Not added"
                        
                        _userState.value = UserState.SignedIn(
                            uid = user.uid,
                            displayName = firestoreName ?: user.displayName ?: "Farmer",
                            email = user.email ?: "",
                            phoneNumber = phone, isEmailVerified = user.isEmailVerified
                        )
                    } catch (e: Exception) {
                        _userState.value = UserState.SignedIn(
                            uid = user.uid,
                            displayName = user.displayName ?: "Farmer",
                            email = user.email ?: "",
                            phoneNumber = "Not added", isEmailVerified = user.isEmailVerified
                        )
                    }
                }
            } else {
                _userState.value = UserState.SignedOut
            }
        }"""

new_listener = """        auth.addAuthStateListener { firebaseAuth ->
            val user = firebaseAuth.currentUser
            if (user != null) {
                // Immediate update to avoid disappearing profile issue
                _userState.value = UserState.SignedIn(
                    uid = user.uid,
                    displayName = user.displayName ?: "Farmer",
                    email = user.email ?: "",
                    phoneNumber = user.phoneNumber ?: "Not available",
                    isEmailVerified = user.isEmailVerified
                )
                // Fetch latest data from Firestore
                viewModelScope.launch {
                    try {
                        val document = db.collection("users").document(user.uid).get().await()
                        val firestoreName = document.getString("displayName")
                        val phone = document.getString("phoneNumber") ?: user.phoneNumber ?: "Not available"
                        val email = document.getString("email") ?: user.email ?: ""
                        
                        var bankDetails: BankDetails? = null
                        val bd = document.get("bankDetails") as? Map<String, String>
                        if (bd != null) {
                            bankDetails = BankDetails(
                                accountHolderName = bd["accountHolderName"] ?: "",
                                bankName = bd["bankName"] ?: "",
                                accountNumber = bd["accountNumber"] ?: "",
                                ifscCode = bd["ifscCode"] ?: ""
                            )
                        }
                        
                        _userState.value = UserState.SignedIn(
                            uid = user.uid,
                            displayName = firestoreName ?: user.displayName ?: "Farmer",
                            email = email,
                            phoneNumber = phone, 
                            isEmailVerified = user.isEmailVerified,
                            bankDetails = bankDetails
                        )
                    } catch (e: Exception) {
                        // ignore, keep the immediate update
                    }
                }
            } else {
                _userState.value = UserState.SignedOut
            }
        }"""

content = content.replace(old_listener, new_listener)

# Add updateEmail and updateBankDetails methods
new_methods = """
    fun updateEmail(newEmail: String) {
        val user = auth.currentUser
        if (user != null) {
            viewModelScope.launch {
                try {
                    // Update in Firestore
                    db.collection("users").document(user.uid).update("email", newEmail).await()
                    // Re-trigger listener or reload
                    val currentState = _userState.value
                    if (currentState is UserState.SignedIn) {
                        _userState.value = currentState.copy(email = newEmail)
                    }
                } catch (e: Exception) {
                    Log.e("Auth", "Email update failed", e)
                }
            }
        }
    }

    fun updateBankDetails(bankDetails: BankDetails) {
        val user = auth.currentUser
        if (user != null) {
            viewModelScope.launch {
                try {
                    db.collection("users").document(user.uid).update(
                        "bankDetails", mapOf(
                            "accountHolderName" to bankDetails.accountHolderName,
                            "bankName" to bankDetails.bankName,
                            "accountNumber" to bankDetails.accountNumber,
                            "ifscCode" to bankDetails.ifscCode
                        )
                    ).await()
                    val currentState = _userState.value
                    if (currentState is UserState.SignedIn) {
                        _userState.value = currentState.copy(bankDetails = bankDetails)
                    }
                } catch (e: Exception) {
                    Log.e("Auth", "Bank details update failed", e)
                }
            }
        }
    }

    fun reloadUser() {
"""

content = content.replace('    fun reloadUser() {', new_methods)

with open('app/src/main/java/com/example/ui/AuthViewModel.kt', 'w') as f:
    f.write(content)

