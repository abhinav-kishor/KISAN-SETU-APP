import re

with open("app/src/main/java/com/example/ui/screens/FarmerHomeScreen.kt", "r") as f:
    content = f.read()

# Make sure we have MapViewModel
if "mapViewModel: MapViewModel" not in content:
    content = content.replace(
        "fun FarmerHomeScreen(navController: NavController)",
        "fun FarmerHomeScreen(navController: NavController, mapViewModel: MapViewModel = androidx.lifecycle.viewmodel.compose.viewModel())"
    )
    
    # And update onPlaceSelected to use it
    content = content.replace(
        """onPlaceSelected = { latLng, placeId, address ->
                            // Update the Farmer's location coordinates here if needed in the future
                            // E.g., mapViewModel.setUserLocation(latLng)
                        },""",
        """onPlaceSelected = { latLng, placeId, address ->
                            if (latLng != null) {
                                mapViewModel.setUserLocation(latLng)
                            }
                        },"""
    )

with open("app/src/main/java/com/example/ui/screens/FarmerHomeScreen.kt", "w") as f:
    f.write(content)
