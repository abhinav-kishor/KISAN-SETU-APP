import re

with open("gradle/libs.versions.toml", "r") as f:
    content = f.read()

if "places =" not in content:
    content = content.replace(
        'googleid = "1.1.1"',
        'googleid = "1.1.1"\nplaces = "4.0.0"'
    )
    content = content.replace(
        'googleid = { group = "com.google.android.libraries.identity.googleid", name = "googleid", version.ref = "googleid" }',
        'googleid = { group = "com.google.android.libraries.identity.googleid", name = "googleid", version.ref = "googleid" }\nplaces = { group = "com.google.android.libraries.places", name = "places", version.ref = "places" }'
    )

with open("gradle/libs.versions.toml", "w") as f:
    f.write(content)
