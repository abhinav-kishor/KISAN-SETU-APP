import re

with open("app/src/main/java/com/example/ui/screens/FarmerHomeScreen.kt", "r") as f:
    content = f.read()

# Replace Indore, MP with dynamic location
content = content.replace(
    'Text("Indore, MP", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)',
    'Text(location.split(",").take(2).joinToString(",").take(20), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)'
)

with open("app/src/main/java/com/example/ui/screens/FarmerHomeScreen.kt", "w") as f:
    f.write(content)
