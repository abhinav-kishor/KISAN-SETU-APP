import re

with open("app/src/main/java/com/example/ui/AuthViewModel.kt", "r") as f:
    content = f.read()

reload_pattern = r"(fun reloadUser\(\)\s*\{\s*viewModelScope\.launch\s*\{\s*try\s*\{\s*auth\.currentUser\?.reload\(\)\?.await\(\))([\s\S]*?)(\} catch)"

def replace_reload(m):
    return m.group(1) + """
                loadProfile()
            """ + m.group(3)

content = re.sub(reload_pattern, replace_reload, content)

with open("app/src/main/java/com/example/ui/AuthViewModel.kt", "w") as f:
    f.write(content)

