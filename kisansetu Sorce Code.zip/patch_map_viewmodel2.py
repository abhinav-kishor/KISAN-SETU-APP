import re

with open("app/src/main/java/com/example/ui/screens/MapViewModel.kt", "r") as f:
    content = f.read()

# First, revert the previous bad patch if it applied poorly
if "dummy to balance brackets if needed" in content:
    print("Fixing the function")

# Let's just redefine the whole loadLocationAndRoutes function using regex
pattern = r"fun loadLocationAndRoutes\(context: Context, markets: List<Market>\) \{[\s\S]*?private suspend fun fetchRoutesForMarkets"

new_func = """fun loadLocationAndRoutes(context: Context, markets: List<Market>) {
        if (_isLoading.value) return // already loading
        viewModelScope.launch {
            _isLoading.value = true
            _locationError.value = null
            
            if (_userLocation.value != null) {
                // Use explicitly set location
                fetchRoutesForMarkets(_userLocation.value!!, markets)
            } else {
                val location = getCurrentLocation(context)
                if (location != null) {
                    val originLatLng = LatLng(location.latitude, location.longitude)
                    _userLocation.value = originLatLng
                    fetchRoutesForMarkets(originLatLng, markets)
                } else {
                    _locationError.value = "Location access is required to calculate the actual driving route and transport cost."
                    _isLoading.value = false
                }
            }
        }
    }

    private suspend fun fetchRoutesForMarkets"""

content = re.sub(pattern, new_func, content)

with open("app/src/main/java/com/example/ui/screens/MapViewModel.kt", "w") as f:
    f.write(content)
