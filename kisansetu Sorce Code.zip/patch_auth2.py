import re

with open('app/src/main/java/com/example/ui/AuthViewModel.kt', 'r') as f:
    content = f.read()

old_email_update = """                    // Update in Firestore
                    db.collection("users").document(user.uid).update("email", newEmail).await()"""

new_email_update = """                    // Update in Firebase Auth and Firestore
                    user.updateEmail(newEmail).await()
                    db.collection("users").document(user.uid).update("email", newEmail).await()"""

content = content.replace(old_email_update, new_email_update)

with open('app/src/main/java/com/example/ui/AuthViewModel.kt', 'w') as f:
    f.write(content)
