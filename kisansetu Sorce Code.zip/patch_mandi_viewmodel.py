import re

with open("app/src/main/java/com/example/ui/screens/MandiViewModel.kt", "r") as f:
    content = f.read()

content = content.replace(
    'val shopPhotoUri: String? = null',
    'val shopPhotoUri: String? = null,\n    val latitude: Double? = null,\n    val longitude: Double? = null,\n    val placeId: String? = null'
)

with open("app/src/main/java/com/example/ui/screens/MandiViewModel.kt", "w") as f:
    f.write(content)
