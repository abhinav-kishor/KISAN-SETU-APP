import sys

with open("app/src/main/java/com/example/ui/screens/MarketComparisonScreen.kt", "r") as f:
    content = f.read()

old_list = """            Text("Found ${sortedMarkets.size} markets for Wheat", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
            Spacer(modifier = Modifier.height(16.dp))
            LazyColumn {
                items(sortedMarkets) { calc ->
                    MarketCard(calc) {
                        navController.navigate("mandi_overview/${calc.market.id}/$quantity")
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }
            }"""

new_list = """            val cropDisplayName = if (!selectedCrop.isNullOrBlank()) selectedCrop else "Wheat"
            Text("Found ${sortedMarkets.size} markets for $cropDisplayName", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
            Spacer(modifier = Modifier.height(16.dp))
            LazyColumn {
                items(sortedMarkets) { calc ->
                    MarketCard(calc) {
                        if (selectedCrop.isNullOrBlank()) {
                            navController.navigate("mandi_overview/${calc.market.id}/$quantity")
                        } else {
                            val cropId = calc.market.crops.find { it.cropName.equals(selectedCrop.trim(), ignoreCase = true) }?.id
                            if (cropId != null) {
                                navController.navigate("crop_details/${calc.market.id}/$cropId/$quantity")
                            } else {
                                navController.navigate("mandi_overview/${calc.market.id}/$quantity")
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }
            }"""

content = content.replace(old_list, new_list)

with open("app/src/main/java/com/example/ui/screens/MarketComparisonScreen.kt", "w") as f:
    f.write(content)
