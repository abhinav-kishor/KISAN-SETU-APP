import re

with open('app/src/main/java/com/example/ui/screens/MandiRegistrationScreen.kt', 'r') as f:
    content = f.read()

imports = """import androidx.compose.ui.res.stringResource
import com.example.R
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController"""

new_imports = imports + """
import android.net.Uri
import android.content.ContentValues
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.PickVisualMediaRequest
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.ui.Alignment
import coil.compose.AsyncImage"""

content = content.replace(imports, new_imports)

# Add state variables
state_old = """    var city by remember { mutableStateOf("") }
    var contactNumber by remember { mutableStateOf("") }
    val context = LocalContext.current"""

state_new = state_old + """
    var shopPhotoUri by remember { mutableStateOf<Uri?>(null) }
    var cameraUri by remember { mutableStateOf<Uri?>(null) }
    
    val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) shopPhotoUri = uri
    }
    
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        if (success) {
            shopPhotoUri = cameraUri
        }
    }
    
    fun createImageUri(): Uri? {
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "shop_photo_${System.currentTimeMillis()}.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
        }
        return context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
    }"""
content = content.replace(state_old, state_new)

# Add back button to TopAppBar
topbar_old = """            TopAppBar(
                title = { Text(stringResource(R.string.mandi_registration)) },
                colors = TopAppBarDefaults.topAppBarColors("""
topbar_new = """            TopAppBar(
                title = { Text(stringResource(R.string.mandi_registration)) },
                navigationIcon = {
                    IconButton(onClick = { navController.navigate("role_selection") { popUpTo(0) { inclusive = true } } }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors("""
content = content.replace(topbar_old, topbar_new)

# Add Shop Photo UI
form_old = """            Spacer(modifier = Modifier.height(16.dp))
            OutlinedTextField(
                value = contactNumber,
                onValueChange = { contactNumber = it },
                label = { Text(stringResource(R.string.contact_number)) },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(32.dp))"""

form_new = """            Spacer(modifier = Modifier.height(16.dp))
            OutlinedTextField(
                value = contactNumber,
                onValueChange = { contactNumber = it },
                label = { Text(stringResource(R.string.contact_number)) },
                modifier = Modifier.fillMaxWidth()
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            Text("Shop Photo", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
            
            if (shopPhotoUri != null) {
                Box(modifier = Modifier.fillMaxWidth().height(200.dp).clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.surfaceVariant)) {
                    AsyncImage(
                        model = shopPhotoUri,
                        contentDescription = "Shop Photo",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    IconButton(
                        onClick = { shopPhotoUri = null },
                        modifier = Modifier.align(Alignment.TopEnd).padding(8.dp).background(MaterialTheme.colorScheme.surface.copy(alpha = 0.7f), androidx.compose.foundation.shape.CircleShape)
                    ) {
                        Text("X", fontWeight = FontWeight.Bold)
                    }
                }
            } else {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Button(
                        onClick = {
                            val uri = createImageUri()
                            cameraUri = uri
                            if (uri != null) {
                                cameraLauncher.launch(uri)
                            }
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.PhotoCamera, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Camera")
                    }
                    Button(
                        onClick = {
                            galleryLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.PhotoLibrary, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Gallery")
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(32.dp))"""
content = content.replace(form_old, form_new)

# Update MandiProfile creation
profile_old = """                        val profile = MandiProfile(
                            mandiName = mandiName,
                            mandiId = mandiId,
                            ownerName = ownerName,
                            address = address,
                            city = city,
                            contactNumber = contactNumber
                        )"""
profile_new = """                        val profile = MandiProfile(
                            mandiName = mandiName,
                            mandiId = mandiId,
                            ownerName = ownerName,
                            address = address,
                            city = city,
                            contactNumber = contactNumber,
                            shopPhotoUri = shopPhotoUri?.toString()
                        )"""
content = content.replace(profile_old, profile_new)

with open('app/src/main/java/com/example/ui/screens/MandiRegistrationScreen.kt', 'w') as f:
    f.write(content)
