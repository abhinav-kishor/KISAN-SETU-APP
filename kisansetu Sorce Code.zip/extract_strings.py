import os
import re

strings = set()
for root, dirs, files in os.walk('app/src/main/java'):
    for file in files:
        if file.endswith('.kt'):
            with open(os.path.join(root, file), 'r') as f:
                content = f.read()
                # Find all Text("...") or text = "..." or label = { Text("...") } or placeholder = { Text("...") }
                matches = re.findall(r'Text\(\s*"([^"\\]+)"\s*\)', content)
                matches += re.findall(r'text\s*=\s*"([^"\\]+)"', content)
                matches += re.findall(r'label\s*=\s*"([^"\\]+)"', content)
                matches += re.findall(r'placeholder\s*=\s*"([^"\\]+)"', content)
                matches += re.findall(r'contentDescription\s*=\s*"([^"\\]+)"', content)
                matches += re.findall(r'title\s*=\s*"([^"\\]+)"', content)
                matches += re.findall(r'description\s*=\s*"([^"\\]+)"', content)
                
                # Toast.makeText(context, "...", Toast.LENGTH_SHORT)
                matches += re.findall(r'makeText\(.*?"([^"\\]+)".*?\)', content)
                
                for m in matches:
                    if len(m) > 1 and '{' not in m and '$' not in m:
                        strings.add(m)

for s in sorted(list(strings)):
    print(s)
