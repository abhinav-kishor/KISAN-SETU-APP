import re

with open("app/src/main/java/com/example/ui/KisanSetuApp.kt", "r") as f:
    content = f.read()

content = content.replace(
    'composable("farmer_home") { FarmerHomeScreen(navController) }',
    'composable("farmer_home") { FarmerHomeScreen(navController, mapViewModel) }'
)

with open("app/src/main/java/com/example/ui/KisanSetuApp.kt", "w") as f:
    f.write(content)
