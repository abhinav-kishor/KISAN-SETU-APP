print("Sikandra Mandi Agra coordinates")
