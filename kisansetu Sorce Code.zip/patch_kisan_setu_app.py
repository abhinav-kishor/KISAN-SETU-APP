import re

with open("app/src/main/java/com/example/ui/KisanSetuApp.kt", "r") as f:
    content = f.read()

# Add viewmodel instantiation
vm_pattern = r"(val mandiViewModel: MandiViewModel = androidx\.lifecycle\.viewmodel\.compose\.viewModel\(\))"
vm_replacement = r"\1\n    val aiSupportViewModel: AiSupportViewModel = androidx.lifecycle.viewmodel.compose.viewModel()"
content = re.sub(vm_pattern, vm_replacement, content)

# Add navigation route
route_pattern = r"(composable\(\"profile\"\)\s*\{\s*ProfileScreen\(navController,\s*authViewModel\)\s*\})"
route_replacement = r"""\1
            composable("ai_support_call") {
                aiSupportViewModel.setAuthViewModel(authViewModel)
                AiSupportCallScreen(navController, aiSupportViewModel)
            }"""
content = re.sub(route_pattern, route_replacement, content)

# Make sure AiSupportViewModel and AiSupportCallScreen are imported
import_pattern = r"(import com\.example\.ui\.screens\.ProfileScreen)"
import_replacement = r"\1\nimport com.example.ui.screens.AiSupportCallScreen\nimport com.example.ui.screens.AiSupportViewModel"
content = re.sub(import_pattern, import_replacement, content)

with open("app/src/main/java/com/example/ui/KisanSetuApp.kt", "w") as f:
    f.write(content)
