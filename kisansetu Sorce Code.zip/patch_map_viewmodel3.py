import re

with open("app/src/main/java/com/example/ui/screens/MapViewModel.kt", "r") as f:
    content = f.read()

# Make setUserLocation clear the old routes so they recalculate
content = content.replace(
    """    fun setUserLocation(latLng: LatLng) {
        _userLocation.value = latLng
    }""",
    """    fun setUserLocation(latLng: LatLng) {
        _userLocation.value = latLng
        _routePolylines.value = emptyMap() // Clear old routes to force recalculation
        _routeDistancesKm.value = emptyMap()
        _routeDurations.value = emptyMap()
    }"""
)

with open("app/src/main/java/com/example/ui/screens/MapViewModel.kt", "w") as f:
    f.write(content)
