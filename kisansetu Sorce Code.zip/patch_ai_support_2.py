import re

with open("app/src/main/java/com/example/ui/screens/AiSupportViewModel.kt", "r") as f:
    content = f.read()

# Replace the sendToGoogleSheets method
new_method = """    private fun sendToGoogleSheets(complaintJson: JSONObject) {
        val payload = JSONObject().apply {
            put("farmerName", farmerName)
            put("phone", farmerPhone)
            put("crop", complaintJson.optString("crop", "N/A"))
            put("category", complaintJson.optString("category", "General Support"))
            put("complaint", complaintJson.optString("complaint", "Unknown"))
            put("summary", complaintJson.optString("summary", "No summary"))
            put("aiResponse", complaintJson.optString("aiResponse", "N/A"))
            put("location", "N/A")
            put("status", "New")
            put("sessionId", "KS-${System.currentTimeMillis()}")
        }
        
        val scriptUrl = "https://script.google.com/macros/s/AKfycbz_placeholder/exec"
        
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val url = java.net.URL(scriptUrl)
                val conn = url.openConnection() as java.net.HttpURLConnection
                conn.requestMethod = "POST"
                conn.setRequestProperty("Content-Type", "application/json; utf-8")
                conn.setRequestProperty("Accept", "application/json")
                conn.doOutput = true
                
                conn.outputStream.use { os ->
                    val input = payload.toString().toByteArray(Charsets.UTF_8)
                    os.write(input, 0, input.size)
                }
                
                val code = conn.responseCode
                Log.d("AiSupport", "Sheets response code: $code")
            } catch (e: Exception) {
                Log.e("AiSupport", "Failed to send to Sheets", e)
            } finally {
                _callState.value = CallState.COMPLETED
            }
        }
    }"""

pattern = r"    private fun sendToGoogleSheets\(complaintJson: JSONObject\) \{[\s\S]*?override fun onCleared"

content = re.sub(pattern, new_method + "\n\n    override fun onCleared", content)

# Remove okhttp imports if they exist
content = re.sub(r"import okhttp3\..*\n", "", content)

# Remove private val client = OkHttpClient()
content = content.replace("private val client = OkHttpClient()", "")

with open("app/src/main/java/com/example/ui/screens/AiSupportViewModel.kt", "w") as f:
    f.write(content)
