import re

with open("app/src/main/java/com/example/ui/screens/LocationAutocomplete.kt", "r") as f:
    content = f.read()

content = content.replace('import androidx.compose.ui.text.font.FontWeight', 'import androidx.compose.ui.text.font.FontWeight\nimport androidx.compose.ui.res.stringResource\nimport com.example.R')

content = content.replace(
    'searchError = "Unable to search locations. Please check your internet connection."',
    'searchError = "location_search_error"'
)

# And in the UI where it's displayed:
content = content.replace(
    'text = searchError!!,',
    'text = if (searchError == "location_search_error") stringResource(R.string.location_search_error) else searchError!!,'
)

content = content.replace(
    'text = "No matching locations found.",',
    'text = stringResource(R.string.no_matching_locations),'
)

with open("app/src/main/java/com/example/ui/screens/LocationAutocomplete.kt", "w") as f:
    f.write(content)
