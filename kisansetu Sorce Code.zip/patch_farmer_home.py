import re

with open("app/src/main/java/com/example/ui/screens/FarmerHomeScreen.kt", "r") as f:
    content = f.read()

# Replace the default location
content = content.replace(
    'var location by remember { mutableStateOf("Pune, Maharashtra") }',
    'var location by remember { mutableStateOf("Dayalbagh, Agra, Uttar Pradesh") }'
)

# Replace the OutlinedTextField for location
old_location_field = """                    OutlinedTextField(
                        value = location,
                        onValueChange = { location = it },
                        label = { Text(stringResource(R.string.location)) },
                        modifier = Modifier.fillMaxWidth()
                    )"""

new_location_field = """                    LocationAutocomplete(
                        location = location,
                        onLocationChange = { location = it },
                        onPlaceSelected = { latLng, placeId, address ->
                            // Update the Farmer's location coordinates here if needed in the future
                            // E.g., mapViewModel.setUserLocation(latLng)
                        },
                        label = stringResource(R.string.location)
                    )"""

content = content.replace(old_location_field, new_location_field)

with open("app/src/main/java/com/example/ui/screens/FarmerHomeScreen.kt", "w") as f:
    f.write(content)
