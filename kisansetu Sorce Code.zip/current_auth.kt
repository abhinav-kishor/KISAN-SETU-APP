package com.example.ui

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialException
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.*
import com.google.firebase.auth.PhoneAuthProvider.OnVerificationStateChangedCallbacks
import com.google.firebase.auth.PhoneAuthProvider.ForceResendingToken
import com.google.firebase.firestore.firestore
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.FirebaseException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.concurrent.TimeUnit

class AuthViewModel : ViewModel() {
    private val auth = Firebase.auth
    private val db = Firebase.firestore

    private val _userState = MutableStateFlow<UserState>(UserState.Loading)
    val userState: StateFlow<UserState> = _userState.asStateFlow()
    
    private val _verificationId = MutableStateFlow<String?>(null)
    val verificationId: StateFlow<String?> = _verificationId.asStateFlow()
    
    private var resendToken: ForceResendingToken? = null

    init {
        /**
         * =========================================================================
         * DEVELOPER DOCUMENTATION: FIREBASE PHONE AUTHENTICATION (DEMO/TESTING)
         * =========================================================================
         * 
         * To test Phone OTP Verification in an emulator or without sending real SMS:
         * 
         * 1. Go to Firebase Console -> Authentication -> Sign-in method -> Phone.
         * 2. Scroll down to "Phone numbers for testing".
         * 3. Add a test phone number (e.g., +91 9999999999) and a fixed OTP (e.g., 123456).
         * 
         * When this test number is entered in the app:
         * - Firebase will intentionally NOT send a real SMS.
         * - Firebase will successfully trigger `onCodeSent()`.
         * - Enter the fixed OTP assigned in the console to verify successfully.
         * - The flow uses the standard `PhoneAuthCredential` and behaves exactly like a real phone.
         * 
         * WARNING: Real SMS authentication requires Play Integrity/SafetyNet and may fail
         * in emulators. Do not claim real SMS is working unless tested on a physical device.
         * =========================================================================
         */
        auth.firebaseAuthSettings.setAppVerificationDisabledForTesting(true)
        
        auth.addAuthStateListener { firebaseAuth ->
            val user = firebaseAuth.currentUser
            if (user != null) {
                // Fetch the user's display name from Firestore if it's missing in FirebaseAuth
                viewModelScope.launch {
                    try {
                        val document = db.collection("users").document(user.uid).get().await()
                        val firestoreName = document.getString("displayName")
                        val phone = document.getString("phoneNumber") ?: "Not added"
                        
                        _userState.value = UserState.SignedIn(
                            uid = user.uid,
                            displayName = firestoreName ?: user.displayName ?: "Farmer",
                            email = user.email ?: "",
                            phoneNumber = phone, isEmailVerified = user.isEmailVerified
                        )
                    } catch (e: Exception) {
                        _userState.value = UserState.SignedIn(
                            uid = user.uid,
                            displayName = user.displayName ?: "Farmer",
                            email = user.email ?: "",
                            phoneNumber = "Not added", isEmailVerified = user.isEmailVerified
                        )
                    }
                }
            } else {
                _userState.value = UserState.SignedOut
            }
        }
    }

    fun startPhoneVerification(phoneNumber: String, activity: Activity) {
        _userState.value = UserState.Loading
        val optionsBuilder = PhoneAuthOptions.newBuilder(auth)
            .setPhoneNumber(phoneNumber)
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(activity)
            .setCallbacks(object : OnVerificationStateChangedCallbacks() {
                override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                    // Auto-retrieval or Instant verification (Test numbers)
                    // Wait for user to tap verify or we could auto sign-in
                    // For simplicity, we just fill the OTP or sign in, but let's let the user type if they want, 
                    // or auto sign in. Since we need to create account with password, we just store credential.code
                    if (credential.smsCode != null) {
                        // We could auto-fill, but we are not passing a callback to UI for that yet.
                    }
                    _userState.value = UserState.SignedOut // stop loading
                }

                override fun onVerificationFailed(e: com.google.firebase.FirebaseException) {
                    _userState.value = UserState.Error(e.localizedMessage ?: "Phone verification failed")
                }

                override fun onCodeSent(
                    verificationId: String,
                    token: ForceResendingToken
                ) {
                    _verificationId.value = verificationId
                    resendToken = token
                    _userState.value = UserState.SignedOut
                }
            })
            
        if (resendToken != null) {
            optionsBuilder.setForceResendingToken(resendToken!!)
        }
        PhoneAuthProvider.verifyPhoneNumber(optionsBuilder.build())
    }

    fun verifyOTPAndSignUp(verId: String, otp: String, name: String, phone: String, email: String, pass: String) {
        viewModelScope.launch {
            _userState.value = UserState.Loading
            try {
                // 1. Verify OTP
                val credential = PhoneAuthProvider.getCredential(verId, otp)
                val authResult = auth.signInWithCredential(credential).await()
                val user = authResult.user
                
                if (user != null) {
                    // 2. Set up Email & Password
                    val sanitizedPhone = phone.replace(Regex("[^0-9]"), "")
                    val finalEmail = if (email.isEmpty() || email == "NONE") "$sanitizedPhone@kisansetu.app" else email
                    val realEmail = if (email.isEmpty() || email == "NONE") null else email
                    
                    try {
                        user.updateEmail(finalEmail).await()
                        user.updatePassword(pass).await()
                        
                        if (realEmail != null) {
                            user.sendEmailVerification().await()
                        }
                    } catch (e: Exception) {
                        // It might fail if they already have an account with that email.
                        Log.e("Auth", "Failed to update email/pwd. Proceeding with phone auth", e)
                    }
                    
                    // 3. Save to Firestore
                    val userData = hashMapOf(
                        "uid" to user.uid,
                        "displayName" to name,
                        "email" to realEmail,
                        "phoneNumber" to phone,
                        "phoneVerified" to true,
                        "emailVerified" to false,
                        "role" to "farmer",
                        "createdAt" to System.currentTimeMillis(),
                        "updatedAt" to System.currentTimeMillis(),
                        "lastLogin" to System.currentTimeMillis()
                    )
                    db.collection("users").document(user.uid).set(userData).await()
                }
            } catch (e: FirebaseAuthInvalidCredentialsException) {
                _userState.value = UserState.Error("Invalid OTP. Please try again.")
            } catch (e: Exception) {
                val msg = e.message ?: ""
                if (msg.contains("session expired", ignoreCase = true)) {
                    _userState.value = UserState.Error("OTP expired. Please resend.")
                } else {
                    _userState.value = UserState.Error(e.localizedMessage ?: "Verification failed")
                }
            }
        }
    }

    fun signInWithEmailPassword(identifier: String, password: String) {
        viewModelScope.launch {
            _userState.value = UserState.Loading
            try {
                var loginEmail = identifier
                // If the user entered a phone number, lookup their real email in Firestore, 
                // or use the synthetic email if they don't have one.
                if (identifier.contains("@kisansetu.app")) {
                    val phone = identifier.replace("@kisansetu.app", "")
                    val query = db.collection("users").whereEqualTo("phoneNumber", phone).get().await()
                    if (!query.isEmpty) {
                        val doc = query.documents.first()
                        val savedEmail = doc.getString("email")
                        if (savedEmail != null) {
                            loginEmail = savedEmail
                        }
                    }
                }
                
                auth.signInWithEmailAndPassword(loginEmail, password).await()
                // The auth state listener will update the state to SignedIn
            } catch (e: FirebaseAuthInvalidCredentialsException) {
                _userState.value = UserState.Error("Invalid phone/email or password.")
            } catch (e: FirebaseAuthInvalidUserException) {
                _userState.value = UserState.Error("No account found.")
            } catch (e: Exception) {
                val msg = e.message ?: ""
                if (msg.contains("invalid credential", ignoreCase = true) || msg.contains("invalid password", ignoreCase = true)) {
                    _userState.value = UserState.Error("Invalid phone/email or password.")
                } else if (msg.contains("no user record", ignoreCase = true)) {
                    _userState.value = UserState.Error("No account found.")
                } else {
                    _userState.value = UserState.Error(e.localizedMessage ?: "Sign in failed")
                }
            }
        }
    }

    fun resetPassword(email: String) {
        viewModelScope.launch {
            try {
                auth.sendPasswordResetEmail(email).await()
            } catch (e: Exception) {
                _userState.value = UserState.Error(e.localizedMessage ?: "Password reset failed")
            }
        }
    }

    fun clearError() {
        if (_userState.value is UserState.Error) {
            _userState.value = UserState.SignedOut
        }
    }

    fun signInWithGoogle(context: Context) {
        viewModelScope.launch {
            try {
                // IMPORTANT: The google-services.json provided does NOT have a Web Client ID
                // configured in the oauth_client array. Google Sign-In requires a Web Client ID.
                // Replace "YOUR_WEB_CLIENT_ID" with the actual Web Client ID from your Firebase Console.
                val serverClientId = "YOUR_WEB_CLIENT_ID_PLACEHOLDER"
                val credentialManager = CredentialManager.create(context)
                
                val googleIdOption = GetGoogleIdOption.Builder()
                    .setFilterByAuthorizedAccounts(false)
                    .setServerClientId(serverClientId)
                    .setAutoSelectEnabled(true)
                    .build()
                
                val request = GetCredentialRequest.Builder()
                    .addCredentialOption(googleIdOption)
                    .build()
                
                val result = credentialManager.getCredential(context, request)
                val credential = result.credential
                
                if (credential is GoogleIdTokenCredential) {
                    val idToken = credential.idToken
                    val firebaseCredential = GoogleAuthProvider.getCredential(idToken, null)
                    
                    val authResult = auth.signInWithCredential(firebaseCredential).await()
                    
                    // Save user profile to Firestore
                    authResult.user?.let { user ->
                        val userData = hashMapOf(
                            "uid" to user.uid,
                            "displayName" to user.displayName,
                            "email" to user.email,
                            "lastLogin" to System.currentTimeMillis()
                        )
                        db.collection("users").document(user.uid).set(userData).await()
                    }
                } else {
                    Log.e("Auth", "Unexpected credential type")
                }
            } catch (e: Exception) {
                Log.e("Auth", "Sign-in failed", e)
            }
        }
    }

    fun reloadUser() {
        viewModelScope.launch {
            try {
                auth.currentUser?.reload()?.await()
                // The auth state listener will handle the rest
            } catch (e: Exception) {
                Log.e("Auth", "Failed to reload user", e)
            }
        }
    }

    fun signOut() {
        auth.signOut()
    }
}

sealed class UserState {
    object Loading : UserState()
    object SignedOut : UserState()
    data class SignedIn(val uid: String, val displayName: String, val email: String, val phoneNumber: String, val isEmailVerified: Boolean = false) : UserState()
    data class Error(val message: String) : UserState()
}
