import re

for filename in ["app/src/main/java/com/example/ui/screens/GoogleMapRoute.kt", "app/src/main/java/com/example/ui/screens/MapScreen.kt"]:
    with open(filename, "r") as f:
        content = f.read()

    if "import androidx.compose.runtime.setValue" not in content:
        content = content.replace(
            "import androidx.compose.runtime.remember",
            "import androidx.compose.runtime.remember\nimport androidx.compose.runtime.getValue\nimport androidx.compose.runtime.setValue"
        )
    
    with open(filename, "w") as f:
        f.write(content)
