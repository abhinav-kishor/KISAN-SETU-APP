import sys

with open("app/src/main/java/com/example/ui/MarketData.kt", "r") as f:
    content = f.read()

old_list = """listOf(
            Market("1", "Agra Mandi", 2550, 40, 28.7041, 77.1025, listOf(CropListing("c1", "Wheat", 2550, "High"))),
            Market("2", "Sikandra Mandi", 2480, 15, 28.5355, 77.3910, listOf(CropListing("c2", "Wheat", 2480, "Normal"))),
            Market("3", "Etmadpur Mandi", 2400, 10, 28.4595, 77.0266, listOf(CropListing("c3", "Wheat", 2400, "Low")))
        )"""

new_list = """listOf(
            Market("1", "Agra Mandi", 2550, 40, 28.7041, 77.1025, listOf(
                CropListing("c1_1", "Wheat", 2550, "High"),
                CropListing("c1_2", "Corn", 2200, "Normal"),
                CropListing("c1_3", "Potato", 1800, "High")
            )),
            Market("2", "Sikandra Mandi", 2480, 15, 28.5355, 77.3910, listOf(
                CropListing("c2_1", "Potato", 1850, "High"),
                CropListing("c2_2", "Tomato", 3000, "Normal"),
                CropListing("c2_3", "Wheat", 2480, "Normal"),
                CropListing("c2_4", "Brinjal", 1500, "Low")
            )),
            Market("3", "Etmadpur Mandi", 2400, 10, 28.4595, 77.0266, listOf(
                CropListing("c3_1", "Wheat", 2400, "Low"),
                CropListing("c3_2", "Mustard", 5000, "High"),
                CropListing("c3_3", "Onion", 2100, "High"),
                CropListing("c3_4", "Potato", 1700, "Normal")
            ))
        )"""

content = content.replace(old_list, new_list)

with open("app/src/main/java/com/example/ui/MarketData.kt", "w") as f:
    f.write(content)

with open("app/src/main/java/com/example/ui/KisanSetuApp.kt", "r") as f:
    content = f.read()

content = content.replace('import com.example.ui.screens.MarketDetailsScreen', 'import com.example.ui.screens.MarketDetailsScreen\nimport com.example.ui.screens.MandiOverviewScreen')

old_details_route = """composable("market_details/{marketId}") { backStackEntry ->
                val marketId = backStackEntry.arguments?.getString("marketId")
                MarketDetailsScreen(navController, marketId, mapViewModel, mandiViewModel)
            }"""

new_details_route = """composable("mandi_overview/{marketId}/{quantity}") { backStackEntry ->
                val marketId = backStackEntry.arguments?.getString("marketId")
                val quantity = backStackEntry.arguments?.getString("quantity")?.toIntOrNull() ?: 10
                MandiOverviewScreen(navController, marketId, quantity)
            }
            composable("crop_details/{marketId}/{cropId}/{quantity}") { backStackEntry ->
                val marketId = backStackEntry.arguments?.getString("marketId")
                val cropId = backStackEntry.arguments?.getString("cropId")
                val quantity = backStackEntry.arguments?.getString("quantity")?.toIntOrNull() ?: 10
                MarketDetailsScreen(navController, marketId, cropId, quantity, mapViewModel, mandiViewModel)
            }"""

content = content.replace(old_details_route, new_details_route)

with open("app/src/main/java/com/example/ui/KisanSetuApp.kt", "w") as f:
    f.write(content)

with open("app/src/main/java/com/example/ui/screens/MarketComparisonScreen.kt", "r") as f:
    content = f.read()

content = content.replace('navController.navigate("market_details/${calc.market.id}")', 'navController.navigate("mandi_overview/${calc.market.id}/$quantity")')
with open("app/src/main/java/com/example/ui/screens/MarketComparisonScreen.kt", "w") as f:
    f.write(content)
    
with open("app/src/main/java/com/example/ui/screens/FarmerHomeScreen.kt", "r") as f:
    content = f.read()

content = content.replace('navController.navigate("market_details/${bestMarketCalc.market.id}")', 'navController.navigate("mandi_overview/${bestMarketCalc.market.id}/$qtyInt")')
with open("app/src/main/java/com/example/ui/screens/FarmerHomeScreen.kt", "w") as f:
    f.write(content)

with open("app/src/main/java/com/example/ui/screens/KisanSahayakChatPanel.kt", "r") as f:
    content = f.read()

content = content.replace('navController.navigate("market_details/${message.recommendedMarketId}")', 'navController.navigate("mandi_overview/${message.recommendedMarketId}/10")')
with open("app/src/main/java/com/example/ui/screens/KisanSahayakChatPanel.kt", "w") as f:
    f.write(content)

