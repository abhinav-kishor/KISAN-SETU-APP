import re

with open('app/src/main/java/com/example/ui/AuthViewModel.kt', 'r') as f:
    content = f.read()

# Add UserProfileChangeRequest import if not exists
if 'import com.google.firebase.auth.userProfileChangeRequest' not in content:
    content = content.replace('import com.google.firebase.auth.FirebaseAuthInvalidUserException', 
                              'import com.google.firebase.auth.FirebaseAuthInvalidUserException\nimport com.google.firebase.auth.userProfileChangeRequest')

old_verify = """                    val sanitizedPhone = phone.replace(Regex("[^0-9]"), "")
                    val finalEmail = if (email.isEmpty() || email == "NONE") "$sanitizedPhone@kisansetu.app" else email
                    val realEmail = if (email.isEmpty() || email == "NONE") null else email
                    
                    try { user.updateEmail(finalEmail).await() } catch (e: Exception) { Log.e("Auth", "Failed to update email", e) }
                    try { user.updatePassword(pass).await() } catch (e: Exception) { Log.e("Auth", "Failed to update password", e) }"""

new_verify = """                    val sanitizedPhone = phone.replace(Regex("[^0-9]"), "")
                    val finalEmail = if (email.isEmpty() || email == "NONE") "$sanitizedPhone@kisansetu.app" else email
                    val realEmail = if (email.isEmpty() || email == "NONE") null else email
                    
                    try {
                        val profileUpdates = userProfileChangeRequest { displayName = name }
                        user.updateProfile(profileUpdates).await()
                    } catch (e: Exception) { Log.e("Auth", "Failed to update profile name", e) }
                    try { user.updateEmail(finalEmail).await() } catch (e: Exception) { Log.e("Auth", "Failed to update email", e) }
                    try { user.updatePassword(pass).await() } catch (e: Exception) { Log.e("Auth", "Failed to update password", e) }"""

content = content.replace(old_verify, new_verify)

with open('app/src/main/java/com/example/ui/AuthViewModel.kt', 'w') as f:
    f.write(content)
