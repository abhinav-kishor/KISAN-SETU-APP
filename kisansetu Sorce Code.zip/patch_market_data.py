import re

with open("app/src/main/java/com/example/ui/MarketData.kt", "r") as f:
    content = f.read()

# Update Agra Mandi
content = re.sub(
    r'Market\("1", "Agra Mandi", 2550, 40, 28\.7041, 77\.1025',
    'Market("1", "Agra Mandi", 2550, 40, 27.2023, 77.9396',
    content
)

# Update Sikandra Mandi
content = re.sub(
    r'Market\("2", "Sikandra Mandi", 2480, 15, 28\.5355, 77\.3910',
    'Market("2", "Sikandra Mandi", 2480, 15, 27.2204, 77.9343',
    content
)

# Update Etmadpur Mandi
content = re.sub(
    r'Market\("3", "Etmadpur Mandi", 2400, 10, 28\.4595, 77\.0266',
    'Market("3", "Etmadpur Mandi", 2400, 10, 27.2354, 78.1983',
    content
)

with open("app/src/main/java/com/example/ui/MarketData.kt", "w") as f:
    f.write(content)
