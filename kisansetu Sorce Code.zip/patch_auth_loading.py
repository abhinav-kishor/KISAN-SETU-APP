import re

with open("app/src/main/java/com/example/ui/AuthViewModel.kt", "r") as f:
    content = f.read()

# Remove the Firestore fetch from addAuthStateListener
listener_pattern = r"(auth\.addAuthStateListener\s*\{\s*firebaseAuth\s*->[\s\S]*?if\s*\(user\s*!=\s*null\)\s*\{)([\s\S]*?)(\} else \{)"

def replace_listener(m):
    prefix = m.group(1)
    suffix = m.group(3)
    # We just want to set SignedIn with basic info, OR we can just call loadProfile
    return prefix + """
                // We just set basic info first, then call loadProfile
                _userState.value = UserState.SignedIn(
                    uid = user.uid,
                    displayName = user.displayName ?: "Farmer",
                    email = user.email ?: "",
                    phoneNumber = user.phoneNumber ?: "Not available",
                    isEmailVerified = user.isEmailVerified
                )
                loadProfile()
            """ + suffix

content = re.sub(listener_pattern, replace_listener, content)

# Add loadProfile function
load_profile_func = """
    fun loadProfile() {
        val user = auth.currentUser
        if (user == null) {
            _userState.value = UserState.SignedOut
            return
        }
        
        viewModelScope.launch {
            // Keep basic SignedIn state while loading profile data, or use Loading if you prefer.
            // But we don't want to disrupt the UI if they are just navigating.
            try {
                val document = db.collection("users").document(user.uid).get().await()
                if (document.exists()) {
                    val firestoreName = document.getString("displayName")
                    val phone = document.getString("phoneNumber") ?: user.phoneNumber ?: "Not available"
                    val email = document.getString("email") ?: user.email ?: ""
                    
                    var bankDetails: BankDetails? = null
                    val bd = document.get("bankDetails") as? Map<String, String>
                    if (bd != null) {
                        bankDetails = BankDetails(
                            accountHolderName = bd["accountHolderName"] ?: "",
                            bankName = bd["bankName"] ?: "",
                            accountNumber = bd["accountNumber"] ?: "",
                            ifscCode = bd["ifscCode"] ?: ""
                        )
                    }
                    
                    _userState.value = UserState.SignedIn(
                        uid = user.uid,
                        displayName = firestoreName ?: user.displayName ?: "Farmer",
                        email = email,
                        phoneNumber = phone, 
                        isEmailVerified = user.isEmailVerified,
                        bankDetails = bankDetails
                    )
                } else {
                    // Profile document doesn't exist yet, that's fine.
                }
            } catch (e: Exception) {
                // If it fails due to permissions or network, we should probably let them know,
                // but setting Error will break the home screen if they are on it?
                // Wait, FarmerHomeScreen doesn't crash on Error. It just ignores it.
                // But if they are on ProfileScreen, they will see it.
                Log.e("Auth", "Failed to load profile", e)
                _userState.value = UserState.Error(e.localizedMessage ?: "Failed to load profile data")
            }
        }
    }
"""
content = content.replace("fun reloadUser() {", load_profile_func + "\n    fun reloadUser() {")

# Also fix signInWithEmailPassword to NOT query by phoneNumber
signin_pattern = r"(if \(identifier\.contains\(\"@kisansetu\.app\"\)\)\s*\{[\s\S]*?)(auth\.signInWithEmailAndPassword)"
def replace_signin(m):
    return """
                // We cannot query the users collection before authentication due to security rules.
                // If they enter a phone number without @kisansetu.app, we assume it's their email prefix.
                if (!identifier.contains("@") && android.util.Patterns.PHONE.matcher(identifier).matches()) {
                    val formatted = if (identifier.startsWith("+")) identifier else "+91$identifier"
                    loginEmail = "$formatted@kisansetu.app"
                }
                """ + m.group(2)
content = re.sub(signin_pattern, replace_signin, content)

with open("app/src/main/java/com/example/ui/AuthViewModel.kt", "w") as f:
    f.write(content)

