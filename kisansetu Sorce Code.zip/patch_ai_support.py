import re

# 1. Fix AiSupportCallScreen.kt imports
with open("app/src/main/java/com/example/ui/screens/AiSupportCallScreen.kt", "r") as f:
    content = f.read()
if "import androidx.compose.material.icons.filled.SmartToy" not in content:
    content = content.replace(
        "import androidx.compose.material.icons.filled.MicOff",
        "import androidx.compose.material.icons.filled.MicOff\nimport androidx.compose.material.icons.filled.SmartToy"
    )
with open("app/src/main/java/com/example/ui/screens/AiSupportCallScreen.kt", "w") as f:
    f.write(content)

# 2. Fix AiSupportViewModel.kt
with open("app/src/main/java/com/example/ui/screens/AiSupportViewModel.kt", "r") as f:
    content = f.read()

# Replace BuildConfig.APPS_SCRIPT_URL
content = content.replace("BuildConfig.APPS_SCRIPT_URL.ifBlank { ", "")
content = content.replace(" }", "")
content = content.replace("val scriptUrl = \"https://script.google.com/macros/s/AKfycbz_placeholder/exec\"", "val scriptUrl = \"https://script.google.com/macros/s/AKfycbz_placeholder/exec\"")

with open("app/src/main/java/com/example/ui/screens/AiSupportViewModel.kt", "w") as f:
    f.write(content)

