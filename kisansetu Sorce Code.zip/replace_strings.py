import os
import re

replacements = {
    '"Home"': 'stringResource(R.string.home)',
    '"Markets"': 'stringResource(R.string.markets)',
    '"Transport"': 'stringResource(R.string.transport)',
    '"Map"': 'stringResource(R.string.map)',
    '"Alerts"': 'stringResource(R.string.alerts)',
    '"Profile"': 'stringResource(R.string.profile)',
    '"Login"': 'stringResource(R.string.login)',
    '"Sign Up"': 'stringResource(R.string.signup)',
    '"Logout"': 'stringResource(R.string.logout)',
    '"Kisan Sahayak"': 'stringResource(R.string.kisan_sahayak)',
    '"Role Selection"': 'stringResource(R.string.role_selection)',
    '"Compare Markets"': 'stringResource(R.string.compare_markets)',
    '"Market Details"': 'stringResource(R.string.market_details)',
    '"Price Trends"': 'stringResource(R.string.price_trends)',
    '"Mandi Dashboard"': 'stringResource(R.string.mandi_dashboard)',
    '"Quantity"': 'stringResource(R.string.quantity)',
    '"Location"': 'stringResource(R.string.location)',
    '"Cancel"': 'stringResource(R.string.cancel)',
    '"Close"': 'stringResource(R.string.close)',
    '"Accept"': 'stringResource(R.string.accept)',
    '"Email"': 'stringResource(R.string.email)',
    '"Password"': 'stringResource(R.string.password)',
    '"Forgot Password?"': 'stringResource(R.string.forgot_password)',
    '"Full Name"': 'stringResource(R.string.full_name)',
    '"Address"': 'stringResource(R.string.address)',
    '"Contact Number *"': 'stringResource(R.string.contact_number)',
    '"City / District *"': 'stringResource(R.string.city_district)',
    '"Mandi ID / Shop ID *"': 'stringResource(R.string.mandi_id)',
    '"Crop Name"': 'stringResource(R.string.crop_name)',
    '"Grant Permission"': 'stringResource(R.string.grant_permission)',
    '"Next"': 'stringResource(R.string.next)',
    '"Welcome"': 'stringResource(R.string.welcome)',
    '"Farmer"': 'stringResource(R.string.farmer)',
    '"Mandi Agent"': 'stringResource(R.string.mandi_agent)',
    '"Sell Request"': 'stringResource(R.string.sell_request)',
    '"Search"': 'stringResource(R.string.search)',
    '"Type your message..."': 'stringResource(R.string.type_your_message)',
    '"KisanSetu"': 'stringResource(R.string.app_name)',
}

for root, _, files in os.walk('app/src/main/java'):
    for file in files:
        if file.endswith('.kt') and file != 'LanguageSelectionScreen.kt':
            path = os.path.join(root, file)
            with open(path, 'r') as f:
                content = f.read()
            
            original_content = content
            for k, v in replacements.items():
                content = content.replace(f'Text({k})', f'Text({v})')
                content = content.replace(f'Text({k},', f'Text({v},')
                content = content.replace(f'Text(text = {k}', f'Text(text = {v}')
                content = content.replace(f'label = {{ Text({k}) }}', f'label = {{ Text({v}) }}')
                content = content.replace(f'title = {{ Text({k}) }}', f'title = {{ Text({v}) }}')
                content = content.replace(f'contentDescription = {k}', f'contentDescription = {v}')
                content = content.replace(f'placeholder = {{ Text({k}) }}', f'placeholder = {{ Text({v}) }}')

            if content != original_content:
                if 'import androidx.compose.ui.res.stringResource' not in content:
                    content = content.replace('import androidx.compose.runtime.Composable', 'import androidx.compose.ui.res.stringResource\nimport androidx.compose.runtime.Composable')
                if 'import com.example.R' not in content:
                    content = content.replace('package com.example.ui.screens\n', 'package com.example.ui.screens\n\nimport com.example.R\n')
                    content = content.replace('package com.example.ui\n', 'package com.example.ui\n\nimport com.example.R\n')
                with open(path, 'w') as f:
                    f.write(content)
                print(f"Updated {file}")

print("Done string replacement.")
