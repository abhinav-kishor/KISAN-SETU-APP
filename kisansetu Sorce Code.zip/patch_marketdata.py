import re

with open("app/src/main/java/com/example/ui/MarketData.kt", "r") as f:
    content = f.read()

pattern = r'''fun calculateMarketReturns\(
    markets: List<Market>, 
    quantityQuintals: Int, 
    transportCostPerKm: Int = 50,
    actualRouteDistancesKm: Map<String, Double> = emptyMap\(\),
    actualRouteDurations: Map<String, String> = emptyMap\(\)
\): List<MarketCalculation> \{
    val calculations = markets\.map \{ market ->
        val grossValue = quantityQuintals \* market\.pricePerQuintal'''

replacement = """fun calculateMarketReturns(
    markets: List<Market>, 
    quantityQuintals: Int, 
    transportCostPerKm: Int = 50,
    actualRouteDistancesKm: Map<String, Double> = emptyMap(),
    actualRouteDurations: Map<String, String> = emptyMap(),
    cropName: String? = null
): List<MarketCalculation> {
    val calculations = markets.map { market ->
        val price = if (!cropName.isNullOrBlank()) {
            market.crops.find { it.cropName.equals(cropName.trim(), ignoreCase = true) }?.pricePerQuintal ?: market.pricePerQuintal
        } else {
            market.pricePerQuintal
        }
        val grossValue = quantityQuintals * price"""

content = re.sub(pattern, replacement, content)

with open("app/src/main/java/com/example/ui/MarketData.kt", "w") as f:
    f.write(content)
