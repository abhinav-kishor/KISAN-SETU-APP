import os
import re

strings = {
    "welcome_title": {"en": "Welcome to KisanSetu", "hi": "किसानसेतु में आपका स्वागत है", "mr": "किसानसेतूमध्ये आपले स्वागत आहे", "bn": "কিষাণসেতুতে আপনাকে স্বাগতম", "te": "కిసాన్‌సేతుకు స్వాగతం"},
    "know_your_market": {"en": "Know Your Market", "hi": "अपना बाजार जानें", "mr": "तुमची बाजारपेठ जाणून घ्या", "bn": "আপনার বাজার জানুন", "te": "మీ మార్కెట్‌ను తెలుసుకోండి"},
    "know_your_market_desc": {"en": "Get up-to-date market prices for your crops across different mandis.", "hi": "विभिन्न मंडियों में अपनी फसलों के नवीनतम बाजार मूल्य प्राप्त करें।", "mr": "विविध मंडईंमध्ये तुमच्या पिकांचे अद्ययावत बाजारभाव मिळवा.", "bn": "বিভিন্ন মাণ্ডিতে আপনার ফসলের সর্বশেষ বাজার মূল্য পান।", "te": "వివిధ మండిల్లో మీ పంటల తాజా మార్కెట్ ధరలను పొందండి."},
    "make_smarter_decisions": {"en": "Make Smarter Decisions", "hi": "समझदारी से निर्णय लें", "mr": "हुशार निर्णय घ्या", "bn": "স্মার্ট সিদ্ধান্ত নিন", "te": "తెలివైన నిర్ణయాలు తీసుకోండి"},
    "make_smarter_decisions_desc": {"en": "Compare prices, transport costs, and estimated returns easily.", "hi": "कीमतों, परिवहन लागतों और अनुमानित रिटर्न की आसानी से तुलना करें।", "mr": "किमती, वाहतूक खर्च आणि अंदाजे परताव्याची सहज तुलना करा.", "bn": "সহজে দাম, পরিবহন খরচ এবং আনুমানিক আয়ের তুলনা করুন।", "te": "ధరలు, రవాణా ఖర్చులు మరియు అంచనా రాబడిని సులభంగా సరిపోల్చండి."},
    "stay_updated": {"en": "Stay Updated", "hi": "अपडेट रहें", "mr": "अद्ययावित रहा", "bn": "আপডেট থাকুন", "te": "తాజాగా ఉండండి"},
    "stay_updated_desc": {"en": "Receive timely alerts on market trends and price changes.", "hi": "बाजार के रुझानों और कीमतों में बदलाव पर समय पर अलर्ट प्राप्त करें।", "mr": "बाजारातील कल आणि किमतीतील बदलांबद्दल वेळेवर सूचना मिळवा.", "bn": "বাজারের প্রবণতা এবং দামের পরিবর্তনের সময়মতো সতর্কতা পান।", "te": "మార్కెట్ పోకడలు మరియు ధరల మార్పులపై సకాలంలో హెచ్చరికలను పొందండి."},
    "get_started": {"en": "Get Started", "hi": "शुरू करें", "mr": "सुरुवात करा", "bn": "শুরু করুন", "te": "ప్రారంభించండి"},
    "where_should_sell": {"en": "Where should you sell today?", "hi": "आज आपको कहाँ बेचना चाहिए?", "mr": "आज तुम्ही कुठे विकायला हवे?", "bn": "আজ আপনার কোথায় বিক্রি করা উচিত?", "te": "ఈరోజు మీరు ఎక్కడ విక్రయించాలి?"},
    "crop_eg_wheat": {"en": "Crop (e.g., Wheat)", "hi": "फसल (जैसे, गेहूं)", "mr": "पीक (उदा., गहू)", "bn": "ফসল (উদাঃ গম)", "te": "పంట (ఉదా. గోధుమ)"},
    "quantity_quintals": {"en": "Quantity (Quintals)", "hi": "मात्रा (क्विंटल)", "mr": "प्रमाण (क्विंटल)", "bn": "পরিমাণ (কুইন্টাল)", "te": "పరిమాణం (క్వింటాల్)"},
    "view_details": {"en": "View Details", "hi": "विवरण देखें", "mr": "तपशील पहा", "bn": "বিবরণ দেখুন", "te": "వివరాలను వీక్షించండి"},
    "find_best_market": {"en": "Find Best Market", "hi": "सर्वश्रेष्ठ मंडी खोजें", "mr": "सर्वोत्तम बाजार शोधा", "bn": "সেরা বাজার খুঁজুন", "te": "ఉత్తమ మార్కెట్‌ను కనుగొనండి"},
    "recommendation": {"en": "Recommendation", "hi": "सिफारिश", "mr": "शिफारस", "bn": "সুপারিশ", "te": "సిఫార్సు"},
    "distance": {"en": "Distance", "hi": "दूरी", "mr": "अंतर", "bn": "দূরত্ব", "te": "దూరం"},
    "estimated_return": {"en": "Estimated Return", "hi": "अनुमानित रिटर्न", "mr": "अंदाजित परतावा", "bn": "আনুমানিক আয়", "te": "అంచనా రాబడి"},
    "recommended_badge": {"en": "RECOMMENDED", "hi": "अनुशंसित", "mr": "शिफारस केलेले", "bn": "সুপারিশকৃত", "te": "సిఫార్సు చేయబడినది"},
    "ai_assistant_soon": {"en": "AI Assistant Coming Soon", "hi": "एआई सहायक जल्द आ रहा है", "mr": "एआय असिस्टंट लवकरच येत आहे", "bn": "এআই অ্যাসিস্ট্যান্ট শীঘ্রই আসছে", "te": "AI అసిస్టెంట్ త్వరలో రాబోతోంది"},
    "apna_sawaal": {"en": "Type or speak your question...", "hi": "अपना सवाल लिखें या बोलें...", "mr": "तुमचा प्रश्न लिहा किंवा बोला...", "bn": "আপনার প্রশ্ন টাইপ করুন বা বলুন...", "te": "మీ ప్రశ్నను టైప్ చేయండి లేదా మాట్లాడండి..."},
    "app_logo": {"en": "App Logo", "hi": "ऐप लोगो", "mr": "अॅप लोगो", "bn": "অ্যাপ লোগো", "te": "యాప్ లోగో"},
    "back": {"en": "Back", "hi": "पीछे", "mr": "मागे", "bn": "পিছনে", "te": "వెనుకకు"},
    "back_to_home": {"en": "Back to Home", "hi": "होम पर वापस जाएं", "mr": "होमवर परत जा", "bn": "হোমে ফিরে যান", "te": "హోమ్‌కి తిరిగి వెళ్లండి"},
    "calculating_route": {"en": "Calculating best driving route...", "hi": "सर्वश्रेष्ठ ड्राइविंग मार्ग की गणना की जा रही है...", "mr": "सर्वोत्तम ड्रायव्हिंग मार्गाची गणना करत आहे...", "bn": "সেরা ড্রাইভিং রুট গণনা করা হচ্ছে...", "te": "ఉత్తమ డ్రైవింగ్ మార్గాన్ని గణిస్తోంది..."},
    "connecting_farmers": {"en": "Connecting Farmers to Better Markets", "hi": "किसानों को बेहतर बाजारों से जोड़ना", "mr": "शेतकऱ्यांना चांगल्या बाजारांशी जोडणे", "bn": "কৃষকদের ভালো বাজারের সাথে সংযুক্ত করা", "te": "రైతులను మెరుగైన మార్కెట్లతో అనుసంధానించడం"},
    "create_account": {"en": "Create Account", "hi": "खाता बनाएं", "mr": "खाते तयार करा", "bn": "অ্যাকাউন্ট তৈরি করুন", "te": "ఖాతాను సృష్టించండి"},
    "crop_not_found": {"en": "Crop or Market not found", "hi": "फसल या मंडी नहीं मिली", "mr": "पीक किंवा बाजार सापडला नाही", "bn": "ফসল বা বাজার পাওয়া যায়নি", "te": "పంట లేదా మార్కెట్ కనుగొనబడలేదు"},
    "demand_high_normal_low": {"en": "Demand (High/Normal/Low)", "hi": "मांग (उच्च/सामान्य/निम्न)", "mr": "मागणी (जास्त/सामान्य/कमी)", "bn": "চাহিদা (উচ্চ/স্বাভাবিক/নিম্ন)", "te": "డిమాండ్ (అధిక/సాధారణ/తక్కువ)"},
    "destination_mandi": {"en": "Destination Mandi", "hi": "गंतव्य मंडी", "mr": "गंतव्य मंडी", "bn": "গন্তব্য মাণ্ডি", "te": "గమ్యస్థాన మండి"},
    "edit": {"en": "Edit", "hi": "संपादित करें", "mr": "संपादित करा", "bn": "সম্পাদনা করুন", "te": "సవరించండి"},
    "find_nearby_mandis": {"en": "Find nearby mandis & plan your route", "hi": "आसपास की मंडियां खोजें और अपना मार्ग बनाएं", "mr": "जवळपासच्या मंडई शोधा आणि तुमच्या मार्गाची योजना करा", "bn": "কাছাকাছি মাণ্ডি খুঁজুন এবং আপনার রুট পরিকল্পনা করুন", "te": "సమీప మండిలను కనుగొనండి & మీ మార్గాన్ని ప్లాన్ చేయండి"},
    "im_farmer": {"en": "I'm a Farmer", "hi": "मैं एक किसान हूँ", "mr": "मी एक शेतकरी आहे", "bn": "আমি একজন কৃষক", "te": "నేను రైతును"},
    "im_mandi": {"en": "I'm a Mandi / Market", "hi": "मैं एक मंडी / बाजार हूँ", "mr": "मी एक मंडी / बाजार आहे", "bn": "আমি একজন মাণ্ডি / বাজার", "te": "నేను మండి / మార్కెట్‌ను"},
    "kisan_thinking": {"en": "Kisan Sahayak is thinking...", "hi": "किसान सहायक सोच रहा है...", "mr": "किसान सहाय्यक विचार करत आहे...", "bn": "কিষাণ সহায়ক ভাবছেন...", "te": "కిసాన్ సహాయక్ ఆలోచిస్తున్నారు..."},
    "kisansetu_map": {"en": "KisanSetu Map", "hi": "किसानसेतु नक्शा", "mr": "किसानसेतू नकाशा", "bn": "কিষাণসেতু মানচিত্র", "te": "కిసాన్‌సేతు మ్యాప్"},
    "mandi_shop_name": {"en": "Mandi / Shop Name *", "hi": "मंडी / दुकान का नाम *", "mr": "मंडी / दुकानाचे नाव *", "bn": "মাণ্ডি / দোকানের নাম *", "te": "మండి / షాప్ పేరు *"},
    "mandi_notifications": {"en": "Mandi Notifications", "hi": "मंडी सूचनाएं", "mr": "मंडी सूचना", "bn": "মাণ্ডি বিজ্ঞপ্তি", "te": "మండి నోటిఫికేషన్‌లు"},
    "mandi_registration": {"en": "Mandi Registration", "hi": "मंडी पंजीकरण", "mr": "मंडी नोंदणी", "bn": "মাণ্ডি নিবন্ধন", "te": "మండి రిజిస్ట్రేషన్"},
    "mic_permission_required": {"en": "Microphone permission is required for voice input.", "hi": "वॉइस इनपुट के लिए माइक्रोफोन की अनुमति आवश्यक है।", "mr": "व्हॉइस इनपुटसाठी मायक्रोफोनची परवानगी आवश्यक आहे.", "bn": "ভয়েস ইনপুটের জন্য মাইক্রোফোনের অনুমতি প্রয়োজন।", "te": "వాయిస్ ఇన్‌పుట్ కోసం మైక్రోఫోన్ అనుమతి అవసరం."},
    "navigate": {"en": "Navigate", "hi": "नेविगेट करें", "mr": "नॅव्हिगेट करा", "bn": "নেভিগেট করুন", "te": "నావిగేట్ చేయండి"},
    "no_new_alerts": {"en": "No new alerts. We'll notify you when something important changes.", "hi": "कोई नया अलर्ट नहीं। कुछ महत्वपूर्ण बदलने पर हम आपको सूचित करेंगे।", "mr": "कोणत्याही नवीन सूचना नाहीत. काही महत्त्वाचे बदलल्यावर आम्ही तुम्हाला सूचित करू.", "bn": "কোনো নতুন সতর্কতা নেই। গুরুত্বপূর্ণ কিছু পরিবর্তন হলে আমরা আপনাকে জানাব।", "te": "కొత్త హెచ్చరికలు లేవు. ముఖ్యమైనవి మారినప్పుడు మేము మీకు తెలియజేస్తాము."},
    "no_notifications": {"en": "No notifications.", "hi": "कोई सूचना नहीं।", "mr": "कोणत्याही सूचना नाहीत.", "bn": "কোনো বিজ্ঞপ্তি নেই।", "te": "నోటిఫికేషన్‌లు లేవు."},
    "notifications": {"en": "Notifications", "hi": "सूचनाएं", "mr": "सूचना", "bn": "বিজ্ঞপ্তি", "te": "నోటిఫికేషన్‌లు"},
    "owner_name": {"en": "Owner / Manager Name *", "hi": "मालिक / प्रबंधक का नाम *", "mr": "मालक / व्यवस्थापकाचे नाव *", "bn": "মালিক / ম্যানেজারের নাম *", "te": "యజమాని / మేనేజర్ పేరు *"},
    "pickup_location": {"en": "Pickup Location", "hi": "पिकअप स्थान", "mr": "पिकअप स्थान", "bn": "পিকআপ অবস্থান", "te": "పికప్ స్థానం"},
    "please_fill_required": {"en": "Please fill required fields", "hi": "कृपया आवश्यक फ़ील्ड भरें", "mr": "कृपया आवश्यक फील्ड भरा", "bn": "অনুগ্রহ করে প্রয়োজনীয় ক্ষেত্রগুলি পূরণ করুন", "te": "దయచేసి అవసరమైన ఫీల్డ్‌లను పూరించండి"},
    "price_trends_soon": {"en": "Price Trends Coming Soon", "hi": "कीमत के रुझान जल्द आ रहे हैं", "mr": "किमतीचा कल लवकरच येत आहे", "bn": "দামের প্রবণতা শীঘ্রই আসছে", "te": "ధర ధోరణులు త్వరలో రాబోతున్నాయి"},
    "price_per_quintal": {"en": "Price per Quintal (₹)", "hi": "प्रति क्विंटल कीमत (₹)", "mr": "प्रति क्विंटल किंमत (₹)", "bn": "প্রতি কুইন্টাল দাম (₹)", "te": "క్వింటాల్‌కు ధర (₹)"},
    "profile_picture": {"en": "Profile Picture", "hi": "प्रोफ़ाइल चित्र", "mr": "प्रोफाइल चित्र", "bn": "প্রোফাইল ছবি", "te": "ప్రొఫైల్ చిత్రం"},
    "recommended_mandi": {"en": "Recommended Mandi", "hi": "अनुशंसित मंडी", "mr": "शिफारस केलेली मंडी", "bn": "প্রস্তাবিত মাণ্ডি", "te": "సిఫార్సు చేయబడిన మండి"},
    "register_mandi": {"en": "Register Mandi", "hi": "मंडी पंजीकृत करें", "mr": "मंडीची नोंदणी करा", "bn": "মাণ্ডি নিবন্ধন করুন", "te": "మండిని నమోదు చేయండి"},
    "request_transport": {"en": "Request Transport", "hi": "परिवहन का अनुरोध करें", "mr": "वाहतुकीची विनंती करा", "bn": "পরিবহনের অনুরোধ করুন", "te": "రవాణాను అభ్యర్థించండి"},
    "retry": {"en": "Retry", "hi": "पुनः प्रयास करें", "mr": "पुन्हा प्रयत्न करा", "bn": "পুনরায় চেষ্টা করুন", "te": "మళ్లీ ప్రయత్నించండి"},
    "retry_permission": {"en": "Retry Permission", "hi": "अनुमति का पुनः प्रयास करें", "mr": "परवानगीचा पुन्हा प्रयत्न करा", "bn": "অনুমতির জন্য পুনরায় চেষ্টা করুন", "te": "అనుమతిని మళ్లీ ప్రయత్నించండి"},
    "search_mandi": {"en": "Search mandi or location", "hi": "मंडी या स्थान खोजें", "mr": "मंडी किंवा स्थान शोधा", "bn": "মাণ্ডি বা অবস্থান খুঁজুন", "te": "మండి లేదా స్థానాన్ని శోధించండి"},
    "select": {"en": "Select", "hi": "चुनें", "mr": "निवडा", "bn": "নির্বাচন করুন", "te": "ఎంచుకోండి"},
    "selected": {"en": "Selected", "hi": "चयनित", "mr": "निवडलेले", "bn": "নির্বাচিত", "te": "ఎంచుకోబడింది"},
    "selected_mandi": {"en": "Selected Mandi", "hi": "चयनित मंडी", "mr": "निवडलेली मंडी", "bn": "নির্বাচিত মাণ্ডি", "te": "ఎంచుకున్న మండి"},
    "send": {"en": "Send", "hi": "भेजें", "mr": "पाठवा", "bn": "পাঠান", "te": "పంపండి"},
    "send_sell_request": {"en": "Send Sell Request", "hi": "बिक्री अनुरोध भेजें", "mr": "विक्री विनंती पाठवा", "bn": "বিক্রয়ের অনুরোধ পাঠান", "te": "విక్రయ అభ్యర్థనను పంపండి"},
    "sahayak_unavailable": {"en": "Sorry, Kisan Sahayak is temporarily unavailable. Please try again.", "hi": "क्षमा करें, किसान सहायक अस्थायी रूप से अनुपलब्ध है। कृपया पुनः प्रयास करें।", "mr": "क्षमस्व, किसान सहाय्यक तात्पुरते अनुपलब्ध आहे. कृपया पुन्हा प्रयत्न करा.", "bn": "দুঃখিত, কিষাণ সহায়ক সাময়িকভাবে অনুপলব্ধ। আবার চেষ্টা করুন।", "te": "క్షమించండి, కిసాన్ సహాయక్ తాత్కాలికంగా అందుబాటులో లేదు. దయచేసి మళ్లీ ప్రయత్నించండి."},
    "speak": {"en": "Speak", "hi": "बोलें", "mr": "बोला", "bn": "বলুন", "te": "మాట్లాడండి"},
    "stop_listening": {"en": "Stop Listening", "hi": "सुनना बंद करें", "mr": "ऐकणे थांबवा", "bn": "শোনা বন্ধ করুন", "te": "వినడం ఆపండి"},
    "transport_options": {"en": "Transport Options", "hi": "परिवहन विकल्प", "mr": "वाहतूक पर्याय", "bn": "পরিবহন বিকল্প", "te": "రవాణా ఎంపికలు"},
    "transport_summary": {"en": "Transport Summary", "hi": "परिवहन सारांश", "mr": "वाहतूक सारांश", "bn": "পরিবহন সারাংশ", "te": "రవాణా సారాంశం"},
    "who_are_you": {"en": "Who are you?", "hi": "आप कौन हैं?", "mr": "तुम्ही कोण आहात?", "bn": "আপনি কে?", "te": "మీరు ఎవరు?"},
    "add_crop": {"en": "Add Crop", "hi": "फसल जोड़ें", "mr": "पीक जोडा", "bn": "ফসল যোগ করুন", "te": "పంటను జోడించండి"}
}

import xml.etree.ElementTree as ET

langs = ["en", "hi", "mr", "bn", "te"]
dirs = {"en": "values", "hi": "values-hi", "mr": "values-mr", "bn": "values-bn", "te": "values-te"}
res_dir = "app/src/main/res"

for lang in langs:
    xml_path = os.path.join(res_dir, dirs[lang], "strings.xml")
    try:
        tree = ET.parse(xml_path)
        root = tree.getroot()
    except Exception:
        root = ET.Element("resources")
        tree = ET.ElementTree(root)

    existing_keys = {child.attrib['name'] for child in root if 'name' in child.attrib}

    for key, trans in strings.items():
        if key not in existing_keys:
            val = trans.get(lang, trans["en"])
            elem = ET.Element("string", name=key)
            elem.text = val
            root.append(elem)

    # Convert back to string and pretty print manually because ET formatting is tricky
    xml_str = '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n'
    for child in root:
        if 'name' in child.attrib:
            text = child.text if child.text else ""
            text = text.replace("'", "\\'").replace("&", "&amp;")
            xml_str += f'    <string name="{child.attrib["name"]}">{text}</string>\n'
    xml_str += '</resources>'
    
    with open(xml_path, 'w', encoding='utf-8') as f:
        f.write(xml_str)

print("Updated strings.xml")
