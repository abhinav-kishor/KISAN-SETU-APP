import re

with open("app/src/main/java/com/example/ui/screens/MapViewModel.kt", "r") as f:
    content = f.read()

# Add a way to set custom location
if "fun setUserLocation(latLng: LatLng)" not in content:
    content = content.replace(
        "fun loadLocationAndRoutes(context: Context, markets: List<Market>) {",
        "fun setUserLocation(latLng: LatLng) {\n        _userLocation.value = latLng\n    }\n\n    fun loadLocationAndRoutes(context: Context, markets: List<Market>) {"
    )
    
    # Modify loadLocationAndRoutes to use existing if set
    content = content.replace(
        """val location = getCurrentLocation(context)
            if (location != null) {
                val originLatLng = LatLng(location.latitude, location.longitude)
                _userLocation.value = originLatLng""",
        """if (_userLocation.value != null) {
                fetchRoutesForMarkets(_userLocation.value!!, markets)
            } else {
                val location = getCurrentLocation(context)
                if (location != null) {
                    val originLatLng = LatLng(location.latitude, location.longitude)
                    _userLocation.value = originLatLng
                    fetchRoutesForMarkets(originLatLng, markets)
                } else {
                    _locationError.value = "Location access is required to calculate the actual driving route and transport cost."
                    _isLoading.value = false
                }
            }
            // dummy to balance brackets if needed: if (false) {"""
    )
    # We need to properly replace the if (location != null) block. Let's do it cleaner.

with open("app/src/main/java/com/example/ui/screens/MapViewModel.kt", "w") as f:
    f.write(content)
