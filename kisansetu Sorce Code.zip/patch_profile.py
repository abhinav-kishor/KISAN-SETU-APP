import re

with open("app/src/main/java/com/example/ui/screens/ProfileScreen.kt", "r") as f:
    content = f.read()

# Replace onClick = { /* Placeholder for next prompt */ } for Contact / AI Support
# We know the title is stringResource(R.string.contact_ai)
pattern = r"(title = stringResource\(R\.string\.contact_ai\),\s*subtitle = \"Chat with AI Assistant\",\s*icon = Icons\.Default\.SmartToy,\s*onClick = \{) /\* Placeholder for next prompt \*/ (\})"
replacement = r"\1 navController.navigate(\"ai_support_call\") \2"

new_content = re.sub(pattern, replacement, content)

with open("app/src/main/java/com/example/ui/screens/ProfileScreen.kt", "w") as f:
    f.write(new_content)
