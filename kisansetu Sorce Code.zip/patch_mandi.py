import re

# Fix ViewModel
with open('app/src/main/java/com/example/ui/screens/MandiBhavViewModel.kt', 'r') as f:
    content = f.read()

content = content.replace(
    'MandiSortOption.MODAL_HIGH_LOW -> records.sortedByDescending { it.modalPrice.toDoubleOrNull() ?: 0.0 }',
    'MandiSortOption.MODAL_HIGH_LOW -> records.sortedByDescending { it.modalPrice?.toDoubleOrNull() ?: 0.0 }'
)
content = content.replace(
    'MandiSortOption.MODAL_LOW_HIGH -> records.sortedBy { it.modalPrice.toDoubleOrNull() ?: 0.0 }',
    'MandiSortOption.MODAL_LOW_HIGH -> records.sortedBy { it.modalPrice?.toDoubleOrNull() ?: 0.0 }'
)
content = content.replace(
    'MandiSortOption.MARKET_NAME -> records.sortedBy { it.market }',
    'MandiSortOption.MARKET_NAME -> records.sortedBy { it.market ?: "" }'
)
with open('app/src/main/java/com/example/ui/screens/MandiBhavViewModel.kt', 'w') as f:
    f.write(content)

# Fix Screen
with open('app/src/main/java/com/example/ui/screens/MandiBhavScreen.kt', 'r') as f:
    content = f.read()

content = content.replace('Text("🇮🇳 ${record.market}",', 'Text("🇮🇳 ${record.market ?: "Unknown"}",')
content = content.replace('Text("${record.district}, ${record.state}",', 'Text("${record.district ?: ""}, ${record.state ?: ""}",')
content = content.replace('Text(record.commodity, modifier =', 'Text(record.commodity ?: "", modifier =')
content = content.replace('Text("₹${record.minPrice}",', 'Text("₹${record.minPrice ?: "N/A"}",')
content = content.replace('Text("₹${record.modalPrice}",', 'Text("₹${record.modalPrice ?: "N/A"}",')
content = content.replace('Text("₹${record.maxPrice}",', 'Text("₹${record.maxPrice ?: "N/A"}",')
content = content.replace('Text("${stringResource(R.string.updated_on)} ${record.arrivalDate}",', 'Text("${stringResource(R.string.updated_on)} ${record.arrivalDate ?: "N/A"}",')

with open('app/src/main/java/com/example/ui/screens/MandiBhavScreen.kt', 'w') as f:
    f.write(content)

