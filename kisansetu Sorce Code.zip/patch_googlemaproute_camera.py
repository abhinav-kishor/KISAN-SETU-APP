import re

with open("app/src/main/java/com/example/ui/screens/GoogleMapRoute.kt", "r") as f:
    content = f.read()

# Add mapLoaded state
if "var mapLoaded by remember" not in content:
    content = content.replace(
        'val cameraPositionState = rememberCameraPositionState {',
        'var mapLoaded by remember { androidx.compose.runtime.mutableStateOf(false) }\n    val cameraPositionState = rememberCameraPositionState {'
    )

    # Update LaunchedEffect
    old_launched_effect = """    LaunchedEffect(origin, destination, encodedPolyline) {
        val boundsBuilder = LatLngBounds.builder()
        boundsBuilder.include(destination)
        if (origin != null) {
            boundsBuilder.include(origin)
        }
        val bounds = boundsBuilder.build()
        try {
            cameraPositionState.animate(CameraUpdateFactory.newLatLngBounds(bounds, 100))
        } catch (e: Exception) {
            // Ignored, happens if layout is not ready
        }
    }"""
    
    new_launched_effect = """    LaunchedEffect(mapLoaded, origin, destination, encodedPolyline) {
        if (mapLoaded) {
            val boundsBuilder = LatLngBounds.builder()
            boundsBuilder.include(destination)
            if (origin != null) {
                boundsBuilder.include(origin)
            }
            val bounds = boundsBuilder.build()
            try {
                // Using 64px padding to prevent map layout breaking
                cameraPositionState.animate(CameraUpdateFactory.newLatLngBounds(bounds, 64))
            } catch (e: Exception) {
                // Ignored, happens if layout is not ready
            }
        }
    }"""
    
    content = content.replace(old_launched_effect, new_launched_effect)

    # Add onMapLoaded to GoogleMap
    content = content.replace(
        """    GoogleMap(
        modifier = modifier,
        cameraPositionState = cameraPositionState,
        onMapClick = {
            openGoogleMapsDirections(context, origin, destination)
        }
    ) {""",
        """    GoogleMap(
        modifier = modifier,
        cameraPositionState = cameraPositionState,
        onMapLoaded = { mapLoaded = true },
        onMapClick = {
            openGoogleMapsDirections(context, origin, destination)
        }
    ) {"""
    )

with open("app/src/main/java/com/example/ui/screens/GoogleMapRoute.kt", "w") as f:
    f.write(content)
