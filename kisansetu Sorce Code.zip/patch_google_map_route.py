import re

with open("app/src/main/java/com/example/ui/screens/GoogleMapRoute.kt", "r") as f:
    content = f.read()

# Add onMapClick modifier to GoogleMap
pattern = r"(GoogleMap\(\s*modifier = modifier,\s*cameraPositionState = cameraPositionState\s*\) \{)"
replacement = r"""    val context = LocalContext.current
    GoogleMap(
        modifier = modifier,
        cameraPositionState = cameraPositionState,
        onMapClick = {
            openGoogleMapsDirections(context, origin, destination)
        }
    ) {"""

content = re.sub(pattern, replacement, content)

with open("app/src/main/java/com/example/ui/screens/GoogleMapRoute.kt", "w") as f:
    f.write(content)
