import re

with open("app/src/main/java/com/example/ui/screens/MapScreen.kt", "r") as f:
    content = f.read()

# Add polyline import if not present
if "import com.google.maps.android.compose.Polyline" not in content:
    content = content.replace(
        "import com.google.maps.android.compose.MarkerState",
        "import com.google.maps.android.compose.MarkerState\nimport com.google.maps.android.compose.Polyline\nimport com.google.maps.android.PolyUtil\nimport androidx.compose.ui.graphics.Color"
    )

# Find the GoogleMap block in MapScreen.kt and inject polyline rendering
google_map_pattern = r"(GoogleMap\(\s*modifier = Modifier.fillMaxSize\(\),\s*cameraPositionState = cameraPositionState\s*\)\s*\{[\s\S]*?)(            if \(!hasLocationPermission && locationError != null\) \{)"

def replace_map_block(match):
    original_block = match.group(1)
    # Inject Polyline logic right before the end of the GoogleMap block
    polyline_code = """
                // Draw polyline if a market is selected
                if (selectedMarket != null) {
                    val polyline = mapViewModel.routePolylines.collectAsState().value[selectedMarket!!.id]
                    if (polyline != null && polyline.isNotEmpty()) {
                        val decodedPath = remember(polyline) { PolyUtil.decode(polyline) }
                        Polyline(
                            points = decodedPath,
                            color = Color.Blue,
                            width = 12f
                        )
                    }
                } else if (recommendedMarketCalc != null) {
                    val polyline = mapViewModel.routePolylines.collectAsState().value[recommendedMarketCalc.market.id]
                    if (polyline != null && polyline.isNotEmpty()) {
                        val decodedPath = remember(polyline) { PolyUtil.decode(polyline) }
                        Polyline(
                            points = decodedPath,
                            color = Color.Blue,
                            width = 12f
                        )
                    }
                }
            }
"""
    # Find the closing brace of the GoogleMap block and insert before it
    # We'll just replace the last '}' in original_block
    new_block = original_block.rsplit('}', 1)[0] + polyline_code
    return new_block + match.group(2)

content = re.sub(google_map_pattern, replace_map_block, content)

with open("app/src/main/java/com/example/ui/screens/MapScreen.kt", "w") as f:
    f.write(content)
