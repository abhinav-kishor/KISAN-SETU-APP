import os
import xml.etree.ElementTree as ET

strings = {
    "your_location": {"en": "Your Location", "hi": "आपका स्थान", "mr": "तुमचे स्थान", "bn": "আপনার অবস্থান", "te": "మీ స్థానం"}
}

langs = ["en", "hi", "mr", "bn", "te"]
dirs = {"en": "values", "hi": "values-hi", "mr": "values-mr", "bn": "values-bn", "te": "values-te"}
res_dir = "app/src/main/res"

for lang in langs:
    xml_path = os.path.join(res_dir, dirs[lang], "strings.xml")
    try:
        tree = ET.parse(xml_path)
        root = tree.getroot()
    except Exception:
        root = ET.Element("resources")
        tree = ET.ElementTree(root)

    existing_keys = {child.attrib['name'] for child in root if 'name' in child.attrib}

    for key, trans in strings.items():
        if key not in existing_keys:
            val = trans.get(lang, trans["en"])
            elem = ET.Element("string", name=key)
            elem.text = val
            root.append(elem)

    xml_str = '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n'
    for child in root:
        if 'name' in child.attrib:
            text = child.text if child.text else ""
            text = text.replace("'", "\\'").replace("&", "&amp;")
            xml_str += f'    <string name="{child.attrib["name"]}">{text}</string>\n'
    xml_str += '</resources>'
    
    with open(xml_path, 'w', encoding='utf-8') as f:
        f.write(xml_str)

