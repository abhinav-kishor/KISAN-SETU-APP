import os
import xml.etree.ElementTree as ET

strings = {
    "capacity_quintals": {"en": "Capacity: %1$d quintals", "hi": "क्षमता: %1$d क्विंटल", "mr": "क्षमता: %1$d क्विंटल", "bn": "ক্ষমতা: %1$d কুইন্টাল", "te": "సామర్థ్యం: %1$d క్వింటాళ్లు"},
    "vehicle_capacity_quintals": {"en": "Vehicle Capacity: %1$d quintals", "hi": "वाहन क्षमता: %1$d क्विंटल", "mr": "वाहन क्षमता: %1$d क्विंटल", "bn": "গাড়ির ক্ষমতা: %1$d কুইন্টাল", "te": "వాహనం సామర్థ్యం: %1$d క్వింటాళ్లు"},
    "quantity_val_quintals": {"en": "Quantity: %1$s quintals", "hi": "मात्रा: %1$s क्विंटल", "mr": "प्रमाण: %1$s क्विंटल", "bn": "পরিমাণ: %1$s কুইন্টাল", "te": "పరిమాణం: %1$s క్వింటాళ్లు"},
    "quantity_val_quintals_cap": {"en": "Quantity: %1$s Quintals", "hi": "मात्रा: %1$s क्विंटल", "mr": "प्रमाण: %1$s क्विंटल", "bn": "পরিমাণ: %1$s কুইন্টাল", "te": "పరిమాణం: %1$s క్వింటాళ్లు"},
    "sell_crop_at_market": {"en": "Sell %1$s at %2$s", "hi": "%2$s में %1$s बेचें", "mr": "%2$s मध्ये %1$s विका", "bn": "%2$s তে %1$s বিক্রি করুন", "te": "%2$s వద్ద %1$s ను విక్రయించండి"},
    "price_per_quintal_val": {"en": "Price: ₹%1$s / Quintal", "hi": "कीमत: ₹%1$s / क्विंटल", "mr": "किंमत: ₹%1$s / क्विंटल", "bn": "দাম: ₹%1$s / কুইন্টাল", "te": "ధర: ₹%1$s / క్వింటాల్"},
    "estimated_value_val": {"en": "Estimated Value: ₹%1$s", "hi": "अनुमानित मूल्य: ₹%1$s", "mr": "अंदाजित मूल्य: ₹%1$s", "bn": "আনুমানিক মূল্য: ₹%1$s", "te": "అంచనా విలువ: ₹%1$s"},
    "travel_time_val": {"en": "Travel Time: %1$s", "hi": "यात्रा का समय: %1$s", "mr": "प्रवासाची वेळ: %1$s", "bn": "ভ্রমণের সময়: %1$s", "te": "ప్రయాణ సమయం: %1$s"},
    "request_id": {"en": "Request #%1$s", "hi": "अनुरोध #%1$s", "mr": "विनंती #%1$s", "bn": "অনুরোধ #%1$s", "te": "అభ్యర్థన #%1$s"},
    "farmer_name": {"en": "Farmer: %1$s", "hi": "किसान: %1$s", "mr": "शेतकरी: %1$s", "bn": "কৃষক: %1$s", "te": "రైతు: %1$s"},
    "location_name": {"en": "Location: %1$s", "hi": "स्थान: %1$s", "mr": "स्थान: %1$s", "bn": "অবস্থান: %1$s", "te": "స్థానం: %1$s"},
    "welcome_back": {"en": "Welcome Back", "hi": "वापसी पर स्वागत है", "mr": "परत स्वागत आहे", "bn": "আবার স্বাগতম", "te": "తిరిగి స్వాగతం"},
    "view_details_lower": {"en": "View details", "hi": "विवरण देखें", "mr": "तपशील पहा", "bn": "বিবরণ দেখুন", "te": "వివరాలను వీక్షించండి"},
}

langs = ["en", "hi", "mr", "bn", "te"]
dirs = {"en": "values", "hi": "values-hi", "mr": "values-mr", "bn": "values-bn", "te": "values-te"}
res_dir = "app/src/main/res"

for lang in langs:
    xml_path = os.path.join(res_dir, dirs[lang], "strings.xml")
    try:
        tree = ET.parse(xml_path)
        root = tree.getroot()
    except Exception:
        root = ET.Element("resources")
        tree = ET.ElementTree(root)

    existing_keys = {child.attrib['name'] for child in root if 'name' in child.attrib}

    for key, trans in strings.items():
        if key not in existing_keys:
            val = trans.get(lang, trans["en"])
            elem = ET.Element("string", name=key)
            elem.text = val
            root.append(elem)

    xml_str = '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n'
    for child in root:
        if 'name' in child.attrib:
            text = child.text if child.text else ""
            text = text.replace("'", "\\'").replace("&", "&amp;")
            xml_str += f'    <string name="{child.attrib["name"]}">{text}</string>\n'
    xml_str += '</resources>'
    
    with open(xml_path, 'w', encoding='utf-8') as f:
        f.write(xml_str)

print("Updated parametrized strings.xml")
