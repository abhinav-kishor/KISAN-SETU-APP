import re

with open("app/src/main/java/com/example/ui/screens/MandiRegistrationScreen.kt", "r") as f:
    content = f.read()

# Add states for lat/lng/placeId
content = content.replace(
    'var address by remember { mutableStateOf("") }',
    'var address by remember { mutableStateOf("") }\n    var latitude by remember { mutableStateOf<Double?>(null) }\n    var longitude by remember { mutableStateOf<Double?>(null) }\n    var placeId by remember { mutableStateOf<String?>(null) }'
)

# Replace the OutlinedTextField for Address
old_address_field = """            OutlinedTextField(
                value = address,
                onValueChange = { address = it },
                label = { Text(stringResource(R.string.address)) },
                modifier = Modifier.fillMaxWidth()
            )"""

new_address_field = """            LocationAutocomplete(
                location = address,
                onLocationChange = { address = it },
                onPlaceSelected = { latLng, pId, formattedAddress ->
                    if (latLng != null) {
                        latitude = latLng.latitude
                        longitude = latLng.longitude
                    }
                    placeId = pId
                },
                label = stringResource(R.string.address)
            )"""

content = content.replace(old_address_field, new_address_field)

# Pass them to MandiProfile
content = content.replace(
    'shopPhotoUri = shopPhotoUri?.toString()',
    'shopPhotoUri = shopPhotoUri?.toString(),\n                            latitude = latitude,\n                            longitude = longitude,\n                            placeId = placeId'
)

with open("app/src/main/java/com/example/ui/screens/MandiRegistrationScreen.kt", "w") as f:
    f.write(content)
