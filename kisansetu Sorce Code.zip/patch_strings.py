import xml.etree.ElementTree as ET

tree = ET.parse("app/src/main/res/values/strings.xml")
root = tree.getroot()

def add_string(name, value):
    # Check if exists
    for child in root:
        if child.attrib.get('name') == name:
            return
    elem = ET.SubElement(root, "string", name=name)
    elem.text = value

add_string("no_matching_locations", "No matching locations found.")
add_string("location_search_error", "Unable to search locations. Please check your internet connection.")

tree.write("app/src/main/res/values/strings.xml", encoding="utf-8", xml_declaration=True)
