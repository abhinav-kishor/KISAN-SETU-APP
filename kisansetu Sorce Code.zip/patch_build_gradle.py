import re

with open("app/build.gradle.kts", "r") as f:
    content = f.read()

replacement = """val mapsApiKey = project.findProperty("GOOGLE_MAPS_API_KEY") as? String ?: System.getenv("GOOGLE_MAPS_API_KEY") ?: "YOUR_API_KEY_HERE"
    manifestPlaceholders["GOOGLE_MAPS_API_KEY"] = mapsApiKey"""

content = content.replace('manifestPlaceholders["GOOGLE_MAPS_API_KEY"] = "YOUR_API_KEY_HERE"', replacement)

with open("app/build.gradle.kts", "w") as f:
    f.write(content)
