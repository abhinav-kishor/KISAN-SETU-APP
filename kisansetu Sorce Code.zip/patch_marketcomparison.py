import re

with open("app/src/main/java/com/example/ui/screens/MarketComparisonScreen.kt", "r") as f:
    content = f.read()

pattern = r'''    val sortedMarkets = calculateMarketReturns\(
        markets = MarketRepository\.availableMarkets\.value, 
        quantityQuintals = quantity,
        actualRouteDistancesKm = routeDistancesKm,
        actualRouteDurations = routeDurations
    \)'''

replacement = """    val sortedMarkets = calculateMarketReturns(
        markets = MarketRepository.availableMarkets.value, 
        quantityQuintals = quantity,
        actualRouteDistancesKm = routeDistancesKm,
        actualRouteDurations = routeDurations,
        cropName = selectedCrop
    )"""

content = re.sub(pattern, replacement, content)

with open("app/src/main/java/com/example/ui/screens/MarketComparisonScreen.kt", "w") as f:
    f.write(content)

with open("app/src/main/java/com/example/ui/screens/FarmerHomeScreen.kt", "r") as f:
    content = f.read()
    
pattern = r'''val bestMarketCalc = calculateMarketReturns\(MarketRepository\.availableMarkets\.value, qtyInt\)\.first\(\)'''
replacement = """val bestMarketCalc = calculateMarketReturns(MarketRepository.availableMarkets.value, qtyInt, cropName = crop).first()"""
content = re.sub(pattern, replacement, content)

with open("app/src/main/java/com/example/ui/screens/FarmerHomeScreen.kt", "w") as f:
    f.write(content)

