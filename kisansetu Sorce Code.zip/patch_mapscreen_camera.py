import re

with open("app/src/main/java/com/example/ui/screens/MapScreen.kt", "r") as f:
    content = f.read()

# Introduce mapLoaded state
content = content.replace(
    'val cameraPositionState = rememberCameraPositionState {',
    'var mapLoaded by remember { androidx.compose.runtime.mutableStateOf(false) }\n    val cameraPositionState = rememberCameraPositionState {'
)

# Update the LaunchedEffect
old_launched_effect = """    LaunchedEffect(userLocation, displayedMarkets) {
        if (displayedMarkets.isNotEmpty()) {
            val boundsBuilder = LatLngBounds.builder()
            userLocation?.let { boundsBuilder.include(it) }
            displayedMarkets.forEach { boundsBuilder.include(LatLng(it.latitude, it.longitude)) }
            try {
                cameraPositionState.animate(CameraUpdateFactory.newLatLngBounds(boundsBuilder.build(), 150))
            } catch (e: Exception) {
                // Ignore layout not ready
            }
        } else if (userLocation != null) {
            cameraPositionState.animate(CameraUpdateFactory.newLatLngZoom(userLocation!!, 10f))
        }
    }"""
    
new_launched_effect = """    LaunchedEffect(userLocation, displayedMarkets, mapLoaded) {
        if (mapLoaded) {
            if (displayedMarkets.isNotEmpty()) {
                val boundsBuilder = LatLngBounds.builder()
                userLocation?.let { boundsBuilder.include(it) }
                displayedMarkets.forEach { boundsBuilder.include(LatLng(it.latitude, it.longitude)) }
                try {
                    // Use a smaller padding (64px) to avoid pushing the map out of bounds on small screens
                    cameraPositionState.animate(CameraUpdateFactory.newLatLngBounds(boundsBuilder.build(), 64))
                } catch (e: Exception) {
                    // Ignore layout not ready
                }
            } else if (userLocation != null) {
                try {
                    cameraPositionState.animate(CameraUpdateFactory.newLatLngZoom(userLocation!!, 10f))
                } catch (e: Exception) {}
            }
        }
    }"""
    
content = content.replace(old_launched_effect, new_launched_effect)

# Update the GoogleMap to trigger mapLoaded
content = content.replace(
    """            GoogleMap(
                modifier = Modifier.fillMaxSize(),
                cameraPositionState = cameraPositionState
            ) {""",
    """            GoogleMap(
                modifier = Modifier.fillMaxSize(),
                cameraPositionState = cameraPositionState,
                onMapLoaded = { mapLoaded = true }
            ) {"""
)

# Make MapScreen respect userLocation for permission flow
old_permission_effect = """    LaunchedEffect(Unit) {
        if (hasLocationPermission) {
            mapViewModel.loadLocationAndRoutes(context, MarketRepository.availableMarkets.value)
        } else {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }"""

new_permission_effect = """    LaunchedEffect(userLocation, hasLocationPermission) {
        if (hasLocationPermission || userLocation != null) {
            mapViewModel.loadLocationAndRoutes(context, MarketRepository.availableMarkets.value)
        } else {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }"""

content = content.replace(old_permission_effect, new_permission_effect)


with open("app/src/main/java/com/example/ui/screens/MapScreen.kt", "w") as f:
    f.write(content)
