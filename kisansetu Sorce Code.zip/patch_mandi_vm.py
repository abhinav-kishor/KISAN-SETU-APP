import re

with open('app/src/main/java/com/example/ui/screens/MandiViewModel.kt', 'r') as f:
    content = f.read()

old_profile = """data class MandiProfile(
    val mandiName: String,
    val mandiId: String,
    val ownerName: String,
    val address: String,
    val city: String,
    val contactNumber: String
)"""

new_profile = """data class MandiProfile(
    val mandiName: String,
    val mandiId: String,
    val ownerName: String,
    val address: String,
    val city: String,
    val contactNumber: String,
    val shopPhotoUri: String? = null
)"""

content = content.replace(old_profile, new_profile)

with open('app/src/main/java/com/example/ui/screens/MandiViewModel.kt', 'w') as f:
    f.write(content)
